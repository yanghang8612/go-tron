"""Alternate persistent old/new test processes on exactly the retained pairs."""
import collections
import datetime
import hashlib
import json
import os
import pathlib
import select
import statistics
import subprocess
import time
import traceback

P = pathlib.Path('/data/gtron/history-columns-ordered-pages-20261026-01')
OLD = pathlib.Path('/data/gtron/history-record-columns-container-20261026-01')
state = dict(complete=False, production_mutations=False, samples=0,
             scope='Warm-cache actual CompactHistoryDomain, index, fsync and manifest publication. Three fixed pairs, two persistent implementations, four format/implementation arms, alternating requests; not mainnet synchronization throughput.')
children = {}


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(4 << 20), b''):
            h.update(b)
    return h.hexdigest()


def identity():
    text = subprocess.check_output(['systemctl', 'show', 'gtron', '-p', 'MainPID', '-p', 'ActiveState'], universal_newlines=True)
    out = dict(line.split('=', 1) for line in text.splitlines() if '=' in line)
    pid = int(out['MainPID'])
    out['binary_sha256'] = sha(pathlib.Path('/proc/%d/exe' % pid)) if pid else None
    out['process_start_ticks'] = pathlib.Path('/proc/%d/stat' % pid).read_text().split(') ', 1)[1].split()[19] if pid else None
    return out


def save():
    state['utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    q = P/'publish-status.json.tmp'
    q.write_text(json.dumps(state, sort_keys=True, indent=2)+'\n')
    os.replace(str(q), str(P/'publish-status.json'))


def send(arm, request):
    child = children[arm]
    child.stdin.write((json.dumps(request)+'\n').encode())
    child.stdin.flush()
    deadline = time.monotonic()+600
    while time.monotonic() < deadline:
        ready, _, _ = select.select([child.stdout], [], [], min(5, deadline-time.monotonic()))
        if not ready:
            assert child.poll() is None, 'private publisher exited early'
            continue
        line = child.stdout.readline()
        if not line:
            raise RuntimeError('private publisher EOF '+arm)
        with (P/('publish-'+arm+'.log')).open('ab') as log:
            log.write(line)
        if line.startswith(b'REUSE_ROW '):
            row = json.loads(line[len(b'REUSE_ROW '):])
            assert row['Label'] == request['Label'] and row['Pair']['Index'] == request['PairIndex']
            row['Implementation'] = arm
            return row
    raise TimeoutError('private publication sample')


try:
    gate = json.loads((P/'native-status.json').read_text())
    assert gate['complete'] and all(r['returncode'] == 0 for r in gate['checks'])
    assert all(json.loads((OLD/n).read_text())['complete'] for n in ('capture-status.json', 'acceptance-status.json', 'publish-driver-status.json'))
    assert not (P/'publish-samples.jsonl').exists(), 'do not restart measured experiment'
    assert __import__('shutil').disk_usage('/data').free > 100*10**9
    state['before_identity'] = identity()
    state['native_status_sha256'] = sha(P/'native-status.json')
    state['old_plan_sha256'] = sha(OLD/'publish-comparison/plan.json')
    state['old_samples_sha256'] = sha(OLD/'publish-comparison/samples.jsonl')
    plan = json.loads((OLD/'publish-comparison/plan.json').read_text())['selected']
    assert [r['Index'] for r in plan] == [458, 2309, 4147]
    env = {k: v for k,v in os.environ.items() if not k.startswith('GTRON_')}
    env.update(GOMAXPROCS='2', GOMEMLIMIT='3GiB', CGO_ENABLED='1')
    for arm in ('old', 'new'):
        binary = P/(arm+'-publish.test')
        state[arm+'_binary_sha256'] = sha(binary)
        child_env = dict(env, GTRON_REUSE_ARM=arm)
        children[arm] = subprocess.Popen([str(binary), '-test.run=^TestOfflineRecordColumnEncoderReusePublishServer$', '-test.v', '-test.timeout=2h'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=child_env, bufsize=0)
    rows = []
    save()
    with (P/'publish-samples.jsonl').open('xb') as output:
        for group, pair in enumerate(plan):
            arms = [('old', '2'), ('old', '5'), ('new', '2'), ('new', '5')]
            for round_index in range(5):
                offset = (group+round_index) % 4
                order = arms[offset:]+arms[:offset]
                if round_index % 2:
                    order = list(reversed(order))
                for arm, fmt in order:
                    state['phase'] = 'pair-%d-round-%d-%s-%s' % (group, round_index, arm, fmt)
                    save()
                    label = 'pair-%d-round-%d-format-%s' % (group, round_index, fmt)
                    row = send(arm, dict(PairIndex=pair['Index'], Format=fmt, Label=label, Timed=round_index > 0))
                    output.write((json.dumps(row, sort_keys=True)+'\n').encode())
                    output.flush()
                    os.fsync(output.fileno())
                    rows.append(row)
                    state['samples'] = len(rows)
                    assert identity() == state['before_identity'], 'production identity changed externally'
                    save()
    for arm, child in children.items():
        child.stdin.write(b'{"Stop":true}\n')
        child.stdin.flush()
        tail, _ = child.communicate(timeout=120)
        with (P/('publish-'+arm+'.log')).open('ab') as log:
            log.write(tail)
        assert child.returncode == 0, arm+' failed'
    groups = collections.defaultdict(list)
    for row in rows:
        if row['Timed']:
            groups[(row['Pair']['Index'], row['Implementation'], row['Format'])].append(row)
    summary = []
    for (pair, arm, fmt), items in sorted(groups.items()):
        assert len(items) == 4
        summary.append(dict(pair_index=pair, implementation=arm, format=fmt, n=4,
                            median_seconds=statistics.median(r['Seconds'] for r in items),
                            min_seconds=min(r['Seconds'] for r in items), max_seconds=max(r['Seconds'] for r in items),
                            median_cpu_seconds=statistics.median(r['CPUSeconds'] for r in items),
                            median_alloc_bytes=statistics.median(r['AllocBytes'] for r in items),
                            median_gc=statistics.median(r['GCs'] for r in items), output_bytes=items[0]['OutputBytes'],
                            canonical_and_companion_sha=items[0]['CanonicalAndCompanionSHA'],
                            physical_output_sha={r['kind']:r['checksum'] for r in items[0]['OutputRefs']}))
    (P/'publish-summary.json').write_text(json.dumps(summary, sort_keys=True, indent=2)+'\n')
    assert len(rows) == 60 and sum(r['Timed'] for r in rows) == 48
    state.update(complete=True, phase='complete', total_samples=60, timed_samples=48,
                 all_physical_outputs_equal_frozen_reference=True, after_identity=identity(),
                 summary_sha256=sha(P/'publish-summary.json'), samples_sha256=sha(P/'publish-samples.jsonl'))
    assert state['after_identity'] == state['before_identity']
    save()
except BaseException as error:
    state.update(phase='failed', error=repr(error), traceback=traceback.format_exc())
    save()
    raise
finally:
    for child in children.values():
        if child.poll() is None:
            child.terminate()
            try:
                child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                child.kill()
