package snapshots

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"regexp"
	"runtime"
	"testing"
)

// Overlay-only harness, compiled against each frozen implementation. Both
// processes remain alive while the controller alternates individual samples.
func TestOfflineRecordColumnEncoderReusePublishServer(t *testing.T) {
	const lab = "/data/gtron/history-columns-ordered-pages-20261026-01"
	const old = "/data/gtron/history-record-columns-container-20261026-01"
	arm := os.Getenv("GTRON_REUSE_ARM")
	if arm == "" {
		t.Skip("private publication controller only")
	}
	if arm != "old" && arm != "new" || runtime.GOMAXPROCS(0) != 2 {
		t.Fatal("private arm/budget guard")
	}
	t.Setenv("GTRON_HISTORY_COMPACTION_SOURCE_WORKERS", "2")
	var plan struct{ Selected []columnPublishPair }
	b, err := os.ReadFile(filepath.Join(old, "publish-comparison/plan.json"))
	if err != nil || json.Unmarshal(b, &plan) != nil || len(plan.Selected) != 3 {
		t.Fatal("fixed original pair plan", err)
	}
	pairs := map[int]columnPublishPair{}
	for _, pair := range plan.Selected {
		pairs[pair.Index] = pair
	}
	file, err := os.Open(filepath.Join(old, "publish-comparison/samples.jsonl"))
	if err != nil {
		t.Fatal(err)
	}
	expected := map[string]columnPublishRow{}
	scan := bufio.NewScanner(file)
	for scan.Scan() {
		var row columnPublishRow
		if err := json.Unmarshal(scan.Bytes(), &row); err != nil {
			t.Fatal(err)
		}
		expected[fmt.Sprintf("%d/%s", row.Pair.Index, row.Format)] = row
	}
	if err := scan.Err(); err != nil {
		t.Fatal(err)
	}
	file.Close()
	root := filepath.Join(lab, "publish-"+arm)
	if err := os.Mkdir(root, 0700); err != nil {
		t.Fatal(err)
	}
	labels := regexp.MustCompile(`^pair-[0-2]-round-[0-4]-format-[25]$`)
	requests := json.NewDecoder(os.Stdin)
	for {
		var request struct {
			PairIndex     int
			Format, Label string
			Timed         bool
			Stop          bool
		}
		if err := requests.Decode(&request); err != nil {
			t.Fatal("controller input", err)
		}
		if request.Stop {
			return
		}
		pair, ok := pairs[request.PairIndex]
		if !ok || !labels.MatchString(request.Label) || request.Format != "2" && request.Format != "5" {
			t.Fatal("request scope guard")
		}
		row := runColumnPublish(t, filepath.Join(old, "baseline-input/state-snapshots"), root, pair, request.Format, request.Label, request.Timed)
		prior, ok := expected[fmt.Sprintf("%d/%s", pair.Index, request.Format)]
		if !ok || row.OutputBytes != prior.OutputBytes || !reflect.DeepEqual(row.CanonicalAndCompanionSHA, prior.CanonicalAndCompanionSHA) || row.ColumnKeyModes != prior.ColumnKeyModes || row.PlainPages != prior.PlainPages {
			t.Fatal("output disagrees with original frozen real-pair proof")
		}
		checksums := func(refs []SegmentRef) map[SegmentKind]string {
			out := map[SegmentKind]string{}
			for _, ref := range refs {
				out[ref.Kind] = ref.Checksum
			}
			return out
		}
		if !reflect.DeepEqual(checksums(row.OutputRefs), checksums(prior.OutputRefs)) {
			t.Fatal("physical output SHA changed")
		}
		b, err := json.Marshal(row)
		if err != nil {
			t.Fatal(err)
		}
		fmt.Printf("REUSE_ROW %s\n", b)
	}
}
