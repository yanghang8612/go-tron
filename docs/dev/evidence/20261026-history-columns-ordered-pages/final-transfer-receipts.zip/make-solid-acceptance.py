import pathlib,zipfile,tarfile,lzma,hashlib,json,io
p=pathlib.Path('/data/gtron/history-columns-ordered-pages-20261026-01');raw=(p/'final-acceptance-core.zip').read_bytes();assert hashlib.sha256(raw).hexdigest()=='26641ef303359d752ee8ce4399828a9f91ec211d025b6133a5aacfc95e7890dd'
out=io.BytesIO()
with zipfile.ZipFile(io.BytesIO(raw)) as z:
 assert z.testzip() is None and len(z.namelist())==704
 with tarfile.open(fileobj=out,mode='w',format=tarfile.PAX_FORMAT) as t:
  for name in sorted(z.namelist()):
   b=z.read(name);info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(b))
b=lzma.compress(out.getvalue(),format=lzma.FORMAT_XZ,preset=6);q=p/'final-acceptance-core.tar.xz';assert not q.exists() or q.read_bytes()==b
if not q.exists():q.write_bytes(b)
s=q.stat();r=dict(complete=True,archive=q.name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),members=704,original_zip_bytes=len(raw),original_zip_sha256=hashlib.sha256(raw).hexdigest(),all_members_exactly_preserved=True,device=str(s.st_dev),inode=str(s.st_ino),mtime_ns=str(s.st_mtime_ns),production_mutations=False);(p/'final-acceptance-solid-seal.json').write_text(json.dumps(r,sort_keys=True,indent=2)+'\n')
