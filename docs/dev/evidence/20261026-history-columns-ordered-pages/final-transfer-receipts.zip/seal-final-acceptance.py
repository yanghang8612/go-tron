"""Seal final-binary acceptance only after the original bounded unit exits."""
import datetime
import hashlib
import io
import json
import pathlib
import subprocess
import zipfile

P = pathlib.Path('/data/gtron/history-columns-ordered-pages-20261026-01')
S = P/'candidate-source'
sha = lambda b: hashlib.sha256(b).hexdigest()


def file_sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for value in iter(lambda:f.read(4 << 20),b''):
            h.update(value)
    return h.hexdigest()


def show(unit):
    text = subprocess.check_output(['systemctl','show',unit,'-p','LoadState','-p','ActiveState','-p','SubState','-p','MainPID','-p','ExecMainStatus'],universal_newlines=True)
    return dict(s.split('=',1) for s in text.splitlines() if '=' in s)


def immutable(path,data):
    if path.exists():
        assert path.read_bytes() == data
    else:
        with path.open('xb') as f:
            f.write(data)


status = json.loads((P/'acceptance-status.json').read_text())
assert status['complete'] and status['phase'] == 'complete' and not status.get('error')
assert not status['production_mutations'] and not status['full_latest_snapshot_export_import_performed']
assert status['before_identity'] == status['after_identity']
assert status['chaindata_full_sha_unchanged'] and status['fingerprint_files_per_mode'] == 803
assert status['full_http_requests'] == 286 and status['actual_history_restore_blocks'] == 60
assert len(status['checks']) == 3 and {x['label'] for x in status['checks']} == {'full-muhash','history-restore','full-http-comparison'}
assert all(x['returncode'] == 0 and file_sha(P/(x['label']+'.log')) == x['log_sha256'] for x in status['checks'])
unit = show('gtron-columns-ordered-pages-acceptance-20261026-01.service')
assert unit['MainPID'] == '0' and unit['ActiveState'] == 'inactive' and unit['ExecMainStatus'] == '0', 'observe the same job until it exits; do not restart'
native = json.loads((P/'native-status.json').read_text())
assert all(file_sha(P/n) == h for n,h in native['binaries'].items())
product = json.loads((P/'source-inventory.json').read_text())
extra = json.loads((P/'inherited-extra-go-inventory.json').read_text())
assert len(product) == 2149 and len(extra) == 24
assert all(file_sha(S/n) == h for n,h in product.items())
assert all(file_sha(S/n) == h for n,h in extra.items())
actual_go = {str(f.relative_to(S)) for f in S.rglob('*.go') if 'build' not in f.relative_to(S).parts and 'target' not in f.relative_to(S).parts}
assert actual_go == {n for n in product if n.endswith('.go')} | set(extra)
assert (P/'chaindata-before.json').read_bytes() == (P/'chaindata-after.json').read_bytes()
fingerprints = json.loads((P/'chaindata-before.json').read_text())
assert set(fingerprints) == {'baseline','candidate'} and all(len(v) == 803 for v in fingerprints.values())
census = json.loads((P/'muhash-census.json').read_text())
assert census['complete'] and census['muhash_verified'] and census['block_num'] == 11818192 and census['tx_num'] == 601386177
assert census['source_rows'] == [3484117,481,141418493]
assert bytes(census['muhash_root']).hex() == '8fbf149684146a59b1650b318a768f0edbae0c8c1c3ceb2c5c610129c10f76a5'
comparison = P/'tail-read-comparison'
cs = json.loads((comparison/'comparison-status.json').read_text())
assert cs['complete'] and cs['requests'] == 286 and cs['all_responses_correct'] and not cs['environment_identity_changed']
assert cs['before_identity'] == cs['after_identity']
requests = [json.loads(s) for s in (comparison/'requests.jsonl').read_text().splitlines()]
assert len(requests) == 286 and all(r['correct'] and 'error' not in r['response'] and r['response']['result'] == r['expected'] for r in requests)
assert [r['id'] for r in requests] == list(range(1,287))
items = {n:(P/n).read_bytes() for n in ['acceptance-status.json','native-status.json','source-inventory.json','inherited-extra-go-inventory.json','encoder-identity.json','publication-assessment.json','run-acceptance.py','compare-ordered.py','muhash-census.json','history-restore.json','chaindata-before.json','chaindata-after.json','acceptance-start-receipt.json']}
for row in status['checks']:
    items[row['label']+'.log'] = (P/(row['label']+'.log')).read_bytes()
for n in ['core/offline_fixed_http_test.go','core/offline_request_muhash_test.go','core/state/snapshots/offline_routing_test.go']:
    assert n in extra and file_sha(S/n) == extra[n]
    items['harness-source/'+n] = (S/n).read_bytes()
for n in ['baseline.test','candidate.test','ordered-snapshots.test']:
    info = subprocess.check_output(['/data/go/bin/go','version','-m',str(P/n)])
    items[n+'-final-build-info.txt'] = info
trace_index = []
for file in sorted(comparison.rglob('*')):
    if not file.is_file() or '-cache-input' in str(file.relative_to(comparison)):
        continue
    name = str(file.relative_to(P))
    if file.suffix == '.trace':
        st = file.stat()
        trace_index.append(dict(path=name,bytes=st.st_size,sha256=file_sha(file),retained_on_server=True))
        continue
    if file.suffix not in ('.json','.jsonl','.log','.pprof','.txt'):
        continue
    assert file.stat().st_size < 4 << 20, 'unexpected non-trace core file'
    items[name] = file.read_bytes()
assert len(list(comparison.glob('*/ready.json'))) == len(list(comparison.glob('*/environment.json'))) == len(list(comparison.glob('*/process-resources.json'))) == 122
assert len(list(comparison.glob('*-residency.json'))) == 56
assert len(trace_index) == 18
for n in ['baseline-private-files.json','candidate-private-files.json','baseline-read-files.json','candidate-read-files.json']:
    assert 'tail-read-comparison/'+n in items
proof = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),complete=True,production_mutations=False,production=show('gtron.service'),acceptance_unit=unit,source_files=2149,inherited_go_files=24,source_inventory_sha256=file_sha(P/'source-inventory.json'),inherited_inventory_sha256=file_sha(P/'inherited-extra-go-inventory.json'),binaries=native['binaries'],chaindata_before_sha256=file_sha(P/'chaindata-before.json'),chaindata_after_sha256=file_sha(P/'chaindata-after.json'),traces_retained_on_server=trace_index,full_latest_snapshot_export_import_performed=False)
items['final-source-and-evidence-closure.json'] = (json.dumps(proof,sort_keys=True,indent=2)+'\n').encode()
items['evidence-manifest.json'] = (json.dumps({n:sha(b) for n,b in items.items()},sort_keys=True,indent=2)+'\n').encode()
out = io.BytesIO()
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
    for n,b in sorted(items.items()):
        info = zipfile.ZipInfo(n,date_time=(2026,10,26,0,0,0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        z.writestr(info,b)
data = out.getvalue()
assert len(data) < 4 << 20
immutable(P/'final-acceptance-core.zip',data)
receipt = dict(complete=True,production_mutations=False,seals=[dict(name='final-acceptance-core.zip',bytes=len(data),sha256=sha(data),members=len(items))])
immutable(P/'final-acceptance-seal.json',(json.dumps(receipt,sort_keys=True,indent=2)+'\n').encode())
print('FINAL_ORDERED_ACCEPTANCE_SEALED')
