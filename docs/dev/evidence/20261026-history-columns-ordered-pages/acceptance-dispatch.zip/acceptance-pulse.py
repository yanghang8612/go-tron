import pathlib,json,datetime,subprocess
p=pathlib.Path('/data/gtron/history-columns-ordered-pages-20261026-01')
x=dict(s.split('=',1) for s in subprocess.check_output(['systemctl','show','gtron-columns-ordered-pages-acceptance-20261026-01.service','-p','MainPID','-p','ActiveState','-p','ExecMainStatus'],universal_newlines=True).splitlines() if '=' in s)
pid=int(x.get('MainPID','0'));s=json.loads((p/'acceptance-status.json').read_text())
r=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),unit=x,phase=s['phase'],complete=s['complete'],checks=s.get('checks',[]),error=s.get('error'),source_before=s.get('source_before'))
if pid:r['processes']=subprocess.check_output(['ps','-o','pid,ppid,etimes,pcpu,rss,args','-p',str(pid),'--ppid',str(pid)],universal_newlines=True)
(p/'acceptance-pulse-01.json').write_text(json.dumps(r,sort_keys=True,indent=2)+'\n')
