"""Start/observe one bounded private final-binary acceptance; never retry a run."""
import datetime
import hashlib
import json
import pathlib
import subprocess

P = pathlib.Path('/data/gtron/history-columns-ordered-pages-20261026-01')
UNIT = 'gtron-columns-ordered-pages-acceptance-20261026-01.service'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
expected = {'run-acceptance.py':'1c1e5f2983c92dbd6e64248f326a559de0b8d445847ee23670cd88d6e04a04f0', 'compare-ordered.py':'aaeeba2c034b739baf434cc924acb5271c6161899765a78fa3974a5dc8a9a81c'}
assert all(sha(P/n) == h for n,h in expected.items())
n = json.loads((P/'native-status.json').read_text())
p = json.loads((P/'publish-status.json').read_text())
assert n['complete'] and len(n['checks']) == 10 and all(x['returncode'] == 0 for x in n['checks'])
assert p['complete'] and p['samples'] == 60 and p['timed_samples'] == 48 and not p.get('error')
assert n['source_inventory_sha256'] == '3281b8fcd833df0066efba23ac68c6ed329f9a1534ea5be5c75002655b6e9150'
assert n['encoder_identity']['source_commit'] == '6bb9b95e2a0640dd7642bbd1c9c900ad1e03cc83'
assert all(sha(P/f) == n['binaries'][f] for f in ['ordered-http.test','ordered-snapshots.test'])
assessment = json.loads((P/'publication-assessment.json').read_text())
assert assessment['complete_raw_verification'] and assessment['decision'] == 'retain-experimental-candidate-for-final-correctness-and-query-acceptance'
assert assessment['samples_sha256'] == p['samples_sha256'] and assessment['summary_sha256'] == p['summary_sha256']


def show(unit):
    fields = ['LoadState','ActiveState','SubState','MainPID','ExecMainStatus','MemoryLimit','CPUQuotaPerSecUSec','Nice']
    cmd = ['systemctl','show',unit]
    for name in fields:
        cmd += ['-p',name]
    result = subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,universal_newlines=True)
    return dict(s.split('=',1) for s in result.stdout.splitlines() if '=' in s)


def immutable(path,data):
    if path.exists():
        assert path.read_bytes() == data
    else:
        with path.open('xb') as f:
            f.write(data)


native_unit = show('gtron-columns-ordered-pages-native-20261026-01.service')
assert native_unit['MainPID'] == '0' and native_unit['ActiveState'] == 'inactive' and native_unit['ExecMainStatus'] == '0'
before = show(UNIT)
prod_before = show('gtron.service')
marker = P/'acceptance-dispatch.json'
dispatched = False
if marker.exists():
    prior = json.loads(marker.read_text())
    assert prior['unit'] == UNIT and prior['source_commit'] == n['encoder_identity']['source_commit'] and prior['script_sha256'] == expected
    # A previously completed/failed/missing transient unit is not resubmitted.
    assert (P/'acceptance-status.json').exists() or before['MainPID'] != '0', 'known dispatch has no visible status; investigate without restarting'
else:
    assert before['LoadState'] == 'not-found' and not (P/'acceptance-status.json').exists()
    dispatch = dict(unit=UNIT,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_commit=n['encoder_identity']['source_commit'],script_sha256=expected,production_mutations=False)
    immutable(marker,(json.dumps(dispatch,sort_keys=True,indent=2)+'\n').encode())
    result = subprocess.run(['systemd-run','--unit='+UNIT,'--description=Private ordered-page full MuHash HTTP and history restore acceptance','--property=MemoryLimit=4G','--property=CPUQuota=200%','--property=Nice=15','/usr/bin/ionice','-c3','/usr/bin/python3',str(P/'run-acceptance.py')],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,universal_newlines=True)
    immutable(P/'acceptance-dispatch-output.txt',result.stdout.encode())
    assert result.returncode == 0,result.stdout
    dispatched = True
after = show(UNIT)
pid = int(after['MainPID'])
receipt = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),unit=UNIT,dispatched_now=dispatched,pid=pid,proc_exists=bool(pid and pathlib.Path('/proc/%d'%pid).exists()),systemctl=after,source_commit=n['encoder_identity']['source_commit'],candidate_http_binary_sha256=n['binaries']['ordered-http.test'],candidate_snapshots_binary_sha256=n['binaries']['ordered-snapshots.test'],assessment_sha256=sha(P/'publication-assessment.json'),script_sha256=expected,production_identity_before=prod_before,production_identity_after=show('gtron.service'),production_mutations=False,scope='Private fixed-copy acceptance only; no production restart, deploy, data deletion or production budget change.')
assert receipt['production_identity_before'] == receipt['production_identity_after']
if pid:
    receipt['ps'] = subprocess.check_output(['ps','-o','pid,ppid,etimes,pcpu,rss,args','-p',str(pid),'--ppid',str(pid)],universal_newlines=True)
(P/'acceptance-start-receipt.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
print('PRIVATE_ORDERED_ACCEPTANCE_READY',pid)
