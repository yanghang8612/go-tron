"""Seal completed isolated native/publication evidence; no production mutation."""
import datetime
import hashlib
import io
import json
import pathlib
import subprocess
import zipfile

P = pathlib.Path('/data/gtron/history-columns-ordered-pages-20261026-01')
SERIAL = pathlib.Path('/data/gtron/history-columns-encoder-reuse-20261026-01')
OLD = pathlib.Path('/data/gtron/history-record-columns-container-20261026-01')
sha = lambda b: hashlib.sha256(b).hexdigest()


def file_sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for value in iter(lambda: f.read(4 << 20), b''):
            h.update(value)
    return h.hexdigest()


def show(unit):
    x = subprocess.check_output(['systemctl', 'show', unit, '-p', 'LoadState', '-p', 'ActiveState', '-p', 'SubState', '-p', 'MainPID', '-p', 'ExecMainStatus'], universal_newlines=True)
    return dict(line.split('=', 1) for line in x.splitlines() if '=' in line)


def source(root, inv, extra):
    product = json.loads(inv.read_text())
    inherited = json.loads(extra.read_text())
    assert not (set(product) & set(inherited))
    assert all(file_sha(root/n) == h for n,h in product.items())
    assert all(file_sha(root/n) == h for n,h in inherited.items())
    found = {str(f.relative_to(root)) for f in root.rglob('*.go') if 'build' not in f.relative_to(root).parts and 'target' not in f.relative_to(root).parts}
    assert found == {n for n in product if n.endswith('.go')} | set(inherited), 'unaccounted Go input'
    return dict(product_files=len(product), inherited_go_files=len(inherited), inventory_sha256=file_sha(inv), inherited_sha256=file_sha(extra), mismatches=[], unaccounted_go_files=[], sapling_library_sha256=file_sha(root/'third_party/librustzcash/target/release/librustzcash.a'))


def seal(name, items):
    items = dict(items)
    items['evidence-manifest.json'] = (json.dumps({n: sha(b) for n,b in items.items()}, sort_keys=True, indent=2)+'\n').encode()
    out = io.BytesIO()
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
        for n,b in sorted(items.items()):
            info = zipfile.ZipInfo(n, date_time=(2026, 10, 26, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, b)
    b = out.getvalue()
    target = P/name
    assert not target.exists(), 'observe existing seal instead of replacing it'
    with target.open('xb') as f:
        f.write(b)
    return dict(name=name, bytes=len(b), sha256=sha(b), members=len(items))


native = json.loads((P/'native-status.json').read_text())
publish = json.loads((P/'publish-status.json').read_text())
assert native['complete'] and len(native['checks']) == 10 and all(x['returncode'] == 0 for x in native['checks'])
assert publish['complete'] and not publish.get('error') and publish['samples'] == 60 and publish['timed_samples'] == 48
unit = show('gtron-columns-ordered-pages-native-20261026-01.service')
assert unit['MainPID'] == '0' and unit['ActiveState'] == 'inactive' and unit['ExecMainStatus'] == '0', 'native/publish unit has not exited successfully'
assert all(file_sha(P/n) == h for n,h in native['binaries'].items())
proof = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), production_mutations=False,
             new=source(P/'candidate-source', P/'source-inventory.json', P/'inherited-extra-go-inventory.json'),
             serial=source(SERIAL/'candidate-source', P/'base-inventory.json', SERIAL/'inherited-extra-go-inventory.json'),
             binaries=native['binaries'], native_unit=unit, production=show('gtron.service'), full_fixed_copy_acceptance_complete=False)
assert proof['new']['sapling_library_sha256'] == proof['serial']['sapling_library_sha256'] == native['sapling_library_sha256']
proof_raw = (json.dumps(proof, sort_keys=True, indent=2)+'\n').encode()
rows = [json.loads(s) for s in (P/'publish-samples.jsonl').read_text().splitlines()]
assert len(rows) == 60
closure = []
hashed = {}
for row in rows:
    directory = P/('publish-'+row['Implementation'])/row['Label']
    for ref in row['OutputRefs']:
        path = directory/ref['path']
        assert path.resolve().is_relative_to(P.resolve()) if hasattr(path.resolve(), 'is_relative_to') else str(path.resolve()).startswith(str(P.resolve())+'/')
        st = path.stat()
        key = (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns)
        if key not in hashed:
            hashed[key] = file_sha(path)
        assert st.st_size == ref['size'] and 'sha256:'+hashed[key] == ref['checksum']
        after = path.stat()
        assert (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns) == key
        closure.append(dict(implementation=row['Implementation'], label=row['Label'], path=ref['path'], kind=ref['kind'], bytes=st.st_size, sha256=hashed[key], inode=str(st.st_ino), device=str(st.st_dev), mtime_ns=str(st.st_mtime_ns)))
assert len(closure) == 180
closure_raw = (json.dumps(dict(complete=True, files=closure, references=180, unique_physical_files=len(hashed), bytes_hashed=sum(k[2] for k in hashed)), sort_keys=True, indent=2)+'\n').encode()
items = {n: (P/n).read_bytes() for n in ['native-status.json','native-summary.json','source-verification.json','source-inventory.json','base-inventory.json','inherited-extra-go-inventory.json','encoder-identity.json','native-upload-plan.json','prepare-native.py','run-publish.py','offline_column_reuse_publish_test.go','offline_columns_ordered_fixture_test.go']}
for row in native['checks']:
    data = (P/(row['label']+'.log')).read_bytes()
    assert sha(data) == row['log_sha256']
    items[row['label']+'.log'] = data
for n in ['gtron-ordered-pages', 'ordered-snapshots.test', 'ordered-http.test']:
    items[n+'-build-info.txt'] = (P/(n+'-build-info.txt')).read_bytes()
items['post-native-source-and-binaries.json'] = proof_raw
receipts = [seal('native-complete.zip', items)]
items = {n: (P/n).read_bytes() for n in ['publish-status.json','publish-samples.jsonl','publish-summary.json','publish-old.log','publish-new.log','run-publish.py','offline_column_reuse_publish_test.go','native-status.json','encoder-identity.json']}
items.update({'frozen-original-plan.json':(OLD/'publish-comparison/plan.json').read_bytes(), 'frozen-original-samples.jsonl':(OLD/'publish-comparison/samples.jsonl').read_bytes(), 'post-native-source-and-binaries.json':proof_raw, 'physical-output-closure.json':closure_raw})
receipts.append(seal('publication-complete.zip', items))
(P/'evidence-seals.json').write_text(json.dumps(dict(complete=True, production_mutations=False, seals=receipts), sort_keys=True, indent=2)+'\n')
print('ORDERED_NATIVE_PUBLICATION_SEALED')
