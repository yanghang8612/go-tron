"""One-shot native checks; wait for old fixed-copy timing, never touch gtron."""
import datetime
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import time
import traceback

P = pathlib.Path('/data/gtron/history-columns-ordered-pages-20261026-01')
SERIAL = pathlib.Path('/data/gtron/history-columns-encoder-reuse-20261026-01')
POLICY = pathlib.Path('/data/gtron/history-auto-columns-policy-20261026-01')
OLD = pathlib.Path('/data/gtron/history-record-columns-container-20261026-01')
BASE = SERIAL/'candidate-source'
S = P/'candidate-source'
state = dict(complete=False, native_checks_only=True, full_fixed_copy_acceptance_complete=False,
             production_mutations=False, checks=[])


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(4 << 20), b''):
            h.update(b)
    return h.hexdigest()


def save():
    state['utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    data = (json.dumps(state, sort_keys=True, indent=2)+'\n').encode()
    q = P/'native-status.json.tmp'
    q.write_bytes(data)
    os.replace(str(q), str(P/'native-status.json'))
    summary = {k: v for k,v in state.items() if k not in ('checks', 'encoder_identity', 'traceback', 'error')}
    summary['checks'] = [{k: v for k,v in row.items() if k != 'argv'} for row in state['checks']]
    summary['source_commit'] = state.get('encoder_identity', {}).get('source_commit')
    summary['native_status_sha256'] = hashlib.sha256(data).hexdigest()
    if state.get('error'):
        summary['error_summary'] = state['error'][:1000]
    q = P/'native-summary.json.tmp'
    q.write_text(json.dumps(summary, sort_keys=True, separators=(',', ':'))+'\n')
    os.replace(str(q), str(P/'native-summary.json'))


def run(label, args, env, timeout, cwd=None):
    state['phase'] = label
    save()
    started = time.monotonic()
    with (P/(label+'.log')).open('wb') as log:
        result = subprocess.run(args, cwd=str(cwd or S), env=env, stdout=log, stderr=subprocess.STDOUT, timeout=timeout)
    state['checks'].append(dict(label=label, argv=args, returncode=result.returncode,
                                seconds=time.monotonic()-started, log_sha256=sha(P/(label+'.log'))))
    save()
    if result.returncode:
        raise RuntimeError(label+' failed; retained log')


def source_check(root, expected):
    bad = [n for n, h in expected.items() if not (root/n).is_file() or sha(root/n) != h]
    if bad:
        raise RuntimeError('source mismatch: '+repr(bad[:10]))


def ignored(path, names):
    relative = pathlib.Path(path).relative_to(BASE)
    result = {n for n in names if n == '.git'}
    if str(relative) == '.':
        result.update(n for n in names if n == 'build')
    if relative == pathlib.Path('third_party/librustzcash'):
        result.add('target')
    return result


try:
    state['encoder_identity'] = json.loads((P/'encoder-identity.json').read_text())
    state['phase'] = 'wait-frozen-acceptance-and-publication'
    save()
    deadline = time.monotonic()+16*3600
    while True:
        gates = {}
        for name in ('capture-status.json', 'acceptance-status.json', 'publish-driver-status.json'):
            gates[name] = json.loads((OLD/name).read_text()) if (OLD/name).exists() else {}
            if gates[name].get('error'):
                raise RuntimeError('frozen gate failed: '+name+': '+str(gates[name]['error']))
        if all(value.get('complete') for value in gates.values()):
            break
        if time.monotonic() > deadline:
            raise TimeoutError('frozen acceptance/publication gate')
        time.sleep(10)
    state['frozen_gate_receipt_sha256'] = {n: sha(OLD/n) for n in gates}
    serial_gates = {n: json.loads((SERIAL/n).read_text()) for n in ('native-status.json', 'publish-status.json', 'profile-status.json')}
    assert all(value.get('complete') and not value.get('error') for value in serial_gates.values()), 'frozen serial baseline incomplete'
    state['serial_gate_receipt_sha256'] = {n: sha(SERIAL/n) for n in serial_gates}
    base = json.loads((P/'base-inventory.json').read_text())
    current = json.loads((P/'source-inventory.json').read_text())
    identity = json.loads((P/'encoder-identity.json').read_text())
    assert len(base) == 2148 and len(current) == 2149 and not S.exists()
    assert shutil.disk_usage('/data').free > 100*10**9, 'native source/check disk reserve'
    state['phase'] = 'verify-and-copy-private-source'
    save()
    source_check(BASE, base)
    base_extra = json.loads((SERIAL/'inherited-extra-go-inventory.json').read_text())
    source_check(BASE, base_extra)
    payload_manifest = json.loads((P/'payload-manifest.json').read_text())
    source_check(P, payload_manifest)
    # Copy source/fixtures into independent inodes. Exclude Git metadata and
    # previous build output; never create mutable source hard links.
    size = 0
    for directory, directories, files in os.walk(str(BASE)):
        skip = ignored(directory, directories+files)
        directories[:] = [n for n in directories if n not in skip]
        size += sum((pathlib.Path(directory)/n).stat().st_size for n in files if n not in skip and not (pathlib.Path(directory)/n).is_symlink())
    assert size < 8 << 30, 'unexpected source/fixture volume'
    state['source_regular_bytes_preflight'] = size
    shutil.copytree(str(BASE), str(S), symlinks=True, ignore=ignored, copy_function=shutil.copy2)
    for path in (P/'source').rglob('*'):
        if path.is_file():
            relative = path.relative_to(P/'source')
            target = S/relative
            target.parent.mkdir(parents=True, exist_ok=True)
            tmp = target.with_name(target.name+'.encoder-private')
            tmp.write_bytes(path.read_bytes())
            os.replace(str(tmp), str(target))
    # Compiled Go/module inputs are private even if a legacy source was a link.
    for name in current:
        target = S/name
        if target.is_symlink():
            tmp = target.with_name(target.name+'.encoder-private')
            tmp.write_bytes(target.read_bytes())
            os.replace(str(tmp), str(target))
    source_check(S, current)
    for name in base:
        original, copied = (BASE/name).stat(), (S/name).stat()
        assert (original.st_dev, original.st_ino) != (copied.st_dev, copied.st_ino), 'shared mutable source inode'
    source_library = BASE/'third_party/librustzcash/target/release/librustzcash.a'
    assert source_library.stat().st_size < 1 << 30
    lib_sha = sha(source_library)
    library = S/'third_party/librustzcash/target/release/librustzcash.a'
    library.parent.mkdir(parents=True, exist_ok=True)
    assert not library.exists()
    shutil.copy2(str(source_library), str(library))
    assert sha(library) == lib_sha == sha(source_library)
    assert (source_library.stat().st_dev, source_library.stat().st_ino) != (library.stat().st_dev, library.stat().st_ino)
    extra = {str(path.relative_to(S)): sha(path) for path in S.rglob('*.go')
             if str(path.relative_to(S)) not in current}
    assert extra == base_extra, 'inherited harness inputs changed'
    (P/'inherited-extra-go-inventory.json').write_text(json.dumps(extra, sort_keys=True, indent=2)+'\n')
    (P/'source-verification.json').write_text(json.dumps(dict(files=len(current), tests=sum(n.endswith('_test.go') for n in current), mismatches=[], inherited_extra_go_files=len(extra), private_source_inodes=True), sort_keys=True, indent=2)+'\n')
    state['encoder_identity'] = identity
    state['source_files'] = len(current)
    state['source_inventory_sha256'] = sha(P/'source-inventory.json')
    state['sapling_library_sha256'] = lib_sha
    env = {k: v for k, v in os.environ.items() if not k.startswith('GTRON_')}
    env.update(PATH='/data/go/bin:'+env.get('PATH', ''), GOCACHE='/root/.cache/go-build', GOPATH='/root/go',
               GOTOOLCHAIN='local', CGO_ENABLED='1', GOMAXPROCS='2', GOMEMLIMIT='3GiB')
    state['go_version'] = subprocess.check_output(['/data/go/bin/go', 'version'], env=env, universal_newlines=True).strip()
    packages = ['./core/rawdb', './core/state', './core/state/snapshots', './core', './cmd/gtron']
    selector = 'TestRecordColumn|TestHistoryRecordColumns|TestAutoColumns|TestCompressedBlock|TestCompressedFooter|TestHistoryCompressionPipeline|TestDBHistorySharedPipelineFullTrioByteEquivalence|TestDBHistoryColdBenchmarkCompleteModesAndReadOnly|TestDBHistoryReference'
    run('native-focused', ['/data/go/bin/go', 'test', './core/state/snapshots', './cmd/gtron', '-run', selector, '-count=1', '-v', '-timeout=300s'], env, 650)
    run('native-packages', ['/data/go/bin/go', 'test', '-p', '1']+packages+['-count=1', '-timeout=1200s'], env, 2400)
    run('native-race', ['/data/go/bin/go', 'test', '-race', '-p', '1', './core/state/snapshots', './cmd/gtron', '-run', 'TestRecordColumn|TestHistoryRecordColumns|TestAutoColumns|TestCompressedBlock|TestCompressedFooter|TestHistoryCompressionPipeline', '-count=1', '-timeout=300s'], env, 650)
    run('native-vet', ['/data/go/bin/go', 'vet']+packages, env, 600)
    run('native-sapling-build', ['/data/go/bin/go', 'build', '-buildvcs=false', '-tags=sapling', '-o', str(P/'gtron-ordered-pages'), './cmd/gtron'], env, 900)
    run('native-snapshots-build', ['/data/go/bin/go', 'test', '-c', './core/state/snapshots', '-o', str(P/'ordered-snapshots.test')], env, 600)
    run('native-http-build', ['/data/go/bin/go', 'test', '-c', './core', '-o', str(P/'ordered-http.test')], env, 600)
    source_check(S, current)
    source_check(S, extra)
    source_check(BASE, base)
    assert sha(library) == state['sapling_library_sha256']
    state['binaries'] = {n: sha(P/n) for n in ('gtron-ordered-pages', 'ordered-snapshots.test', 'ordered-http.test')}
    for name in state['binaries']:
        (P/(name+'-build-info.txt')).write_bytes(subprocess.check_output(['/data/go/bin/go', 'version', '-m', str(P/name)], env=env))
    # The additional harness exists only in go -overlay, never in frozen sources.
    for arm, source in (('old', BASE), ('new', S)):
        target = source/'core/state/snapshots/offline_column_reuse_publish_test.go'
        assert not target.exists()
        overlay = P/(arm+'-publish-overlay.json')
        extra_target = source/'core/state/snapshots/offline_columns_ordered_fixture_test.go'
        assert not extra_target.exists()
        overlay.write_text(json.dumps({'Replace': {str(target): str(P/'offline_column_reuse_publish_test.go'), str(extra_target): str(P/'offline_columns_ordered_fixture_test.go')}}, sort_keys=True)+'\n')
        run('native-'+arm+'-publish-build', ['/data/go/bin/go', 'test', '-overlay', str(overlay), '-c', './core/state/snapshots', '-o', str(P/(arm+'-publish.test'))], env, 600, source)
        state['binaries'][arm+'-publish.test'] = sha(P/(arm+'-publish.test'))
    run('native-large-publication-fixture', [str(P/'new-publish.test'), '-test.run=^TestOfflineColumnsOrderedLargeFixture$', '-test.v', '-test.timeout=180s'], env, 240)
    source_check(S, current)
    source_check(S, extra)
    source_check(BASE, base)
    source_check(BASE, base_extra)
    source_check(P, payload_manifest)
    state.update(complete=True, phase='complete')
    save()
    with (P/'publish-driver.log').open('wb') as log:
        subprocess.run(['/usr/bin/python3', str(P/'run-publish.py')], cwd=str(P), env=env, stdout=log, stderr=subprocess.STDOUT, timeout=7250, check=True)
    assert json.loads((P/'publish-status.json').read_text())['complete']

except BaseException as error:
    state.update(phase='failed', error=repr(error), traceback=traceback.format_exc())
    save()
    raise
