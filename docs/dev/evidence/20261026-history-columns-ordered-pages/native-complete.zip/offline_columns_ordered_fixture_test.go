package snapshots

import (
	"reflect"
	"runtime"
	"testing"
)

func TestOfflineColumnsOrderedLargeFixture(t *testing.T) {
	procs := runtime.GOMAXPROCS(2)
	defer runtime.GOMAXPROCS(procs)
	t.Setenv("GTRON_HISTORY_COMPACTION_SOURCE_WORKERS", "2")
	dir := t.TempDir()
	refs := writeV6StateDomainHistorySegmentForTest(t, dir, 1, 16384, v6StreamChanges(1, 16384, 1, 80))
	refs = append(refs, writeV6StateDomainHistorySegmentForTest(t, dir, 16385, 32768, v6StreamChanges(16385, 16384, 1, 80))...)
	compressV6StreamFixture(t, dir, refs, historyCompressChunkSize)
	pair := columnPublishPair{FromTxNum: 1, ToTxNum: 32768, Steps: 2, Refs: refs}
	root := t.TempDir()
	plain := runColumnPublish(t, dir, root, pair, "2", "ordinary", false)
	runtime.GOMAXPROCS(1)
	serial := runColumnPublish(t, dir, root, pair, "5", "serial", false)
	runtime.GOMAXPROCS(2)
	parallel := runColumnPublish(t, dir, root, pair, "5", "parallel", false)
	if !reflect.DeepEqual(plain.CanonicalAndCompanionSHA, serial.CanonicalAndCompanionSHA) ||
		!reflect.DeepEqual(serial.OutputRefs, parallel.OutputRefs) || serial.OutputBytes != parallel.OutputBytes {
		t.Fatal("actual compactor changed canonical, companion or physical bytes")
	}
}
