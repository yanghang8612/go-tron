"""Verify staged upload, then start/recover only this bounded private lab unit."""
import datetime
import hashlib
import io
import json
import os
import pathlib
import subprocess
import zipfile

P = pathlib.Path('/data/gtron/history-columns-ordered-pages-20261026-01')
UNIT = 'gtron-columns-ordered-pages-native-20261026-01.service'
EXPECTED = '9d13efb13254af1db243d949ee391c9446d939738c2159df622724836ab4a031'
sha = lambda b: hashlib.sha256(b).hexdigest()
plan = json.loads((P/'native-upload-plan.json').read_text())
assert plan['sha256'] == EXPECTED and plan['bytes'] == 244147
pieces = []
for part in plan['chunks']:
    data = (P/'upload-parts'/'part-{:03d}'.format(part['index'])).read_bytes()
    assert len(data) == part['bytes'] and sha(data) == part['sha256']
    pieces.append(data)
data = b''.join(pieces)
assert len(data) == plan['bytes'] and sha(data) == EXPECTED


def immutable_write(path, content):
    if path.exists():
        assert path.is_file() and path.read_bytes() == content, 'different existing staged file'
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('xb') as f:
            f.write(content)
            f.flush()
            os.fsync(f.fileno())


immutable_write(P/'native-source-payload.zip', data)
with zipfile.ZipFile(io.BytesIO(data)) as z:
    assert z.testzip() is None and len(z.namelist()) == plan['members']
    assert len(z.namelist()) == len(set(z.namelist()))
    manifest = json.loads(z.read('payload-manifest.json'))
    assert set(z.namelist()) == set(manifest) | {'payload-manifest.json'}
    for name, expected in manifest.items():
        path = pathlib.PurePosixPath(name)
        assert not path.is_absolute() and '..' not in path.parts
        value = z.read(name)
        assert sha(value) == expected
        immutable_write(P/name, value)
    immutable_write(P/'payload-manifest.json', z.read('payload-manifest.json'))
identity = json.loads((P/'encoder-identity.json').read_text())
assert identity['source_commit'] == plan['source_commit'] and identity['target_source_files'] == 2149


def show(unit):
    fields = ['LoadState', 'ActiveState', 'SubState', 'MainPID', 'ExecMainStatus', 'MemoryLimit', 'CPUQuotaPerSecUSec', 'Nice']
    args = ['systemctl', 'show', unit]
    for name in fields:
        args += ['-p', name]
    result = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True)
    return {line.split('=', 1)[0]: line.split('=', 1)[1] for line in result.stdout.splitlines() if '=' in line}


before = show(UNIT)
prod_before = show('gtron.service')
dispatch = dict(unit=UNIT, payload_sha256=EXPECTED, source_commit=identity['source_commit'], production_mutations=False,
                utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
if before.get('LoadState') == 'not-found':
    immutable_write(P/'native-dispatch.json', (json.dumps(dispatch, sort_keys=True, indent=2)+'\n').encode())
    result = subprocess.run(['systemd-run', '--unit='+UNIT, '--description=Isolated history encoder checks and same-input publication comparison',
                             '--property=MemoryLimit=4G', '--property=CPUQuota=200%', '--property=Nice=15',
                             '/usr/bin/ionice', '-c3', '/usr/bin/python3', str(P/'prepare-native.py')],
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True)
    immutable_write(P/'native-dispatch-output.txt', result.stdout.encode())
    assert result.returncode == 0, result.stdout
    dispatched = True
else:
    existing = json.loads((P/'native-dispatch.json').read_text())
    assert existing['unit'] == UNIT and existing['payload_sha256'] == EXPECTED
    # A known existing unit is observed, never automatically restarted.
    dispatched = False
after = show(UNIT)
pid = int(after.get('MainPID', '0'))
receipt = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), unit=UNIT, dispatched_now=dispatched,
               payload_bytes=len(data), payload_sha256=EXPECTED, source_commit=identity['source_commit'],
               target_source_files=2149, changed_source_files=5, systemctl=after,
               pid=pid, proc_exists=bool(pid and pathlib.Path('/proc/'+str(pid)).exists()), production_mutations=False,
               production_identity_before=prod_before, production_identity_after=show('gtron.service'),
               scope='Only a new bounded private native-check unit. It waits for the separate frozen acceptance/publication; no production unit or database mutation.')
if pid:
    receipt['ps'] = subprocess.check_output(['ps', '-o', 'pid,ppid,etimes,pcpu,rss,args', '-p', str(pid), '--ppid', str(pid)], universal_newlines=True)
(P/'native-start-receipt.json').write_text(json.dumps(receipt, sort_keys=True, indent=2)+'\n')
print('NATIVE_ENCODER_UNIT_READY', UNIT, pid)
