import pathlib,zipfile,json,io,hashlib,base64
p=pathlib.Path('/data/gtron/history-columns-ordered-pages-20261026-01');sha=lambda b:hashlib.sha256(b).hexdigest()
full=(p/'publication-complete.zip').read_bytes();assert sha(full)=='6d922f4c5d5fd3acbbf13aab7f4858343eb23876a4ed2ca4e233c63e5cacbd41'
with zipfile.ZipFile(io.BytesIO(full)) as z:
 assert z.testzip() is None
 original_manifest=z.read('evidence-manifest.json');m=json.loads(original_manifest);items={n:z.read(n) for n in m};assert all(sha(items[n])==h for n,h in m.items())
raw=items.pop('frozen-original-plan.json');assert sha(raw)=='177f2407b5af8584cf5f982466df60206d3ee8be3dd176cf2aebcb96f86bf78c';plan=json.loads(raw);selected=(json.dumps(dict(selected=plan['selected']),sort_keys=True,indent=2)+'\n').encode();assert len(plan['selected'])==3
items['frozen-original-plan-selected.json']=selected;items['full-evidence-manifest.json']=original_manifest
items['unmeasured-plan-provenance.json']=(json.dumps(dict(full_original_plan_bytes=len(raw),full_original_plan_sha256=sha(raw),selected_count=3,selected_sha256=sha(selected),full_evidence_archive_bytes=len(full),full_evidence_archive_sha256=sha(full),full_original_plan_retained_on_server=True,full_original_plan_raw_in_this_core_archive=False),sort_keys=True,indent=2)+'\n').encode()
items['evidence-manifest.json']=(json.dumps({n:sha(b) for n,b in items.items()},sort_keys=True,indent=2)+'\n').encode();out=io.BytesIO()
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for n,b in sorted(items.items()):
  i=zipfile.ZipInfo(n,date_time=(2026,10,26,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16;z.writestr(i,b)
b=out.getvalue();q=p/'publication-core.zip';assert not q.exists() or q.read_bytes()==b;q.write_bytes(b) if not q.exists() else None
r=dict(name=q.name,bytes=len(b),sha256=sha(b),members=len(items));(p/'core-evidence-seal.json').write_text(json.dumps(dict(complete=True,seals=[r],production_mutations=False),sort_keys=True,indent=2)+'\n')
