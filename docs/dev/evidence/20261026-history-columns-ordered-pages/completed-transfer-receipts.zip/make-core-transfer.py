"""Create bounded, checksummed UI transfer packets from completed evidence ZIPs."""
import hashlib
import io
import json
import pathlib
import zipfile
import base64

P = pathlib.Path('/data/gtron/history-columns-ordered-pages-20261026-01')
sha = lambda b: hashlib.sha256(b).hexdigest()
seals = json.loads((P/'core-evidence-seal.json').read_text())
assert seals['complete']
expected = {r['name']:r for r in seals['seals']}


def immutable(path, data):
    if path.exists():
        assert path.read_bytes() == data
    else:
        with path.open('xb') as f:
            f.write(data)


for tag,name in [('core','publication-core.zip')]:
    p = P/name
    a = p.stat()
    data = p.read_bytes()
    assert 0 < len(data) < 4 << 20 and len(data) == expected[name]['bytes'] and sha(data) == expected[name]['sha256']
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        assert z.testzip() is None and len(z.namelist()) == expected[name]['members']
        m = json.loads(z.read('evidence-manifest.json'))
        assert set(z.namelist()) == set(m) | {'evidence-manifest.json'}
        assert all(sha(z.read(n)) == h for n,h in m.items())
    meta = dict(archive=name, archive_bytes=len(data), archive_sha256=sha(data), device=str(a.st_dev), inode=str(a.st_ino), mtime_ns=str(a.st_mtime_ns))
    count = 0
    for i,offset in enumerate(range(0,len(data),4096)):
        part = data[offset:offset+4096]
        row = dict(meta, index=i, offset=offset, bytes=len(part), part_sha256=sha(part), data_b64=base64.b64encode(part).decode())
        raw = (json.dumps(row,sort_keys=True,separators=(',',':'))+'\n').encode()
        assert len(raw) <= 6144
        immutable(P/('download-%s-%03d.json'%(tag,i)), raw)
        count += 1
    b = p.stat()
    assert (a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns) == (b.st_dev,b.st_ino,b.st_size,b.st_mtime_ns)
    plan = dict(meta, chunks=count, chunk_bytes=4096, archive_members=expected[name]['members'], production_mutations=False)
    immutable(P/('download-%s-plan.json'%tag), (json.dumps(plan,sort_keys=True,indent=2)+'\n').encode())
print('ORDERED_EVIDENCE_TRANSFER_READY')
