"""Final-binary fixed-copy acceptance, invoked only after publication assessment."""
import datetime
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import time
import traceback

P = pathlib.Path('/data/gtron/history-columns-ordered-pages-20261026-01')
OLD = pathlib.Path('/data/gtron/history-record-columns-container-20261026-01')
PREV = pathlib.Path('/data/gtron/history-account-delta-20261025-01')
S = P/'candidate-source'
state = dict(complete=False, production_mutations=False, all_old_files_retained=True,
             scope='Final ordered-page binary on private metadata replicas of the identical fixed ordinary/V5 capture. Existing V5 input bytes are reused; real new writer outputs are separately SHA/canonical verified. Full latest/head snapshot export/import is not claimed.')


def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for value in iter(lambda: f.read(4 << 20), b''):
            h.update(value)
    return h.hexdigest()


def identity():
    text = subprocess.check_output(['systemctl', 'show', 'gtron', '-p', 'MainPID', '-p', 'ActiveState'], universal_newlines=True)
    x = dict(line.split('=', 1) for line in text.splitlines() if '=' in line)
    pid = int(x['MainPID'])
    x['start_ticks'] = pathlib.Path('/proc/%d/stat'%pid).read_text().split(') ', 1)[1].split()[19] if pid else None
    x['binary_sha256'] = sha(pathlib.Path('/proc/%d/exe'%pid)) if pid else None
    return x


def save():
    state['utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    q = P/'acceptance-status.json.tmp'
    q.write_text(json.dumps(state, sort_keys=True, indent=2)+'\n')
    os.replace(str(q), str(P/'acceptance-status.json'))


def run(label, args, env, timeout):
    assert identity() == state['before_identity'], 'production identity changed externally'
    state['phase'] = label
    save()
    start = time.monotonic()
    with (P/(label+'.log')).open('xb') as f:
        result = subprocess.run(args, cwd=str(S), env=env, stdout=f, stderr=subprocess.STDOUT, timeout=timeout)
    state.setdefault('checks', []).append(dict(label=label, seconds=time.monotonic()-start, returncode=result.returncode, log_sha256=sha(P/(label+'.log'))))
    save()
    assert result.returncode == 0, label+' failed; inspect preserved log'
    assert identity() == state['before_identity'], 'production identity changed externally'


def source_check():
    inv = json.loads((P/'source-inventory.json').read_text())
    extra = json.loads((P/'inherited-extra-go-inventory.json').read_text())
    assert len(inv) == 2149 and len(extra) == 24
    assert all(sha(S/n) == h for n,h in inv.items())
    assert all(sha(S/n) == h for n,h in extra.items())
    return dict(product_files=len(inv), inherited_go_files=len(extra), inventory_sha256=sha(P/'source-inventory.json'), inherited_sha256=sha(P/'inherited-extra-go-inventory.json'))


def replica(source, dest):
    source = source.resolve()
    assert not dest.exists()
    dest.mkdir()
    copies = links = copied_bytes = 0
    for directory, dirs, files in os.walk(str(source), followlinks=True):
        rel = pathlib.Path(directory).relative_to(source)
        (dest/rel).mkdir(exist_ok=True)
        for name in files:
            if name in ('LOCK', 'FLOCK'):
                continue
            a = (pathlib.Path(directory)/name).resolve()
            b = dest/rel/name
            before = a.stat()
            if a.suffix in ('.sst', '.seg', '.idx', '.kv', '.route', '.gtv2') or rel.parts[:1] == ('ancient',):
                os.link(str(a), str(b))
                links += 1
            else:
                copied_bytes += before.st_size
                assert copied_bytes < 8 << 30, 'private mutable metadata volume exceeded'
                shutil.copy2(str(a), str(b))
                copies += 1
                assert (before.st_dev, before.st_ino) != (b.stat().st_dev, b.stat().st_ino)
            after = a.stat()
            assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
    return dict(source=str(source), immutable_links=links, private_copies=copies, private_copy_bytes=copied_bytes)


def fingerprint(root):
    out = {}
    for p in sorted((root/'chaindata').iterdir()):
        if not p.is_file() or not (p.suffix in ('.sst', '.log') or p.name == 'CURRENT' or p.name.startswith(('MANIFEST-', 'OPTIONS-'))):
            continue
        a = p.stat()
        h = sha(p)
        b = p.stat()
        assert (a.st_dev, a.st_ino, a.st_size, a.st_mtime_ns) == (b.st_dev, b.st_ino, b.st_size, b.st_mtime_ns)
        out[p.name] = dict(inode=str(a.st_ino), device=str(a.st_dev), bytes=a.st_size, mtime_ns=str(a.st_mtime_ns), sha256=h)
    assert len(out) == 803
    return out


try:
    assert not (P/'acceptance-status.json').exists(), 'do not repeat an acceptance run'
    native = json.loads((P/'native-status.json').read_text())
    publish = json.loads((P/'publish-status.json').read_text())
    assert native['complete'] and len(native['checks']) == 10 and all(r['returncode'] == 0 for r in native['checks'])
    assert publish['complete'] and publish['timed_samples'] == 48 and not publish.get('error')
    unit = subprocess.check_output(['systemctl', 'show', 'gtron-columns-ordered-pages-native-20261026-01.service', '-p', 'MainPID', '-p', 'ActiveState', '-p', 'ExecMainStatus'], universal_newlines=True)
    assert set(unit.splitlines()) == {'MainPID=0', 'ActiveState=inactive', 'ExecMainStatus=0'}, 'native/publication unit still running or failed'
    assert shutil.disk_usage('/data').free > 100*10**9
    state['before_identity'] = identity()
    state['source_before'] = source_check()
    state['native_status_sha256'] = sha(P/'native-status.json')
    state['publish_status_sha256'] = sha(P/'publish-status.json')
    state['phase'] = 'private-input-replicas'
    save()
    state['replicas'] = {mode:replica(src, P/(mode+'-input')) for mode,src in [('baseline', PREV/'baseline-input'), ('candidate', OLD/'candidate-input')]}
    state['baseline_binary_sha256'] = sha(PREV/'baseline.test')
    assert state['baseline_binary_sha256'] == 'fff5e1dd9f51fdaa3fb25f5a93d73147178403890e95bdc5a0fb32d9b741d4bf'
    assert sha(P/'ordered-http.test') == native['binaries']['ordered-http.test']
    assert sha(P/'ordered-snapshots.test') == native['binaries']['ordered-snapshots.test']
    state['candidate_binary_sha256'] = native['binaries']['ordered-http.test']
    state['http_harness_sha256'] = sha(S/'core/offline_fixed_http_test.go')
    assert state['http_harness_sha256'] == '10e6015af7666bf83b5c405543681c368b7537f428b8278a3344f0312aacd3bf'
    os.link(str(PREV/'baseline.test'), str(P/'baseline.test'))
    os.link(str(P/'ordered-http.test'), str(P/'candidate.test'))
    (P/'capture-status.json').write_text(json.dumps(dict(complete=True, method='private metadata replicas with immutable file hardlinks', input_capture_sha256=sha(OLD/'capture-status.json'), production_mutations=False), sort_keys=True)+'\n')
    before = {mode:fingerprint(P/(mode+'-input')) for mode in ('baseline', 'candidate')}
    (P/'chaindata-before.json').write_text(json.dumps(before, sort_keys=True, indent=2)+'\n')
    env = {k:v for k,v in os.environ.items() if not k.startswith('GTRON_')}
    env.update(PATH='/data/go/bin:'+env.get('PATH',''), GOCACHE='/root/.cache/go-build', GOPATH='/root/go', GOTOOLCHAIN='local', CGO_ENABLED='1', GOMAXPROCS='2', GOMEMLIMIT='3GiB', GTRON_FIXED_INPUT=str(P/'candidate-input'), GTRON_FIXED_CENSUS=str(P/'muhash-census.json'), GTRON_ROUTING_ROOT=str(P))
    run('full-muhash', [str(P/'candidate.test'), '-test.run=^TestOfflineRequestFixedMuHash$', '-test.v', '-test.timeout=40m'], env, 2450)
    census = json.loads((P/'muhash-census.json').read_text())
    assert census['complete'] and census['muhash_verified'] and census['block_num'] == 11818192 and census['tx_num'] == 601386177
    assert bytes(census['muhash_root']).hex() == '8fbf149684146a59b1650b318a768f0edbae0c8c1c3ceb2c5c610129c10f76a5'
    assert census['source_rows'] == [3484117, 481, 141418493]
    state['muhash_verified'] = True
    run('history-restore', [str(P/'ordered-snapshots.test'), '-test.run=^TestOfflineAccountHistoryRestore$', '-test.v', '-test.timeout=30m'], env, 1850)
    assert json.loads((P/'history-restore.json').read_text())['complete']
    run('full-http-comparison', ['/usr/bin/python3', str(P/'compare-ordered.py'), 'tail-read'], env, 10800)
    compare = json.loads((P/'tail-read-comparison/comparison-status.json').read_text())
    assert compare['complete'] and compare['requests'] == 286 and compare['all_responses_correct'] and not compare['environment_identity_changed']
    after = {mode:fingerprint(P/(mode+'-input')) for mode in ('baseline', 'candidate')}
    (P/'chaindata-after.json').write_text(json.dumps(after, sort_keys=True, indent=2)+'\n')
    assert before == after
    state['source_after'] = source_check()
    assert state['source_before'] == state['source_after']
    assert sha(P/'ordered-http.test') == native['binaries']['ordered-http.test']
    assert sha(P/'ordered-snapshots.test') == native['binaries']['ordered-snapshots.test']
    state.update(complete=True, phase='complete', chaindata_full_sha_unchanged=True, fingerprint_files_per_mode=803, full_http_requests=286, actual_history_restore_blocks=60, full_latest_snapshot_export_import_performed=False, after_identity=identity())
    assert state['before_identity'] == state['after_identity']
    save()
except BaseException as error:
    state.update(phase='failed', error=repr(error), traceback=traceback.format_exc())
    save()
    raise
