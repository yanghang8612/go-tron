"""One-shot, overlay-only decoder comparison on the frozen three-file cohort."""
import datetime
import hashlib
import json
import os
import pathlib
import resource
import statistics
import subprocess
import tarfile
import time
import traceback

P=pathlib.Path('/data/gtron/history-shared-decoder-20261026-02')
OLD=pathlib.Path('/data/gtron/history-columns-shared-payload-20261026-03')
SOURCE=pathlib.Path('/data/gtron/history-columns-ordered-pages-20261026-01/candidate-source')
ARMS=['v5-fresh','reference-fresh','scratch-fresh','v5-reused','reference-reused','scratch-reused']
state={'complete':False,'production_mutations':False,'checks':[],
       'scope':'Resident page decoder comparison only; no physical format, publication, HTTP, MuHash or restoration acceptance.'}

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(4<<20),b''):h.update(b)
 return h.hexdigest()

def write(name,value):
 with (P/name).open('x') as f:f.write(json.dumps(value,sort_keys=True,indent=2)+'\n')

def save():
 state['utc']=datetime.datetime.utcnow().isoformat()+'Z'
 q=P/'study-status.json.tmp';q.write_text(json.dumps(state,sort_keys=True,indent=2)+'\n');os.replace(str(q),str(P/'study-status.json'))

def identity():
 s=subprocess.check_output(['systemctl','show','gtron','-p','MainPID','-p','ActiveState'],universal_newlines=True)
 d=dict(x.split('=',1) for x in s.splitlines());pid=int(d['MainPID'])
 d['start_ticks']=pathlib.Path('/proc/%d/stat'%pid).read_text().split(') ',1)[1].split()[19] if pid else None
 return d

def inventory():
 out={}
 for base,ds,fs in os.walk(str(SOURCE)):
  ds[:]=[n for n in ds if n not in ('.git','build','target')]
  for n in fs:
   if n.endswith('.go') or n in ('go.mod','go.sum'):
    p=pathlib.Path(base)/n;out[str(p.relative_to(SOURCE))]=sha(p)
 return out

def run(label,args,env,timeout):
 assert identity()==state['production_before'],'production identity changed externally'
 state['phase']=label;save();print('BEGIN',label,flush=True)
 start=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (P/(label+'.log')).open('xb') as f:
  r=subprocess.run(args,cwd=str(SOURCE),env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 after=resource.getrusage(resource.RUSAGE_CHILDREN)
 state['checks'].append({'label':label,'args':args,'returncode':r.returncode,'seconds':time.monotonic()-start,
                         'cpu_seconds':after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,'log_sha256':sha(P/(label+'.log'))})
 save();assert r.returncode==0,label+' failed; original log retained'
 assert identity()==state['production_before'],'production identity changed externally'
 print('DONE',label,round(state['checks'][-1]['seconds'],3),flush=True)

try:
 assert not (P/'decoder-pages.jsonl').exists()
 previous=pathlib.Path('/data/gtron/history-shared-decoder-20261026-01');failed=json.loads((previous/'study-status.json').read_text());assert failed['phase']=='failed' and 'TimeoutExpired' in failed['error']
 state['retry_context']={'previous_lab':str(previous),'previous_status_sha256':sha(previous/'study-status.json'),'cache':str(previous/'go-build'),'change':'Longer build deadlines only; algorithms, test cases, cohort, CPU and memory budgets unchanged.'}
 write('previous-attempt-status.json',failed)
 state['production_before']=identity();pid=int(state['production_before']['MainPID'])
 state['production_binary_sha256']=sha(pathlib.Path('/proc/%d/exe'%pid)) if pid else None
 old_status=json.loads((OLD/'study-status.json').read_text());assert old_status['complete']
 old_files=['study-status.json','pages.jsonl','selected-inputs.json','offline_shared_payload_test.go','frozen-source-inventory.json','study-core.tar.xz']
 state['prior_fingerprints']={n:sha(OLD/n) for n in old_files}
 assert state['prior_fingerprints']['study-core.tar.xz']=='1f1148ee9885c9efcc793ac3058826b5029fe77f7b9941b83c5f456864bd03c5'
 assert sha(P/'reference-pages.jsonl')==old_status['pages_sha256']==sha(OLD/'pages.jsonl')
 assert sha(P/'offline_shared_payload_test.go')=='86378ea65aa3685f1752be89847a3ac39affb42f31e36b956873463ccef7773c'
 state['helpers']={n:sha(P/n) for n in ['offline_shared_payload_test.go','offline_shared_scratch_test.go','offline_shared_decoder_test.go','run-study.py']}
 expected=json.loads((OLD/'frozen-source-inventory.json').read_text())
 assert len(expected)==2149 and sha(OLD/'frozen-source-inventory.json')=='3281b8fcd833df0066efba23ac68c6ed329f9a1534ea5be5c75002655b6e9150'
 before=inventory();assert len(before)==2173 and all(before.get(n)==v for n,v in expected.items())
 write('source-before.json',before)
 lib=SOURCE/'third_party/librustzcash/target/release/librustzcash.a';state['sapling_sha256']=sha(lib)
 assert state['sapling_sha256']=='b6c99f8fabac36d5a836c644bb79059449c89740bf33670d66088d094447e7ea'
 inputs=json.loads((P/'selected-inputs.json').read_text());assert [x['pair'] for x in inputs]==[458,2309,4147]
 assert inputs==json.loads((OLD/'selected-inputs.json').read_text())
 for x in inputs:
  q=pathlib.Path(x['path']);assert q.stat().st_size==x['size'] and sha(q)==x['sha256']
 write('inputs-before.json',inputs)
 pairs=[('offline_shared_payload_study_test.go','offline_shared_payload_test.go'),('offline_shared_scratch_study_test.go','offline_shared_scratch_test.go'),('offline_shared_decoder_study_test.go','offline_shared_decoder_test.go')]
 write('overlay.json',{'Replace':{str(SOURCE/'core/state/snapshots'/a):str(P/b) for a,b in pairs}})
 env={k:v for k,v in os.environ.items() if not k.startswith('GTRON_')}
 env.update(PATH='/data/go/bin:'+env.get('PATH',''),GOCACHE='/data/gtron/history-shared-decoder-20261026-01/go-build',GOPATH='/root/go',GOMODCACHE='/root/go/pkg/mod',GOMAXPROCS='2',GOMEMLIMIT='3GiB',GOTOOLCHAIN='local',CGO_ENABLED='1')
 write('effective-go-env.json',{k:env[k] for k in ['PATH','GOCACHE','GOPATH','GOMODCACHE','GOMAXPROCS','GOMEMLIMIT','GOTOOLCHAIN','CGO_ENABLED']})
 state['go_version']=subprocess.check_output(['/data/go/bin/go','version'],env=env,universal_newlines=True).strip()
 assert state['go_version']=='go version go1.25.5 linux/amd64'
 common=['/data/go/bin/go','test','-overlay',str(P/'overlay.json')]
 cases='^TestOfflineShared(PayloadBounds|ScratchBoundsAndReuse|ScratchConcurrentOwnership|DecoderArmParity)$'
 run('native-bounds',common+['./core/state/snapshots','-run',cases,'-count=1','-v','-timeout=240s'],env,3600)
 run('native-race',common+['-race','./core/state/snapshots','-run',cases,'-count=1','-v','-timeout=240s'],env,3600)
 run('native-build',common+['-c','./core/state/snapshots','-o',str(P/'decoder-study.test')],env,1800)
 state['binary_sha256']=sha(P/'decoder-study.test')
 (P/'binary-build-info.txt').write_bytes(subprocess.check_output(['/data/go/bin/go','version','-m',str(P/'decoder-study.test')],env=env))
 state['load_before']=pathlib.Path('/proc/loadavg').read_text();state['mem_before']=pathlib.Path('/proc/meminfo').read_text()
 run('real-pages',[str(P/'decoder-study.test'),'-test.run=^TestOfflineSharedDecoderRealPages$','-test.v','-test.timeout=15m'],dict(env,GTRON_SHARED_DECODER_STUDY=str(P)),1000)
 state['load_after']=pathlib.Path('/proc/loadavg').read_text();state['mem_after']=pathlib.Path('/proc/meminfo').read_text()
 rows=[json.loads(x) for x in (P/'decoder-pages.jsonl').read_text().splitlines()]
 oracle={(x['Pair'],x['Page']):x for x in (json.loads(s) for s in (P/'reference-pages.jsonl').read_text().splitlines())}
 assert len(rows)==len(oracle)==1817 and len({(x['Pair'],x['Page']) for x in rows})==1817
 summary=[]
 for pair in [458,2309,4147,'all']:
  part=[x for x in rows if pair=='all' or x['Pair']==pair];timings={}
  for name in ARMS:
   metrics={}
   for field in ['Nanoseconds','Allocated','Mallocs','GC']:
    totals=[sum(x['Arms'][name][field][i] for x in part) for i in range(5)]
    metrics[field]={'round_totals':totals,'median_per_pass':statistics.median(totals)/8}
   metrics['retained_scratch_max']=max(x['Arms'][name]['RetainedScratchMax'] for x in part)
   timings[name]=metrics
  summary.append({'pair':pair,'pages':len(part),'original_bytes':sum(x['OriginalBytes'] for x in part),'prototype_bytes':sum(x['PrototypeBytes'] for x in part),'arms':timings})
 for x in rows:
  ref=oracle[(x['Pair'],x['Page'])]
  for k in ['RawBytes','OriginalBytes','PrototypeBytes','OriginalMode','RawSHA','OriginalSHA','PrototypeSHA','AnnotationsRecovered']:assert x[k]==ref[k]
  assert x['Batch']==8 and x['Rounds']==5 and sorted(x['Arms'])==sorted(ARMS)
  assert all(v['RetainedScratchMax']<=131108 for v in x['Arms'].values())
 write('summary.json',summary)
 assert inventory()==before;write('source-after.json',inventory())
 assert sha(lib)==state['sapling_sha256'] and all(sha(P/n)==h for n,h in state['helpers'].items())
 assert all(sha(OLD/n)==h for n,h in state['prior_fingerprints'].items())
 assert all(sha(pathlib.Path(x['path']))==x['sha256'] for x in inputs);write('inputs-after.json',inputs)
 state.update(complete=True,phase='complete',pages=len(rows),plain_pages=sum(not x['AnnotationsRecovered'] for x in rows),pages_sha256=sha(P/'decoder-pages.jsonl'),summary_sha256=sha(P/'summary.json'),production_after=identity())
 assert state['production_after']==state['production_before']
 assert not pid or sha(pathlib.Path('/proc/%d/exe'%pid))==state['production_binary_sha256']
 save()
 members={p.name:sha(p) for p in P.iterdir() if p.is_file() and p.suffix not in ('.test','.xz') and p.name not in ('archive-seal.json','archive-members.json')}
 write('archive-members.json',members)
 archive=P/'decoder-study-core.tar.xz'
 with tarfile.open(str(archive),'w:xz') as t:
  for n in sorted(list(members)+['archive-members.json']):t.add(str(P/n),arcname=n,recursive=False)
 write('archive-seal.json',{'bytes':archive.stat().st_size,'sha256':sha(archive),'members':len(members)+1,'complete':True,'production_mutations':False})
 print('DECODER_STUDY_COMPLETE',sha(archive),archive.stat().st_size,flush=True)
except BaseException as error:
 state.update(phase='failed',error=repr(error),traceback=traceback.format_exc());save();raise
