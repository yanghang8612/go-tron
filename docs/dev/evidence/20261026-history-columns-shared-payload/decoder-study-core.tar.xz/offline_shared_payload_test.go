package snapshots

// Overlay-only page experiment. HSP1 is deliberately not a registered physical
// format: no product writer, reader, policy, manifest, or CLI can emit it.
import (
	"bytes"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"math"
	"os"
	"path/filepath"
	"testing"
	"time"

	"github.com/klauspost/compress/zstd"
)

const sharedStudyHeader = 48

type sharedStudyEncoder struct {
	columns                              recordColumnPageEncoder
	tail, key, ordinary, best, candidate []byte
}

type sharedStudyCosts struct {
	Ordinary   int    `json:"ordinary"`
	Candidates [3]int `json:"candidates"`
	Keys       [3]int `json:"keys"`
	Tail       int    `json:"tail"`
	Selected   int    `json:"selected"` // -1 = ordinary; 0..2 = key representation
}

func (e *sharedStudyEncoder) pack(mode int) []byte {
	h := e.columns.header[:]
	need := 1 + sharedStudyHeader + len(e.key) + len(e.tail)
	if cap(e.candidate) < need {
		e.candidate = make([]byte, need)
	} else {
		e.candidate = e.candidate[:need]
	}
	p := e.candidate
	p[0] = 2
	copy(p[1:37], h)
	copy(p[1:5], "HSP1")
	binary.BigEndian.PutUint32(p[17:21], uint32(len(e.columns.keys[mode])))
	binary.BigEndian.PutUint32(p[29:33], uint32(mode))
	binary.BigEndian.PutUint32(p[37:41], uint32(len(e.key)))
	binary.BigEndian.PutUint32(p[41:45], uint32(e.columns.packedBytes-e.columns.tailStart))
	binary.BigEndian.PutUint32(p[45:49], uint32(len(e.tail)))
	at := 49 + copy(p[49:], e.key)
	copy(p[at:], e.tail)
	return p
}

func (e *sharedStudyEncoder) encode(raw []byte, starts []uint32, enc *zstd.Encoder) ([]byte, sharedStudyCosts, error) {
	c := sharedStudyCosts{Selected: -1}
	if len(raw) == 0 || len(raw) > historyRecordColumnPageMax {
		return nil, c, errHistoryRecordColumns
	}
	e.ordinary = recordColumnEncodeTo(enc, raw, e.ordinary, 0)
	c.Ordinary = len(e.ordinary)
	e.best = append(e.best[:0], e.ordinary...)
	if len(starts) == 0 {
		return e.best, c, nil
	}
	if err := e.columns.prepare(raw, starts); err != nil {
		return nil, c, err
	}
	common := e.columns.packed[e.columns.tailStart:e.columns.packedBytes]
	e.tail = enc.EncodeAll(common, e.tail[:0])
	c.Tail = len(e.tail)
	for mode := 0; mode < 3; mode++ {
		e.key = enc.EncodeAll(e.columns.keys[mode], e.key[:0])
		c.Keys[mode] = len(e.key)
		c.Candidates[mode] = 1 + sharedStudyHeader + len(e.key) + len(e.tail)
		if c.Candidates[mode] < len(e.best) {
			e.candidate = e.pack(mode)
			e.best, e.candidate = e.candidate, e.best
			c.Selected = mode
		}
	}
	return e.best, c, nil
}

func decodeSharedStudy(p []byte, expected uint64, dst []byte) ([]byte, error) {
	if expected == 0 || expected > historyRecordColumnPageMax || len(p) < 2 || len(p) > historyRecordColumnStoredMax {
		return nil, errHistoryRecordColumns
	}
	if p[0] == 0 {
		out, _, err := decodeRecordColumnStoredPage(p, expected, dst, nil)
		return out, err
	}
	if p[0] != 2 || len(p) < 49 || string(p[1:5]) != "HSP1" {
		return nil, errHistoryRecordColumns
	}
	h := p[1:49]
	get := func(at int) uint64 { return uint64(binary.BigEndian.Uint32(h[at : at+4])) }
	n, count, first, kl, tl, ll, mode := get(4), get(8), get(12), get(16), get(20), get(24), get(28)
	kc, tail, tc := get(36), get(40), get(44)
	flags := (count + 7) / 8
	// All arithmetic is uint64; all operands come from bounded uint32 fields.
	if n != expected || count == 0 || count > n/21 || first > n-21 || mode > 2 ||
		kl < count || kl > 5*count || mode == 2 && kl != 4*count ||
		tl < count || tl > 10*count || ll < count || ll > 5*count ||
		tail != tl+ll+flags+n-21*count || kl+tail > n ||
		kc < 1 || tc < 1 || kc > 2*kl+256 || tc > 2*tail+256 || 49+kc+tc != uint64(len(p)) {
		return nil, errHistoryRecordColumns
	}
	dec, err := recordColumnCodecDecoder()
	if err != nil {
		return nil, err
	}
	// Exact output capacities bound decompression even for malicious frame FCS.
	keys, err := dec.DecodeAll(p[49:49+kc], make([]byte, 0, int(kl)))
	if err != nil || uint64(len(keys)) != kl {
		return nil, errHistoryRecordColumns
	}
	common, err := dec.DecodeAll(p[49+kc:], make([]byte, 0, int(tail)))
	if err != nil || uint64(len(common)) != tail {
		return nil, errHistoryRecordColumns
	}
	transformed := make([]byte, historyRecordColumnHeader, int(36+kl+tail))
	copy(transformed, h[:36])
	copy(transformed, "HRC2")
	transformed = append(transformed, keys...)
	transformed = append(transformed, common...)
	return decodeHistoryRecordColumns(transformed, expected, dst)
}

func forceSharedStudy(raw []byte, starts []uint32, enc *zstd.Encoder, mode int) ([]byte, error) {
	var e sharedStudyEncoder
	if err := e.columns.prepare(raw, starts); err != nil {
		return nil, err
	}
	e.tail = enc.EncodeAll(e.columns.packed[e.columns.tailStart:e.columns.packedBytes], nil)
	e.key = enc.EncodeAll(e.columns.keys[mode], nil)
	return bytes.Clone(e.pack(mode)), nil
}

func TestOfflineSharedPayloadBounds(t *testing.T) {
	enc, _, err := cbCodec()
	if err != nil {
		t.Fatal(err)
	}
	var reusable sharedStudyEncoder
	for seed := int64(0); seed < 80; seed++ {
		raw, starts := recordColumnEncoderPage(seed, []int{21, 127, 4096, 65535, historyRecordColumnPageMax}[seed%5])
		before := bytes.Clone(raw)
		if len(starts) > 0 {
			for mode := 0; mode < 3; mode++ {
				p, err := forceSharedStudy(raw, starts, enc, mode)
				if err != nil {
					t.Fatal(err)
				}
				out, err := decodeSharedStudy(p, uint64(len(raw)), nil)
				if err != nil || !bytes.Equal(out, raw) {
					t.Fatalf("seed %d mode %d: %v", seed, mode, err)
				}
			}
		}
		for _, offsets := range [][]uint32{starts, nil} {
			p, costs, err := reusable.encode(raw, offsets, enc)
			if err != nil {
				t.Fatal(err)
			}
			out, err := decodeSharedStudy(p, uint64(len(raw)), nil)
			if err != nil || !bytes.Equal(out, raw) || !bytes.Equal(raw, before) || len(p) > costs.Ordinary {
				t.Fatal("fallback/ownership", err)
			}
			if len(offsets) == 0 && (p[0] != 0 || costs.Selected != -1) {
				t.Fatal("unannotated page inferred columns")
			}
		}
	}
	// Opaque value and incomplete header bytes crossing either page boundary.
	for prefix := 0; prefix < 21; prefix++ {
		raw := bytes.Repeat([]byte{0x97}, prefix)
		raw = binary.BigEndian.AppendUint32(raw, math.MaxUint32)
		raw = binary.BigEndian.AppendUint32(raw, math.MaxUint32)
		raw = binary.BigEndian.AppendUint64(raw, math.MaxUint64)
		raw = append(raw, 1)
		raw = binary.BigEndian.AppendUint32(raw, math.MaxUint32-17)
		raw = append(raw, bytes.Repeat([]byte{0xff}, 63)...)
		for mode := 0; mode < 3; mode++ {
			p, err := forceSharedStudy(raw, []uint32{uint32(prefix)}, enc, mode)
			if err != nil {
				t.Fatal(err)
			}
			out, err := decodeSharedStudy(p, uint64(len(raw)), nil)
			if err != nil || !bytes.Equal(out, raw) {
				t.Fatal("fragment boundary", err)
			}
		}
	}
	for _, raw := range [][]byte{nil, make([]byte, historyRecordColumnPageMax+1)} {
		if _, _, err := reusable.encode(raw, nil, enc); err == nil {
			t.Fatal("encode length bound")
		}
	}
	raw, starts := recordColumnEncoderPage(12, 4096)
	p, err := forceSharedStudy(raw, starts, enc, 0)
	if err != nil {
		t.Fatal(err)
	}
	for i := 0; i < len(p); i++ {
		if _, err := decodeSharedStudy(p[:i], uint64(len(raw)), nil); err == nil {
			t.Fatal("truncation", i)
		}
	}
	for _, expected := range []uint64{0, uint64(len(raw) - 1), historyRecordColumnPageMax + 1, math.MaxUint64} {
		if _, err := decodeSharedStudy(p, expected, nil); err == nil {
			t.Fatal("expected length")
		}
	}
	for _, at := range []int{5, 9, 13, 17, 21, 25, 29, 37, 41, 45} {
		for _, value := range []uint32{0, math.MaxUint32} {
			bad := bytes.Clone(p)
			binary.BigEndian.PutUint32(bad[at:at+4], value)
			if bytes.Equal(bad, p) {
				continue
			}
			if _, err := decodeSharedStudy(bad, uint64(len(raw)), nil); err == nil {
				t.Fatalf("header bound at %d value %d", at, value)
			}
		}
	}
	for _, at := range []int{0, 1, 33, len(p) - 1} {
		bad := bytes.Clone(p)
		bad[at] ^= 0x80
		if _, err := decodeSharedStudy(bad, uint64(len(raw)), nil); err == nil {
			t.Fatal("marker/CRC", at)
		}
	}
	if _, err := decodeSharedStudy(append(bytes.Clone(p), 0), uint64(len(raw)), nil); err == nil {
		t.Fatal("trailing bytes")
	}
	// A real frame that would exceed the declared key output is rejected before
	// canonical reconstruction; neither declared lengths nor FCS can grow scratch.
	var e sharedStudyEncoder
	if err := e.columns.prepare(raw, starts); err != nil {
		t.Fatal(err)
	}
	e.tail = enc.EncodeAll(e.columns.packed[e.columns.tailStart:e.columns.packedBytes], nil)
	e.key = enc.EncodeAll(make([]byte, historyRecordColumnPageMax), nil)
	bad := e.pack(0)
	if _, err := decodeSharedStudy(bad, uint64(len(raw)), nil); err == nil {
		t.Fatal("key decompression cap")
	}
	// Reject malformed annotations; the reusable encoder must recover afterwards.
	for _, offsets := range [][]uint32{{math.MaxUint32}, {starts[0], starts[1] + 1}} {
		if _, _, err := reusable.encode(raw, offsets, enc); err == nil {
			t.Fatal("bad annotation")
		}
	}
	good, _, err := reusable.encode(raw, starts, enc)
	if err != nil {
		t.Fatal(err)
	}
	if out, err := decodeSharedStudy(good, uint64(len(raw)), nil); err != nil || !bytes.Equal(out, raw) {
		t.Fatal("recover after errors", err)
	}
}

type sharedStudyInput struct {
	Pair   int    `json:"pair"`
	Path   string `json:"path"`
	Size   int64  `json:"size"`
	SHA256 string `json:"sha256"`
	Plain  int    `json:"plain_pages"`
	Modes  [3]int `json:"column_key_modes"`
}

type sharedStudyPage struct {
	Pair, Page                                                     int
	RawBytes, OriginalBytes, PrototypeBytes                        int
	OriginalMode                                                   int
	Records                                                        int
	RawSHA, OriginalSHA, PrototypeSHA                              string
	Costs                                                          sharedStudyCosts
	OldEncodeNS, PrototypeEncodeNS, OldDecodeNS, PrototypeDecodeNS [3]int64
	AnnotationsRecovered                                           bool
}

func sharedStudySHA(p []byte) string { d := sha256.Sum256(p); return hex.EncodeToString(d[:]) }

// Recover annotations only from an authenticated existing HRC2 transform. Plain
// pages are preserved verbatim and explicitly excluded from key experiments.
func sharedStudyStarts(comp, raw []byte) ([]uint32, int, error) {
	if comp[0] == 0 {
		return nil, -1, nil
	}
	dec, err := recordColumnCodecDecoder()
	if err != nil {
		return nil, 0, err
	}
	h, err := dec.DecodeAll(comp[1:], make([]byte, 0, len(raw)+historyRecordColumnHeader))
	if err != nil {
		return nil, 0, err
	}
	if len(h) < 36 || string(h[:4]) != "HRC2" {
		return nil, 0, errHistoryRecordColumns
	}
	if reconstructed, err := decodeHistoryRecordColumns(h, uint64(len(raw)), nil); err != nil || !bytes.Equal(reconstructed, raw) {
		return nil, 0, errHistoryRecordColumns
	}
	count := int(binary.BigEndian.Uint32(h[8:12]))
	at := uint64(binary.BigEndian.Uint32(h[12:16]))
	starts := make([]uint32, 0, count)
	for i := 0; i < count; i++ {
		if at+21 > uint64(len(raw)) {
			return nil, 0, errHistoryRecordColumns
		}
		starts = append(starts, uint32(at))
		at += 21 + uint64(binary.BigEndian.Uint32(raw[at+17:at+21]))
	}
	return starts, int(binary.BigEndian.Uint32(h[28:32])), nil
}

func TestOfflineSharedPayloadRealPages(t *testing.T) {
	root := os.Getenv("GTRON_SHARED_STUDY")
	if root == "" {
		t.Skip("private immutable real-page controller only")
	}
	if root != "/data/gtron/history-columns-shared-payload-20261026-03" {
		t.Fatal("private scope")
	}
	b, err := os.ReadFile(filepath.Join(root, "selected-inputs.json"))
	if err != nil {
		t.Fatal(err)
	}
	var inputs []sharedStudyInput
	if json.Unmarshal(b, &inputs) != nil || len(inputs) != 3 {
		t.Fatal("pinned input plan")
	}
	output, err := os.OpenFile(filepath.Join(root, "pages.jsonl"), os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if err != nil {
		t.Fatal(err)
	}
	defer output.Close()
	writer := json.NewEncoder(output)
	enc, _, err := cbCodec()
	if err != nil {
		t.Fatal(err)
	}
	var old recordColumnPageEncoder
	var prototype sharedStudyEncoder
	for _, input := range inputs {
		file, err := os.Open(input.Path)
		if err != nil {
			t.Fatal(err)
		}
		stat, err := file.Stat()
		if err != nil || stat.Size() != input.Size {
			t.Fatal("input size", err)
		}
		hash := sha256.New()
		if _, err := io.Copy(hash, file); err != nil {
			t.Fatal(err)
		}
		if hex.EncodeToString(hash.Sum(nil)) != input.SHA256 {
			t.Fatal("input physical SHA")
		}
		header := make([]byte, compressedBlockHeaderSize)
		if _, err := file.ReadAt(header, 0); err != nil {
			t.Fatal(err)
		}
		if !recordColumnFooterVersion(header) {
			t.Fatal("not frozen V5")
		}
		layout, err := readCompressedBlockFooterLayout(file, uint64(stat.Size()), header)
		if err != nil {
			t.Fatal(err)
		}
		if err := validateRecordColumnBlocks(layout.table, layout.uncSize); err != nil {
			t.Fatal(err)
		}
		var modes [3]int
		plain := 0
		for i, block := range layout.table {
			expected, err := compressedBlockExpectedLen(layout.table, layout.uncSize, i)
			if err != nil {
				t.Fatal(err)
			}
			comp := make([]byte, int(block.compressedLen))
			if _, err := file.ReadAt(comp, int64(compressedBlockHeaderSize+block.compressedStart)); err != nil {
				t.Fatal(err)
			}
			raw, _, err := decodeRecordColumnStoredPage(comp, expected, nil, nil)
			if err != nil {
				t.Fatal(err)
			}
			starts, mode, err := sharedStudyStarts(comp, raw)
			if err != nil {
				t.Fatal(err)
			}
			if mode < 0 {
				plain++
			} else {
				modes[mode]++
			}
			control, err := old.encode(raw, starts, enc)
			if err != nil || !bytes.Equal(control, comp) {
				t.Fatalf("exact stored control pair %d page %d: %v", input.Pair, i, err)
			}
			candidate, costs, err := prototype.encode(raw, starts, enc)
			if err != nil {
				t.Fatal(err)
			}
			candidate = bytes.Clone(candidate)
			decoded, err := decodeSharedStudy(candidate, expected, nil)
			if err != nil || !bytes.Equal(decoded, raw) {
				t.Fatal("prototype canonical", err)
			}
			row := sharedStudyPage{Pair: input.Pair, Page: i, RawBytes: len(raw), OriginalBytes: len(comp), PrototypeBytes: len(candidate), OriginalMode: mode, Records: len(starts), RawSHA: sharedStudySHA(raw), OriginalSHA: sharedStudySHA(comp), PrototypeSHA: sharedStudySHA(candidate), Costs: costs, AnnotationsRecovered: mode >= 0}
			// Resident serial page diagnostics, alternating order per page/round.
			// No file IO, hashing, or correctness verification is inside intervals.
			for round := 0; round < 3; round++ {
				oldEncode := func() {
					start := time.Now()
					got, e := old.encode(raw, starts, enc)
					row.OldEncodeNS[round] = time.Since(start).Nanoseconds()
					if e != nil || !bytes.Equal(got, comp) {
						t.Fatal("control timed bytes", e)
					}
				}
				newEncode := func() {
					start := time.Now()
					got, _, e := prototype.encode(raw, starts, enc)
					row.PrototypeEncodeNS[round] = time.Since(start).Nanoseconds()
					if e != nil || !bytes.Equal(got, candidate) {
						t.Fatal("prototype timed bytes", e)
					}
				}
				oldDecode := func() {
					start := time.Now()
					got, _, e := decodeRecordColumnStoredPage(comp, expected, nil, nil)
					row.OldDecodeNS[round] = time.Since(start).Nanoseconds()
					if e != nil || !bytes.Equal(got, raw) {
						t.Fatal("control timed decode", e)
					}
				}
				newDecode := func() {
					start := time.Now()
					got, e := decodeSharedStudy(candidate, expected, nil)
					row.PrototypeDecodeNS[round] = time.Since(start).Nanoseconds()
					if e != nil || !bytes.Equal(got, raw) {
						t.Fatal("prototype timed decode", e)
					}
				}
				if (i+round)%2 == 0 {
					oldEncode()
					newEncode()
					oldDecode()
					newDecode()
				} else {
					newEncode()
					oldEncode()
					newDecode()
					oldDecode()
				}
			}
			if err := writer.Encode(row); err != nil {
				t.Fatal(err)
			}
		}
		if err := file.Close(); err != nil {
			t.Fatal(err)
		}
		if plain != input.Plain || modes != input.Modes {
			t.Fatal("complete page census differs", plain, modes)
		}
		fmt.Printf("SHARED_PAIR_COMPLETE %d pages=%d plain=%d modes=%v\n", input.Pair, len(layout.table), plain, modes)
	}
	if err := output.Sync(); err != nil {
		t.Fatal(err)
	}
}
