package snapshots

// Overlay-only comparison. Product Go and the prior native study stay frozen.
import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"io"
	"os"
	"path/filepath"
	"runtime"
	"testing"
	"time"
)

const sharedDecoderRounds = 5
const sharedDecoderBatch = 8

var sharedDecoderArms = [...]string{"v5-fresh", "reference-fresh", "scratch-fresh", "v5-reused", "reference-reused", "scratch-reused"}

type sharedDecoderCost struct {
	Nanoseconds        [sharedDecoderRounds]int64
	Allocated          [sharedDecoderRounds]uint64
	Mallocs            [sharedDecoderRounds]uint64
	GC                 [sharedDecoderRounds]uint32
	RetainedScratchMax int
}

type sharedDecoderRow struct {
	Pair, Page, RawBytes, OriginalBytes, PrototypeBytes, OriginalMode int
	RawSHA, OriginalSHA, PrototypeSHA                                 string
	AnnotationsRecovered                                              bool
	Batch, Rounds                                                     int
	Arms                                                              map[string]*sharedDecoderCost
}

type sharedDecoderState struct{ dst, scratch []byte }

func sharedDecoderCall(arm int, original, proposed []byte, expected uint64, state *sharedDecoderState) ([]byte, error) {
	var dst, scratch []byte
	if arm >= 3 {
		dst, scratch = state.dst, state.scratch
	}
	var out, retained []byte
	var err error
	switch arm % 3 {
	case 0:
		out, retained, err = decodeRecordColumnStoredPage(original, expected, dst, scratch)
	case 1:
		out, err = decodeSharedStudy(proposed, expected, dst)
	case 2:
		out, retained, err = decodeSharedStudyScratch(proposed, expected, dst, scratch)
	}
	if arm >= 3 && err == nil {
		state.dst, state.scratch = out, retained
	}
	return out, err
}

func TestOfflineSharedDecoderArmParity(t *testing.T) {
	enc, _, err := cbCodec()
	if err != nil {
		t.Fatal(err)
	}
	var old recordColumnPageEncoder
	var prototype sharedStudyEncoder
	var states [len(sharedDecoderArms)]sharedDecoderState
	for seed := int64(0); seed < 40; seed++ {
		raw, starts := recordColumnEncoderPage(seed, []int{128 << 10, 4096, 63, 21, 65535}[seed%5])
		original, err := old.encode(raw, starts, enc)
		if err != nil {
			t.Fatal(err)
		}
		proposed, _, err := prototype.encode(raw, starts, enc)
		if err != nil {
			t.Fatal(err)
		}
		for repeat := 0; repeat < 3; repeat++ {
			for arm, name := range sharedDecoderArms {
				out, err := sharedDecoderCall(arm, original, proposed, uint64(len(raw)), &states[arm])
				if err != nil || !bytes.Equal(out, raw) || cap(states[arm].scratch) > historyRecordColumnPageMax+36 {
					t.Fatal(seed, repeat, name, err)
				}
				for _, state := range states {
					clear(state.scratch[:cap(state.scratch)])
				}
				if !bytes.Equal(out, raw) || arm < 3 && (states[arm].dst != nil || states[arm].scratch != nil) {
					t.Fatal("fresh policy or output ownership", seed, name)
				}
				if _, err := sharedDecoderCall(arm, original, proposed, uint64(len(raw))+1, &states[arm]); err == nil {
					t.Fatal("wrong expected length accepted", seed, name)
				}
			}
		}
	}
}

func TestOfflineSharedDecoderRealPages(t *testing.T) {
	root := os.Getenv("GTRON_SHARED_DECODER_STUDY")
	if root == "" {
		t.Skip("private immutable-page study only")
	}
	if root != "/data/gtron/history-shared-decoder-20261026-02" {
		t.Fatal("private output scope")
	}
	read := func(name string, dst any) {
		t.Helper()
		p, err := os.ReadFile(name)
		if err != nil || json.Unmarshal(p, dst) != nil {
			t.Fatal("pinned metadata", name, err)
		}
	}
	var inputs []sharedStudyInput
	read(filepath.Join(root, "selected-inputs.json"), &inputs)
	if len(inputs) != 3 || inputs[0].Pair != 458 || inputs[1].Pair != 2309 || inputs[2].Pair != 4147 {
		t.Fatal("pinned input cohort")
	}
	prior, err := os.Open(filepath.Join(root, "reference-pages.jsonl"))
	if err != nil {
		t.Fatal(err)
	}
	oracle := make(map[[2]int]sharedStudyPage)
	d := json.NewDecoder(prior)
	for {
		var row sharedStudyPage
		err := d.Decode(&row)
		if err == io.EOF {
			break
		}
		key := [2]int{row.Pair, row.Page}
		if _, duplicate := oracle[key]; duplicate || err != nil {
			t.Fatal("reference row", key, err)
		}
		oracle[key] = row
	}
	if err := prior.Close(); err != nil || len(oracle) != 1817 {
		t.Fatal("full reference cohort", len(oracle), err)
	}
	output, err := os.OpenFile(filepath.Join(root, "decoder-pages.jsonl"), os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if err != nil {
		t.Fatal(err)
	}
	defer output.Close()
	w := json.NewEncoder(output)
	enc, _, err := cbCodec()
	if err != nil {
		t.Fatal(err)
	}
	var old recordColumnPageEncoder
	var prototype sharedStudyEncoder
	var states [len(sharedDecoderArms)]sharedDecoderState
	seen, ordinary := 0, 0
	for _, input := range inputs {
		file, err := os.Open(input.Path)
		if err != nil {
			t.Fatal(err)
		}
		s, err := file.Stat()
		if err != nil || s.Size() != input.Size {
			t.Fatal("input size", err)
		}
		h := sha256.New()
		if _, err := io.Copy(h, file); err != nil || hex.EncodeToString(h.Sum(nil)) != input.SHA256 {
			t.Fatal("input physical SHA", err)
		}
		header := make([]byte, compressedBlockHeaderSize)
		if _, err := file.ReadAt(header, 0); err != nil || !recordColumnFooterVersion(header) {
			t.Fatal("frozen V5 header", err)
		}
		layout, err := readCompressedBlockFooterLayout(file, uint64(s.Size()), header)
		if err != nil {
			t.Fatal(err)
		}
		if err := validateRecordColumnBlocks(layout.table, layout.uncSize); err != nil {
			t.Fatal(err)
		}
		var modes [3]int
		plain := 0
		for page, block := range layout.table {
			expected, err := compressedBlockExpectedLen(layout.table, layout.uncSize, page)
			if err != nil {
				t.Fatal(err)
			}
			original := make([]byte, int(block.compressedLen))
			if _, err := file.ReadAt(original, int64(compressedBlockHeaderSize+block.compressedStart)); err != nil {
				t.Fatal(err)
			}
			raw, _, err := decodeRecordColumnStoredPage(original, expected, nil, nil)
			if err != nil {
				t.Fatal(err)
			}
			starts, mode, err := sharedStudyStarts(original, raw)
			if err != nil {
				t.Fatal(err)
			}
			control, err := old.encode(raw, starts, enc)
			if err != nil || !bytes.Equal(control, original) {
				t.Fatal("exact frozen V5 stored page", input.Pair, page, err)
			}
			proposed, _, err := prototype.encode(raw, starts, enc)
			if err != nil {
				t.Fatal(err)
			}
			proposed = bytes.Clone(proposed)
			key := [2]int{input.Pair, page}
			ref, ok := oracle[key]
			row := sharedDecoderRow{Pair: input.Pair, Page: page, RawBytes: len(raw), OriginalBytes: len(original), PrototypeBytes: len(proposed), OriginalMode: mode, RawSHA: sharedStudySHA(raw), OriginalSHA: sharedStudySHA(original), PrototypeSHA: sharedStudySHA(proposed), AnnotationsRecovered: mode >= 0, Batch: sharedDecoderBatch, Rounds: sharedDecoderRounds, Arms: make(map[string]*sharedDecoderCost)}
			if !ok || ref.RawBytes != row.RawBytes || ref.OriginalBytes != row.OriginalBytes || ref.PrototypeBytes != row.PrototypeBytes || ref.OriginalMode != mode || ref.RawSHA != row.RawSHA || ref.OriginalSHA != row.OriginalSHA || ref.PrototypeSHA != row.PrototypeSHA || ref.AnnotationsRecovered != row.AnnotationsRecovered {
				t.Fatal("frozen row identity", key)
			}
			if mode < 0 {
				plain++
				ordinary++
			} else {
				modes[mode]++
			}
			// Prime each arm outside intervals. Reuse persists per arm/caller across
			// pages; fresh arms discard all output and scratch after each call.
			for arm, name := range sharedDecoderArms {
				out, err := sharedDecoderCall(arm, original, proposed, expected, &states[arm])
				if err != nil || !bytes.Equal(out, raw) {
					t.Fatal("warmup canonical", key, name, err)
				}
				row.Arms[name] = &sharedDecoderCost{}
			}
			for round := 0; round < sharedDecoderRounds; round++ {
				for order := range sharedDecoderArms {
					arm := (page + round + order) % len(sharedDecoderArms)
					if round%2 != 0 {
						arm = len(sharedDecoderArms) - 1 - arm
					}
					name := sharedDecoderArms[arm]
					cost := row.Arms[name]
					var before, after runtime.MemStats
					runtime.ReadMemStats(&before)
					var out []byte
					start := time.Now()
					for repeat := 0; repeat < sharedDecoderBatch; repeat++ {
						out, err = sharedDecoderCall(arm, original, proposed, expected, &states[arm])
						if err != nil || uint64(len(out)) != expected {
							t.Fatal("timed decoder", key, name, err)
						}
					}
					cost.Nanoseconds[round] = time.Since(start).Nanoseconds()
					runtime.ReadMemStats(&after)
					cost.Allocated[round] = after.TotalAlloc - before.TotalAlloc
					cost.Mallocs[round] = after.Mallocs - before.Mallocs
					cost.GC[round] = after.NumGC - before.NumGC
					cost.RetainedScratchMax = max(cost.RetainedScratchMax, cap(states[arm].scratch))
					if !bytes.Equal(out, raw) || cost.RetainedScratchMax > historyRecordColumnPageMax+36 {
						t.Fatal("canonical or scratch cap", key, name)
					}
				}
			}
			if err := w.Encode(row); err != nil {
				t.Fatal(err)
			}
			seen++
			if seen%200 == 0 {
				t.Logf("verified resident decoder pages %d/1817", seen)
			}
		}
		if err := file.Close(); err != nil || plain != input.Plain || modes != input.Modes {
			t.Fatal("complete input census", input.Pair, plain, modes, err)
		}
	}
	if seen != 1817 || ordinary != 11 {
		t.Fatal("complete cohort", seen, ordinary)
	}
	if err := output.Sync(); err != nil {
		t.Fatal(err)
	}
	t.Logf("all %d pages, %d ordinary pages, %d arms, %d rounds, %d calls per cell", seen, ordinary, len(sharedDecoderArms), sharedDecoderRounds, sharedDecoderBatch)
}
