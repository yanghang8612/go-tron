import base64,datetime,hashlib,json,os,pathlib,resource,subprocess,tarfile,time,traceback

P=pathlib.Path('/data/gtron/history-shared-decoder-profile-20261026-01')
PREVIOUS=pathlib.Path('/data/gtron/history-shared-decoder-20261026-02')
SOURCE=pathlib.Path('/data/gtron/history-columns-ordered-pages-20261026-01/candidate-source')
state={'complete':False,'production_mutations':False,'checks':[],
       'scope':'Resident reused-buffer decoder CPU diagnosis only; no new physical format or HTTP/MuHash/restoration acceptance.'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,d):
 with (P/n).open('x') as f:f.write(json.dumps(d,indent=2,sort_keys=True)+'\n')
def save():
 state['utc']=datetime.datetime.utcnow().isoformat()+'Z';q=P/'profile-status.json.tmp';q.write_text(json.dumps(state,indent=2,sort_keys=True)+'\n');os.replace(str(q),str(P/'profile-status.json'))
def identity():
 d=dict(x.split('=',1) for x in subprocess.check_output(['systemctl','show','gtron','-p','MainPID','-p','ActiveState'],universal_newlines=True).splitlines());pid=int(d['MainPID']);d['start_ticks']=pathlib.Path('/proc/%d/stat'%pid).read_text().split(') ',1)[1].split()[19] if pid else None;return d
def inventory():
 d={}
 for root,dirs,files in os.walk(str(SOURCE)):
  dirs[:]=[x for x in dirs if x not in ('.git','build','target')]
  for name in files:
   if name.endswith('.go') or name in ('go.mod','go.sum'):
    p=pathlib.Path(root)/name;d[str(p.relative_to(SOURCE))]=sha(p)
 return d
def run(label,args,env,timeout):
 assert identity()==state['production_before'];state['phase']=label;save();start=time.monotonic()
 with (P/(label+'.log')).open('xb') as f:r=subprocess.run(args,cwd=str(SOURCE),env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 state['checks'].append({'label':label,'args':args,'returncode':r.returncode,'seconds':time.monotonic()-start,'log_sha256':sha(P/(label+'.log'))});save();assert r.returncode==0,label+' failed';assert identity()==state['production_before']
try:
 state['production_before']=identity();pid=int(state['production_before']['MainPID']);state['production_binary_sha256']=sha(pathlib.Path('/proc/%d/exe'%pid)) if pid else None
 prior=json.loads((PREVIOUS/'study-status.json').read_text());assert prior['complete'] and prior['production_after']==state['production_before']
 assert sha(PREVIOUS/'decoder-study-core.tar.xz')=='cc18b1830e0016afc364c56e74e8aff2fd81f1e2408c3147461863ac0e08ed27'
 state['prior_archive_sha256']=sha(PREVIOUS/'decoder-study-core.tar.xz')
 before=inventory();assert before==json.loads((PREVIOUS/'source-after.json').read_text());write('source-before.json',before)
 helpers=['offline_shared_payload_test.go','offline_shared_scratch_test.go','offline_shared_decoder_test.go','offline_shared_cpu_test.go','run-profile.py'];state['helpers']={n:sha(P/n) for n in helpers}
 for n in helpers[:3]:assert sha(P/n)==prior['helpers'][n]
 inputs=json.loads((P/'selected-inputs.json').read_text());assert inputs==json.loads((PREVIOUS/'selected-inputs.json').read_text())
 assert sha(P/'reference-pages.jsonl')==sha(PREVIOUS/'reference-pages.jsonl')
 assert all(pathlib.Path(x['path']).stat().st_size==x['size'] and sha(pathlib.Path(x['path']))==x['sha256'] for x in inputs);write('inputs-before.json',inputs)
 pairs=[('offline_shared_payload_study_test.go','offline_shared_payload_test.go'),('offline_shared_scratch_study_test.go','offline_shared_scratch_test.go'),('offline_shared_decoder_study_test.go','offline_shared_decoder_test.go'),('offline_shared_cpu_study_test.go','offline_shared_cpu_test.go')]
 write('overlay.json',{'Replace':{str(SOURCE/'core/state/snapshots'/a):str(P/b) for a,b in pairs}})
 env={k:v for k,v in os.environ.items() if not k.startswith('GTRON_')};env.update(PATH='/data/go/bin:'+env.get('PATH',''),GOCACHE='/data/gtron/history-shared-decoder-20261026-01/go-build',GOPATH='/root/go',GOMODCACHE='/root/go/pkg/mod',GOTOOLCHAIN='local',GOMAXPROCS='2',GOMEMLIMIT='3GiB',CGO_ENABLED='1')
 write('effective-go-env.json',{k:env[k] for k in ['PATH','GOCACHE','GOPATH','GOMODCACHE','GOTOOLCHAIN','GOMAXPROCS','GOMEMLIMIT','CGO_ENABLED']})
 state['go_version']=subprocess.check_output(['/data/go/bin/go','version'],env=env,universal_newlines=True).strip();assert state['go_version']=='go version go1.25.5 linux/amd64'
 binary=P/'cpu-study.test';run('native-build',['/data/go/bin/go','test','-overlay',str(P/'overlay.json'),'-c','./core/state/snapshots','-o',str(binary)],env,300);state['binary_sha256']=sha(binary)
 run('cpu-study',[str(binary),'-test.run=^TestOfflineSharedDecoderCPUStudy$','-test.v','-test.timeout=10m'],dict(env,GTRON_SHARED_DECODER_CPU_STUDY=str(P)),650)
 rows=[json.loads(s) for s in (P/'cpu-windows.jsonl').read_text().splitlines()];assert len(rows)==6 and [x['Arm'] for x in rows]==['v5','scratch','scratch','v5','v5','scratch']
 assert all(x['Pages']==1817 and x['Passes']>0 and 20<=x['WallSeconds']<40 and 0<x['CPUSeconds']<80 and x['ScratchCap']<=131108 for x in rows)
 for arm in ('v5','scratch'):
  profiles=[str(P/x['Profile']) for x in rows if x['Arm']==arm]
  for kind,options in [('flat',['-top']),('cum',['-top','-cum']),('decode',['-peek=DecodeAll|decodeHistoryRecordColumns'])]:
   run(arm+'-'+kind,['/data/go/bin/go','tool','pprof']+options+['-nodecount=45','-unit=ms',str(binary)]+profiles,env,60)
 assert inventory()==before;write('source-after.json',before)
 assert all(sha(pathlib.Path(x['path']))==x['sha256'] for x in inputs);write('inputs-after.json',inputs)
 assert all(sha(P/n)==h for n,h in state['helpers'].items());assert sha(PREVIOUS/'decoder-study-core.tar.xz')==state['prior_archive_sha256']
 assert identity()==state['production_before'];state['production_after']=identity();assert not pid or sha(pathlib.Path('/proc/%d/exe'%pid))==state['production_binary_sha256']
 state.update(complete=True,phase='complete',windows=6,pages=1817,windows_sha256=sha(P/'cpu-windows.jsonl'));save()
 members={q.name:sha(q) for q in P.iterdir() if q.is_file() and q.suffix not in ('.test','.xz') and q.name not in ('archive-members.json','archive-seal.json')};write('archive-members.json',members)
 archive=P/'cpu-study-core.tar.xz'
 with tarfile.open(str(archive),'w:xz') as t:
  for n in sorted(list(members)+['archive-members.json']):t.add(str(P/n),arcname=n,recursive=False)
 write('archive-seal.json',{'bytes':archive.stat().st_size,'sha256':sha(archive),'members':len(members)+1,'complete':True,'production_mutations':False});print('CPU_STUDY_COMPLETE',archive.stat().st_size,sha(archive),flush=True)
except BaseException as e:
 state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
