package snapshots

// Overlay-only CPU diagnosis after the complete six-arm study. The successful
// study, product source, decoders and immutable page cohort are not changed.
import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"runtime/pprof"
	"syscall"
	"testing"
	"time"
)

type sharedCPUFixture struct {
	original, proposed, canonical []byte
}

type sharedCPUWindow struct {
	Arm, Profile                     string
	Round, Passes, Pages, ScratchCap int
	WallSeconds, CPUSeconds          float64
}

func TestOfflineSharedDecoderCPUStudy(t *testing.T) {
	root := os.Getenv("GTRON_SHARED_DECODER_CPU_STUDY")
	if root == "" {
		t.Skip("private immutable resident-page CPU study only")
	}
	if root != "/data/gtron/history-shared-decoder-profile-20261026-01" {
		t.Fatal("private output scope")
	}
	var inputs []sharedStudyInput
	b, err := os.ReadFile(filepath.Join(root, "selected-inputs.json"))
	if err != nil || json.Unmarshal(b, &inputs) != nil || len(inputs) != 3 {
		t.Fatal("frozen inputs", err)
	}
	ref, err := os.Open(filepath.Join(root, "reference-pages.jsonl"))
	if err != nil {
		t.Fatal(err)
	}
	oracle := make(map[[2]int]sharedStudyPage)
	d := json.NewDecoder(ref)
	for {
		var row sharedStudyPage
		err := d.Decode(&row)
		if err == io.EOF {
			break
		}
		key := [2]int{row.Pair, row.Page}
		if _, duplicate := oracle[key]; err != nil || duplicate {
			t.Fatal("reference row", err)
		}
		oracle[key] = row
	}
	if err := ref.Close(); err != nil || len(oracle) != 1817 {
		t.Fatal("full oracle", len(oracle), err)
	}
	enc, _, err := cbCodec()
	if err != nil {
		t.Fatal(err)
	}
	var fixtures []sharedCPUFixture
	var old recordColumnPageEncoder
	var prototype sharedStudyEncoder
	ordinary := 0
	for _, input := range inputs {
		physical, err := os.ReadFile(input.Path)
		if err != nil || int64(len(physical)) != input.Size || sharedStudySHA(physical) != input.SHA256 {
			t.Fatal("physical identity", input.Pair, err)
		}
		layout, err := readCompressedBlockFooterLayout(bytes.NewReader(physical), uint64(len(physical)), physical[:compressedBlockHeaderSize])
		if err != nil {
			t.Fatal(err)
		}
		if err := validateRecordColumnBlocks(layout.table, layout.uncSize); err != nil {
			t.Fatal(err)
		}
		for page, block := range layout.table {
			n, err := compressedBlockExpectedLen(layout.table, layout.uncSize, page)
			if err != nil {
				t.Fatal(err)
			}
			at := compressedBlockHeaderSize + block.compressedStart
			stored := bytes.Clone(physical[at : at+block.compressedLen])
			raw, _, err := decodeRecordColumnStoredPage(stored, n, nil, nil)
			if err != nil {
				t.Fatal(err)
			}
			starts, mode, err := sharedStudyStarts(stored, raw)
			if err != nil {
				t.Fatal(err)
			}
			control, err := old.encode(raw, starts, enc)
			if err != nil || !bytes.Equal(control, stored) {
				t.Fatal("exact V5 control", err)
			}
			proposed, _, err := prototype.encode(raw, starts, enc)
			if err != nil {
				t.Fatal(err)
			}
			r, ok := oracle[[2]int{input.Pair, page}]
			if !ok || len(raw) != r.RawBytes || sharedStudySHA(raw) != r.RawSHA || sharedStudySHA(stored) != r.OriginalSHA || sharedStudySHA(proposed) != r.PrototypeSHA || mode != r.OriginalMode {
				t.Fatal("same canonical and stored fixture", input.Pair, page)
			}
			if mode < 0 {
				ordinary++
			}
			fixtures = append(fixtures, sharedCPUFixture{stored, bytes.Clone(proposed), raw})
		}
	}
	if len(fixtures) != 1817 || ordinary != 11 {
		t.Fatal("full cohort", len(fixtures), ordinary)
	}
	var states [len(sharedDecoderArms)]sharedDecoderState
	check := func(arm int) {
		t.Helper()
		for i, f := range fixtures {
			out, err := sharedDecoderCall(arm, f.original, f.proposed, uint64(len(f.canonical)), &states[arm])
			if err != nil || !bytes.Equal(out, f.canonical) || cap(states[arm].scratch) > historyRecordColumnPageMax+36 {
				t.Fatal("canonical/ownership/bounds", arm, i, err)
			}
		}
	}
	cpu := func() float64 {
		t.Helper()
		var r syscall.Rusage
		if err := syscall.Getrusage(syscall.RUSAGE_SELF, &r); err != nil {
			t.Fatal(err)
		}
		return float64(r.Utime.Sec+r.Stime.Sec) + float64(r.Utime.Usec+r.Stime.Usec)/1e6
	}
	result, err := os.OpenFile(filepath.Join(root, "cpu-windows.jsonl"), os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if err != nil {
		t.Fatal(err)
	}
	defer result.Close()
	w := json.NewEncoder(result)
	var rounds [len(sharedDecoderArms)]int
	for _, arm := range []int{3, 5, 5, 3, 3, 5} {
		check(arm) // Whole-cohort warmup and byte comparison outside profiles.
		rounds[arm]++
		name := "v5"
		if arm == 5 {
			name = "scratch"
		}
		filename := fmt.Sprintf("%s-r%d.cpu.pprof", name, rounds[arm])
		p, err := os.OpenFile(filepath.Join(root, filename), os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
		if err != nil {
			t.Fatal(err)
		}
		if err := pprof.StartCPUProfile(p); err != nil {
			t.Fatal(err)
		}
		before := cpu()
		start := time.Now()
		passes := 0
		for time.Since(start) < 20*time.Second {
			for i, f := range fixtures {
				out, err := sharedDecoderCall(arm, f.original, f.proposed, uint64(len(f.canonical)), &states[arm])
				if err != nil || len(out) != len(f.canonical) {
					t.Fatal("profiled decoder", arm, i, err)
				}
			}
			passes++
		}
		elapsed, used := time.Since(start).Seconds(), cpu()-before
		pprof.StopCPUProfile()
		if err := p.Close(); err != nil {
			t.Fatal(err)
		}
		check(arm) // Full canonical byte comparison again after every window.
		row := sharedCPUWindow{name, filename, rounds[arm], passes, len(fixtures), cap(states[arm].scratch), elapsed, used}
		if err := w.Encode(row); err != nil {
			t.Fatal(err)
		}
		if err := result.Sync(); err != nil {
			t.Fatal(err)
		}
		t.Logf("profile %s: passes=%d wall=%.6f cpu=%.6f", filename, passes, elapsed, used)
	}
}
