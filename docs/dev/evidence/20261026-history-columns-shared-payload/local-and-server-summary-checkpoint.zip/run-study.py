"""One-shot bounded native page study; never operates the production service."""
import datetime
import hashlib
import json
import os
import pathlib
import resource
import statistics
import subprocess
import time
import traceback

P = pathlib.Path('/data/gtron/history-columns-shared-payload-20261026-03')
PRIOR = pathlib.Path('/data/gtron/history-columns-ordered-pages-20261026-01')
SOURCE = PRIOR/'candidate-source'
state = dict(complete=False, production_mutations=False, checks=[],
             scope='Overlay-only HSP1 page prototype on all three frozen V5 outputs. All frame/header bytes included. Resident serial page diagnostics only; not physical file, publication, HTTP, or full snapshot acceptance.')


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(4 << 20), b''):
            h.update(b)
    return h.hexdigest()


def show(unit):
    args = ['systemctl', 'show', unit]
    for key in ['LoadState', 'ActiveState', 'SubState', 'MainPID', 'ExecMainStatus']:
        args += ['-p', key]
    result = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True)
    return dict(line.split('=', 1) for line in result.stdout.splitlines() if '=' in line)


def identity():
    out = show('gtron.service')
    pid = int(out['MainPID'])
    out['binary_sha256'] = sha(pathlib.Path('/proc/%d/exe' % pid)) if pid else None
    out['process_start_ticks'] = pathlib.Path('/proc/%d/stat' % pid).read_text().split(') ', 1)[1].split()[19] if pid else None
    return out


def save():
    state['utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    temp = P/'study-status.json.tmp'
    temp.write_text(json.dumps(state, sort_keys=True, indent=2)+'\n')
    os.replace(str(temp), str(P/'study-status.json'))


def inventory():
    names = []
    for directory, directories, files in os.walk(str(SOURCE)):
        directories[:] = [n for n in directories if n not in ('.git', 'build', 'target')]
        names.extend(str((pathlib.Path(directory)/n).relative_to(SOURCE)) for n in files if n.endswith('.go') or n in ('go.mod','go.sum'))
    return {name: sha(SOURCE/name) for name in sorted(names)}


def write_json(name, value):
    path = P/name
    with path.open('x') as f:
        f.write(json.dumps(value, sort_keys=True, indent=2)+'\n')


def check(label, args, env, timeout):
    state['phase'] = label
    save()
    started = time.monotonic()
    before = resource.getrusage(resource.RUSAGE_CHILDREN)
    with (P/(label+'.log')).open('xb') as f:
        result = subprocess.run(args, cwd=str(SOURCE), env=env, stdout=f, stderr=subprocess.STDOUT, timeout=timeout)
    after = resource.getrusage(resource.RUSAGE_CHILDREN)
    row = dict(label=label, args=args, returncode=result.returncode, seconds=time.monotonic()-started,
               cpu_seconds=after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,
               log_sha256=sha(P/(label+'.log')))
    state['checks'].append(row)
    save()
    assert result.returncode == 0, label+' failed; preserve log and inspect'


try:
    assert not (P/'pages.jsonl').exists(), 'do not rerun completed or partial experiment'
    before = identity()
    state['production_before'] = before
    state['prior_units'] = {}
    for name, status in [('gtron-columns-ordered-pages-native-20261026-01.service', 'publish-status.json'),
                         ('gtron-columns-ordered-pages-acceptance-20261026-01.service', 'acceptance-status.json')]:
        unit = show(name)
        state['prior_units'][name] = unit
        assert unit['MainPID'] == '0' and unit['ActiveState'] != 'active' and unit['ExecMainStatus'] == '0'
        assert json.loads((PRIOR/status).read_text())['complete']
    expected = json.loads((P/'frozen-source-inventory.json').read_text())
    assert len(expected) == 2149 and sha(P/'frozen-source-inventory.json') == '3281b8fcd833df0066efba23ac68c6ed329f9a1534ea5be5c75002655b6e9150'
    files = inventory()
    assert all(files.get(n) == d for n,d in expected.items()) and len(files) == 2173
    write_json('source-before.json', files)
    state['source_before_sha256'] = sha(P/'source-before.json')
    state['source_files'] = len(expected)
    lib = SOURCE/'third_party/librustzcash/target/release/librustzcash.a'
    state['sapling_sha256'] = sha(lib)
    assert state['sapling_sha256'] == 'b6c99f8fabac36d5a836c644bb79059449c89740bf33670d66088d094447e7ea'
    state['go_version'] = subprocess.check_output(['/data/go/bin/go', 'version'], universal_newlines=True).strip()
    inputs = json.loads((P/'selected-inputs.json').read_text())
    assert [r['pair'] for r in inputs] == [458,2309,4147]
    for item in inputs:
        q = pathlib.Path(item['path'])
        assert str(q).startswith(str(PRIOR/'publish-new')+'/') and q.stat().st_size == item['size'] and sha(q) == item['sha256']
    write_json('inputs-before.json', inputs)
    overlay = {'Replace': {str(SOURCE/'core/state/snapshots/offline_shared_payload_study_test.go'): str(P/'offline_shared_payload_test.go')}}
    write_json('overlay.json', overlay)
    state['helper_sha256'] = sha(P/'offline_shared_payload_test.go')
    env = {k:v for k,v in os.environ.items() if not k.startswith('GTRON_')}
    env.update(PATH='/data/go/bin:'+env.get('PATH',''), GOCACHE='/root/.cache/go-build', GOPATH='/root/go', GOMODCACHE='/root/go/pkg/mod', GOMAXPROCS='2', GOMEMLIMIT='3GiB', CGO_ENABLED='1', GOTOOLCHAIN='local')
    write_json('effective-go-env.json', {k:env[k] for k in ['PATH','GOCACHE','GOPATH','GOMODCACHE','GOMAXPROCS','GOMEMLIMIT','GOTOOLCHAIN','CGO_ENABLED']})
    common = ['/data/go/bin/go','test','-overlay',str(P/'overlay.json')]
    check('native-bounds',common+['./core/state/snapshots','-run','^TestOfflineSharedPayloadBounds$','-count=1','-v','-timeout=180s'],env,300)
    check('native-race',common+['-race','./core/state/snapshots','-run','^TestOfflineSharedPayloadBounds$','-count=1','-v','-timeout=180s'],env,600)
    check('native-build',common+['-c','./core/state/snapshots','-o',str(P/'shared-study.test')],env,600)
    state['binary_sha256'] = sha(P/'shared-study.test')
    (P/'binary-build-info.txt').write_bytes(subprocess.check_output(['/data/go/bin/go','version','-m',str(P/'shared-study.test')],env=env))
    assert identity() == before, 'production changed externally before study'
    state['load_before'] = pathlib.Path('/proc/loadavg').read_text()
    state['mem_before'] = pathlib.Path('/proc/meminfo').read_text()
    check('real-pages',[str(P/'shared-study.test'),'-test.run=^TestOfflineSharedPayloadRealPages$','-test.v','-test.timeout=15m'],dict(env,GTRON_SHARED_STUDY=str(P)),1000)
    state['load_after'] = pathlib.Path('/proc/loadavg').read_text()
    state['mem_after'] = pathlib.Path('/proc/meminfo').read_text()
    rows = [json.loads(line) for line in (P/'pages.jsonl').read_text().splitlines()]
    assert len(rows) == 1817 and sum(r['AnnotationsRecovered'] for r in rows) == 1806
    summary = []
    for item in inputs:
        part = [r for r in rows if r['Pair'] == item['pair']]
        assert [r['Page'] for r in part] == list(range(len(part)))
        assert sum(r['OriginalMode'] < 0 for r in part) == item['plain_pages']
        assert [sum(r['OriginalMode'] == m for r in part) for m in range(3)] == item['column_key_modes']
        original, proposed = sum(r['OriginalBytes'] for r in part), sum(r['PrototypeBytes'] for r in part)
        timings = {}
        for key in ['OldEncodeNS','PrototypeEncodeNS','OldDecodeNS','PrototypeDecodeNS']:
            totals = [sum(r[key][i] for r in part) for i in range(3)]
            timings[key] = dict(round_total_ns=totals, median_total_ns=statistics.median(totals))
        summary.append(dict(pair=item['pair'], pages=len(part), original_page_bytes=original, prototype_page_bytes=proposed,
                            saved_page_bytes=original-proposed, file_control_bytes=item['size']-original,
                            plain_unannotated_pages=item['plain_pages'], prototype_modes=[sum(r['Costs']['selected']==m for r in part) for m in [-1,0,1,2]],
                            smaller=sum(r['PrototypeBytes']<r['OriginalBytes'] for r in part),
                            equal=sum(r['PrototypeBytes']==r['OriginalBytes'] for r in part),
                            larger=sum(r['PrototypeBytes']>r['OriginalBytes'] for r in part), timings=timings))
    write_json('summary.json', summary)
    assert inventory() == files
    write_json('source-after.json', inventory())
    assert sha(lib) == state['sapling_sha256']
    assert sha(P/'offline_shared_payload_test.go') == state['helper_sha256']
    assert all(sha(pathlib.Path(r['path']))==r['sha256'] for r in inputs)
    write_json('inputs-after.json', inputs)
    state.update(complete=True,phase='complete',pages=len(rows),columns_pages=1806,unannotated_plain_pages=11,
                 pages_sha256=sha(P/'pages.jsonl'),summary_sha256=sha(P/'summary.json'),production_after=identity())
    assert state['production_after'] == before, 'production changed externally'
    save()
except BaseException as error:
    state.update(phase='failed',error=repr(error),traceback=traceback.format_exc())
    save()
    raise
