import pathlib,json,hashlib,base64,subprocess,zipfile,io,datetime
m=json.loads('{"base":{"offline_shared_payload_test.go":"5915e897fab63bf13b3f59ac33aca8abcb201cadc13d13c9c2bbbab8ff396da2","run-study.py":"35fa0d70f4515a4fd47ded2347f37c559f8bf4b50ec3a0ab8051084e65059e41","selected-inputs.json":"c92d44a694f3ac5690937966c226d2e552104f52d23401757b5c1bf5bb61115d"},"expected_payload_sha256":"1e516a5ba95256f33a8a38ba8d4f56bb51150418451c1695f2de458450af2f78","manifest":{"local-bounds.log":{"bytes":160,"sha256":"c2b42d4f6d8e925a0099e91d0a56a35358ff3c40957efb7c3a0b90f3e6e7b33b"},"local-race.log":{"bytes":160,"sha256":"416187b42c2c09e7154af741303716503a7f9515369071319be9ebaf818fbdbe"},"local-status.json":{"bytes":476,"sha256":"d5d2bba93b0751979153442015a46394223049924ca47f33274ac52a4cc750bc"},"offline_shared_payload_test.go":{"bytes":16260,"sha256":"86378ea65aa3685f1752be89847a3ac39affb42f31e36b956873463ccef7773c"},"run-study.py":{"bytes":9224,"sha256":"45641b465aaea616fca946855036dbf69b76ecfd87e5bc9a38da142c33a7af29"},"selected-inputs.json":{"bytes":1163,"sha256":"c92d44a694f3ac5690937966c226d2e552104f52d23401757b5c1bf5bb61115d"}},"raw":{"local-bounds.log":"PT09IFJVTiAgIFRlc3RPZmZsaW5lU2hhcmVkUGF5bG9hZEJvdW5kcwotLS0gUEFTUzogVGVzdE9mZmxpbmVTaGFyZWRQYXlsb2FkQm91bmRzICgwLjE3cykKUEFTUwpvayAgCWdpdGh1Yi5jb20vdHJvbnByb3RvY29sL2dvLXRyb24vY29yZS9zdGF0ZS9zbmFwc2hvdHMJMS45MjNzCg==","local-race.log":"PT09IFJVTiAgIFRlc3RPZmZsaW5lU2hhcmVkUGF5bG9hZEJvdW5kcwotLS0gUEFTUzogVGVzdE9mZmxpbmVTaGFyZWRQYXlsb2FkQm91bmRzICgyLjI0cykKUEFTUwpvayAgCWdpdGh1Yi5jb20vdHJvbnByb3RvY29sL2dvLXRyb24vY29yZS9zdGF0ZS9zbmFwc2hvdHMJNi42NjVzCg==","local-status.json":"ewogICJnb192ZXJzaW9uIjogImdvIHZlcnNpb24gZ28xLjI3LjMgZGFyd2luL2FybTY0IiwKICAiaGVscGVyX3NoYTI1NiI6ICI4NjM3OGVhNjVhYTM2ODVmMTc1MmJlODk4NDdhM2FjMzlhZmZiNDJmMzFlMzZiOTU2ODczNDYzY2NlZjc3NzNjIiwKICAibmF0aXZlX3Jlc3VsdHNfcGVuZGluZyI6IHRydWUsCiAgInByaW9yX25hdGl2ZV9mYWlsdXJlIjogIkdvIG92ZXJsYXkgcmVqZWN0ZWQgYmVmb3JlIGNvbXBpbGF0aW9uIGJlY2F1c2Ugc3lzdGVtZCBlbnZpcm9ubWVudCBoYWQgbm8gbW9kdWxlIGNhY2hlIHBhdGgiLAogICJwcm9kdWN0X2dvX2ludmVudG9yeV9zaGEyNTYiOiAiMzI4MWI4ZmNkODMzZGYwMDY2ZWZiYTIzYWM2OGM2ZWQzMjlmOWExNTM0ZWE1YmU1Yzc1MDAyNjU1YjZlOTE1MCIsCiAgInByb2R1Y3Rpb25fbXV0YXRpb25zIjogZmFsc2UsCiAgInV0YyI6ICIyMDI2LTEwLTI2VDAzOjI4OjIxLjYwODg3NSswMDowMCIKfQo="},"run_replacements":[["history-columns-shared-payload-20261026-02","history-columns-shared-payload-20261026-03"],["    env.update(GOMAXPROCS=\'2\',","    env.update(PATH=\'/data/go/bin:\'+env.get(\'PATH\',\'\'), GOCACHE=\'/root/.cache/go-build\', GOPATH=\'/root/go\', GOMODCACHE=\'/root/go/pkg/mod\', GOMAXPROCS=\'2\',"],["    common = [\'/data/go/bin/go\'","    write_json(\'effective-go-env.json\', {k:env[k] for k in [\'PATH\',\'GOCACHE\',\'GOPATH\',\'GOMODCACHE\',\'GOMAXPROCS\',\'GOMEMLIMIT\',\'GOTOOLCHAIN\',\'CGO_ENABLED\']})\\n    common = [\'/data/go/bin/go\'"]]}')
sha=lambda b:hashlib.sha256(b).hexdigest()
a=pathlib.Path('/data/gtron/history-columns-shared-payload-20261026-02')
p=pathlib.Path('/data/gtron/history-columns-shared-payload-20261026-03')
assert not p.exists(), 'existing lab must be inspected, never overwritten'
def show(u):
    x=subprocess.run(['systemctl','show',u,'-p','LoadState','-p','ActiveState','-p','SubState','-p','MainPID','-p','ExecMainStatus','-p','MemoryLimit','-p','CPUQuotaPerSecUSec','-p','Nice'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,universal_newlines=True)
    return dict(l.split('=',1) for l in x.stdout.splitlines() if '=' in l)
unit='gtron-columns-shared-payload-study-20261026-03.service'
assert show(unit).get('LoadState')=='not-found'
failed=show('gtron-columns-shared-payload-study-20261026-02.service')
assert failed['MainPID']=='0' and failed['ExecMainStatus']=='1'
assert not (a/'pages.jsonl').exists()
state=json.loads((a/'study-status.json').read_text())
assert len(state['checks'])==1 and state['checks'][0]['returncode']==1
assert sha((a/'native-bounds.log').read_bytes())==state['checks'][0]['log_sha256']
assert b'Files beneath GOMODCACHE' in (a/'native-bounds.log').read_bytes()
values={}
for n,d in m['base'].items():
    b=(a/n).read_bytes();assert sha(b)==d
    if n=='offline_shared_payload_test.go':
        b=b.replace(b'history-columns-shared-payload-20261026-02',b'history-columns-shared-payload-20261026-03')
    if n=='run-study.py':
        s=b.decode()
        for old,new in m['run_replacements']:
            assert old in s;s=s.replace(old,new)
        b=s.encode()
    values[n]=b
values.update({n:base64.b64decode(v) for n,v in m['raw'].items()})
for n,v in m['manifest'].items():
    assert len(values[n])==v['bytes'] and sha(values[n])==v['sha256']
values['payload-manifest.json']=(json.dumps(m['manifest'],sort_keys=True,indent=2)+'\n').encode()
blob=io.BytesIO()
with zipfile.ZipFile(blob,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,b in sorted(values.items()):
        zi=zipfile.ZipInfo(n);zi.compress_type=zipfile.ZIP_DEFLATED;zi.external_attr=0o600<<16
        z.writestr(zi,b,compresslevel=9)
payload=blob.getvalue()
assert sha(payload)==m['expected_payload_sha256']
prod=show('gtron.service');p.mkdir(mode=0o700)
for n,b in values.items():
    with (p/n).open('xb') as f:f.write(b)
(p/'study-payload.zip').write_bytes(payload)
(p/'frozen-source-inventory.json').write_bytes((a/'frozen-source-inventory.json').read_bytes())
receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),unit=unit,payload_sha256=sha(payload),payload_bytes=len(payload),production_before=prod,prior_failed_unit=failed,production_mutations=False)
(p/'dispatch.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
x=subprocess.run(['systemd-run','--unit='+unit,'--description=Private shared payload study with explicit Go environment','--property=MemoryLimit=4G','--property=CPUQuota=200%','--property=Nice=15','/usr/bin/ionice','-c3','/usr/bin/python3',str(p/'run-study.py')],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,universal_newlines=True)
(p/'dispatch-output.txt').write_text(x.stdout)
assert x.returncode==0,x.stdout
receipt.update(dispatched=True,observed_unit=show(unit),production_after=show('gtron.service'))
assert receipt['production_before']==receipt['production_after']
(p/'start-receipt.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
print('THIRD_STUDY_DISPATCHED',receipt['observed_unit']['MainPID'],sha(payload))
