import pathlib,json,hashlib,base64,subprocess,zipfile,io,datetime
m=json.loads(REQUEST_JSON)
sha=lambda b:hashlib.sha256(b).hexdigest()
a=pathlib.Path('/data/gtron/history-columns-shared-payload-20261026-02')
p=pathlib.Path('/data/gtron/history-columns-shared-payload-20261026-03')
assert not p.exists(), 'existing lab must be inspected, never overwritten'
def show(u):
    x=subprocess.run(['systemctl','show',u,'-p','LoadState','-p','ActiveState','-p','SubState','-p','MainPID','-p','ExecMainStatus','-p','MemoryLimit','-p','CPUQuotaPerSecUSec','-p','Nice'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,universal_newlines=True)
    return dict(l.split('=',1) for l in x.stdout.splitlines() if '=' in l)
unit='gtron-columns-shared-payload-study-20261026-03.service'
assert show(unit).get('LoadState')=='not-found'
failed=show('gtron-columns-shared-payload-study-20261026-02.service')
assert failed['MainPID']=='0' and failed['ExecMainStatus']=='1'
assert not (a/'pages.jsonl').exists()
state=json.loads((a/'study-status.json').read_text())
assert len(state['checks'])==1 and state['checks'][0]['returncode']==1
assert sha((a/'native-bounds.log').read_bytes())==state['checks'][0]['log_sha256']
assert b'Files beneath GOMODCACHE' in (a/'native-bounds.log').read_bytes()
values={}
for n,d in m['base'].items():
    b=(a/n).read_bytes();assert sha(b)==d
    if n=='offline_shared_payload_test.go':
        b=b.replace(b'history-columns-shared-payload-20261026-02',b'history-columns-shared-payload-20261026-03')
    if n=='run-study.py':
        s=b.decode()
        for old,new in m['run_replacements']:
            assert old in s;s=s.replace(old,new)
        b=s.encode()
    values[n]=b
values.update({n:base64.b64decode(v) for n,v in m['raw'].items()})
for n,v in m['manifest'].items():
    assert len(values[n])==v['bytes'] and sha(values[n])==v['sha256']
values['payload-manifest.json']=(json.dumps(m['manifest'],sort_keys=True,indent=2)+'\n').encode()
blob=io.BytesIO()
with zipfile.ZipFile(blob,'w',zipfile.ZIP_STORED) as z:
    for n,b in sorted(values.items()):
        zi=zipfile.ZipInfo(n);zi.compress_type=zipfile.ZIP_STORED;zi.external_attr=0o600<<16
        z.writestr(zi,b)
payload=blob.getvalue()
assert sha(payload)==m['expected_payload_sha256']
prod=show('gtron.service');p.mkdir(mode=0o700)
for n,b in values.items():
    with (p/n).open('xb') as f:f.write(b)
(p/'study-payload.zip').write_bytes(payload)
(p/'frozen-source-inventory.json').write_bytes((a/'frozen-source-inventory.json').read_bytes())
receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),unit=unit,payload_sha256=sha(payload),payload_bytes=len(payload),production_before=prod,prior_failed_unit=failed,production_mutations=False)
(p/'dispatch.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
x=subprocess.run(['systemd-run','--unit='+unit,'--description=Private shared payload study with explicit Go environment','--property=MemoryLimit=4G','--property=CPUQuota=200%','--property=Nice=15','/usr/bin/ionice','-c3','/usr/bin/python3',str(p/'run-study.py')],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,universal_newlines=True)
(p/'dispatch-output.txt').write_text(x.stdout)
assert x.returncode==0,x.stdout
receipt.update(dispatched=True,observed_unit=show(unit),production_after=show('gtron.service'))
assert receipt['production_before']==receipt['production_after']
(p/'start-receipt.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
print('THIRD_STUDY_DISPATCHED',receipt['observed_unit']['MainPID'],sha(payload))
