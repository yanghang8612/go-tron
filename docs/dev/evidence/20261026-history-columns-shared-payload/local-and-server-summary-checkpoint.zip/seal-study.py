import datetime
import hashlib
import io
import json
import pathlib
import subprocess
import tarfile

P = pathlib.Path('/data/gtron/history-columns-shared-payload-20261026-03')
state = json.loads((P/'study-status.json').read_text())
assert state['complete'] and state['phase'] == 'complete'
assert len(state['checks']) == 4 and all(r['returncode'] == 0 for r in state['checks'])
assert state['production_before'] == state['production_after']
assert (P/'source-before.json').read_bytes() == (P/'source-after.json').read_bytes()
assert (P/'inputs-before.json').read_bytes() == (P/'inputs-after.json').read_bytes()
assert len((P/'pages.jsonl').read_text().splitlines()) == 1817
unit = subprocess.check_output(['systemctl','show','gtron-columns-shared-payload-study-20261026-03.service',
                                '-p','ActiveState','-p','MainPID','-p','ExecMainStatus'],universal_newlines=True)
fields = dict(line.split('=',1) for line in unit.splitlines() if '=' in line)
assert fields['MainPID'] == '0' and fields['ActiveState'] != 'active' and fields['ExecMainStatus'] == '0'
names = ['study-status.json','pages.jsonl','summary.json','selected-inputs.json',
         'source-before.json','source-after.json','frozen-source-inventory.json',
         'inputs-before.json','inputs-after.json','offline_shared_payload_test.go',
         'run-study.py','local-status.json','local-bounds.log','local-race.log',
         'native-bounds.log','native-race.log','native-build.log','real-pages.log',
         'binary-build-info.txt','overlay.json','study-payload.zip','payload-manifest.json',
         'dispatch.json','dispatch-output.txt','start-receipt.json','seal-study.py','effective-go-env.json']
members = {name:(P/name).read_bytes() for name in names}
for prefix, directory, extra_names in [('prior01', pathlib.Path('/data/gtron/history-columns-shared-payload-20261026-01'), ['study-status.json','start-receipt.json','native-inventory-preflight.json']), ('prior02', pathlib.Path('/data/gtron/history-columns-shared-payload-20261026-02'), ['study-status.json','start-receipt.json','native-bounds.log','overlay.json'])]:
    for name in extra_names:
        members[prefix+'-'+name]=(directory/name).read_bytes()
if (P/'pulse-01.json').exists():members['pulse-01.json']=(P/'pulse-01.json').read_bytes()
terminal = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),unit=fields,
                production_mutations=False,scope=state['scope'])
members['terminal-unit.json']=(json.dumps(terminal,sort_keys=True,indent=2)+'\n').encode()
manifest = {name:dict(bytes=len(value),sha256=hashlib.sha256(value).hexdigest()) for name,value in sorted(members.items())}
members['evidence-manifest.json']=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
with tarfile.open(str(P/'study-core.tar.xz'),'x:xz',preset=9) as tar:
    for name,value in sorted(members.items()):
        info=tarfile.TarInfo(name);info.size=len(value);info.mtime=0;info.mode=0o600
        tar.addfile(info,io.BytesIO(value))
q=P/'study-core.tar.xz';s=q.stat()
seal=dict(utc=terminal['utc'],name=q.name,bytes=s.st_size,members=len(members),
          sha256=hashlib.sha256(q.read_bytes()).hexdigest(),device=str(s.st_dev),inode=str(s.st_ino),mtime_ns=str(s.st_mtime_ns),
          unit=fields,binary_sha256=state['binary_sha256'],helper_sha256=state['helper_sha256'],production_mutations=False)
(P/'study-seal.json').write_text(json.dumps(seal,sort_keys=True,indent=2)+'\n')
print(json.dumps(seal,sort_keys=True))
