package snapshots

// A separate overlay-only decoder experiment. The measured original HSP1
// helper, binary and all real-page results remain frozen.
import (
	"bytes"
	"encoding/binary"
	"fmt"
	"sync"
	"testing"
)

func decodeSharedStudyScratch(comp []byte, expected uint64, dst, scratch []byte) (out, retained []byte, err error) {
	retained = scratch
	if expected == 0 || expected > historyRecordColumnPageMax || len(comp) < 2 || len(comp) > historyRecordColumnStoredMax {
		return nil, retained, errHistoryRecordColumns
	}
	if comp[0] == 0 {
		out, _, err = decodeRecordColumnStoredPage(comp, expected, dst, nil)
		return out, retained, err
	}
	if comp[0] != 2 || len(comp) < 49 || string(comp[1:5]) != "HSP1" {
		return nil, retained, errHistoryRecordColumns
	}
	h := comp[1:49]
	get := func(at int) uint64 { return uint64(binary.BigEndian.Uint32(h[at : at+4])) }
	n, count, first, kl, tl, ll, mode := get(4), get(8), get(12), get(16), get(20), get(24), get(28)
	kc, tail, tc := get(36), get(40), get(44)
	flags := (count + 7) / 8
	if n != expected || count == 0 || count > n/21 || first > n-21 || mode > 2 ||
		kl < count || kl > 5*count || mode == 2 && kl != 4*count ||
		tl < count || tl > 10*count || ll < count || ll > 5*count ||
		tail != tl+ll+flags+n-21*count || kl+tail > n ||
		kc < 1 || tc < 1 || kc > 2*kl+256 || tc > 2*tail+256 || 49+kc+tc != uint64(len(comp)) {
		return nil, retained, errHistoryRecordColumns
	}
	dec, err := recordColumnCodecDecoder()
	if err != nil {
		return nil, retained, err
	}
	limit := int(36 + kl + tail)
	if cap(scratch) < limit {
		scratch = make([]byte, 0, limit)
	}
	retained = scratch[:0]
	packed := scratch[:36:limit]
	copy(packed, h[:36])
	copy(packed, "HRC2")
	// Each full slice expression imposes the exact decoded output cap for its
	// frame. Retaining a larger backing array never weakens that per-frame cap.
	keys, err := dec.DecodeAll(comp[49:49+kc], packed[:36:36+kl])
	if err != nil || uint64(len(keys)) != 36+kl {
		return nil, retained, errHistoryRecordColumns
	}
	packed = packed[:36+kl]
	copy(packed[36:], keys[36:])
	transformed, err := dec.DecodeAll(comp[49+kc:], packed[:36+kl:36+kl+tail])
	if err != nil || uint64(len(transformed)) != 36+kl+tail {
		return nil, retained, errHistoryRecordColumns
	}
	out, err = decodeHistoryRecordColumns(transformed, expected, dst)
	return out, retained, err
}

func TestOfflineSharedScratchBoundsAndReuse(t *testing.T) {
	enc, _, err := cbCodec()
	if err != nil {
		t.Fatal(err)
	}
	var scratch []byte
	var e sharedStudyEncoder
	for seed := int64(0); seed < 80; seed++ {
		raw, starts := recordColumnEncoderPage(seed, []int{historyRecordColumnPageMax, 4096, 127, 21, 65535}[seed%5])
		if len(starts) == 0 {
			continue
		}
		for mode := 0; mode < 3; mode++ {
			comp, err := forceSharedStudy(raw, starts, enc, mode)
			if err != nil {
				t.Fatal(err)
			}
			out, retained, err := decodeSharedStudyScratch(comp, uint64(len(raw)), nil, scratch)
			if err != nil || !bytes.Equal(out, raw) || cap(retained) > historyRecordColumnPageMax+36 {
				t.Fatalf("seed=%d mode=%d: %v", seed, mode, err)
			}
			// Returned canonical values must survive the next use of scratch.
			saved := bytes.Clone(out)
			clear(retained[:cap(retained)])
			if !bytes.Equal(saved, out) {
				t.Fatal("canonical bytes alias retained scratch")
			}
			scratch = retained
		}
		plain, _, err := e.encode(raw, nil, enc)
		if err != nil {
			t.Fatal(err)
		}
		if out, _, err := decodeSharedStudyScratch(plain, uint64(len(raw)), nil, scratch); err != nil || !bytes.Equal(out, raw) {
			t.Fatal("plain fallback", err)
		}
	}
	raw, starts := recordColumnEncoderPage(12, 4096)
	comp, err := forceSharedStudy(raw, starts, enc, 0)
	if err != nil {
		t.Fatal(err)
	}
	for i := 0; i < len(comp); i++ {
		if _, _, err := decodeSharedStudyScratch(comp[:i], uint64(len(raw)), nil, scratch); err == nil {
			t.Fatal("truncation accepted", i)
		}
	}
	for _, at := range []int{0, 1, 5, 9, 13, 17, 21, 25, 29, 33, 37, 41, 45, len(comp) - 1} {
		bad := bytes.Clone(comp)
		bad[at] ^= 0x80
		if _, _, err := decodeSharedStudyScratch(bad, uint64(len(raw)), nil, scratch); err == nil {
			t.Fatal("bad header or CRC accepted", at)
		}
	}
	// Reused 128 KiB scratch must not allow a key frame to exceed its small
	// declared output cap, even when its uncompressed FCS fits the backing array.
	if err := e.columns.prepare(raw, starts); err != nil {
		t.Fatal(err)
	}
	e.tail = enc.EncodeAll(e.columns.packed[e.columns.tailStart:e.columns.packedBytes], nil)
	e.key = enc.EncodeAll(make([]byte, historyRecordColumnPageMax), nil)
	bad := e.pack(0)
	if _, _, err := decodeSharedStudyScratch(bad, uint64(len(raw)), nil, scratch); err == nil {
		t.Fatal("reused scratch weakened key-frame cap")
	}
	if out, _, err := decodeSharedStudyScratch(comp, uint64(len(raw)), nil, scratch); err != nil || !bytes.Equal(out, raw) {
		t.Fatal("recovery after rejection", err)
	}
}

func TestOfflineSharedScratchConcurrentOwnership(t *testing.T) {
	enc, _, err := cbCodec()
	if err != nil {
		t.Fatal(err)
	}
	type fixture struct{ raw, stored []byte }
	fixtures := make([]fixture, 8)
	for i := range fixtures {
		raw, starts := recordColumnEncoderPage(int64(7+i), 32768+i*113)
		stored, err := forceSharedStudy(raw, starts, enc, i%3)
		if err != nil {
			t.Fatal(err)
		}
		fixtures[i] = fixture{raw, stored}
	}
	var group sync.WaitGroup
	errors := make(chan error, len(fixtures))
	for worker, data := range fixtures {
		group.Add(1)
		go func(worker int, data fixture) {
			defer group.Done()
			var scratch []byte
			for round := 0; round < 20; round++ {
				out, retained, err := decodeSharedStudyScratch(data.stored, uint64(len(data.raw)), nil, scratch)
				if err != nil || !bytes.Equal(out, data.raw) {
					errors <- fmt.Errorf("worker %d round %d: %v", worker, round, err)
					return
				}
				clear(retained[:cap(retained)])
				if !bytes.Equal(out, data.raw) {
					errors <- fmt.Errorf("worker %d canonical bytes alias scratch", worker)
					return
				}
				scratch = retained
			}
		}(worker, data)
	}
	group.Wait()
	close(errors)
	for err := range errors {
		t.Error(err)
	}
}
