import pathlib,json,hashlib,collections,statistics,subprocess,datetime,zipfile,os
P=pathlib.Path('/data/gtron/kv-inline-directory-20261024-01');OLD=pathlib.Path('/data/gtron/kv-accessor-analysis-20261024-01');R=P/'tail-read-comparison'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def write(n,x):(P/n).write_text(json.dumps(x,indent=2))
assert read(P/'pipeline-status.json')['complete'];assert read(P/'corpus-status.json')['complete']
original={x['path']:x for x in (json.loads(l) for l in (OLD/'final-files.jsonl').open())};a=collections.Counter();allocated0=allocated1=0;wins=losses=equal=0;largest=[];seen=set();endchecks=[]
for line in (P/'corpus-files.jsonl').open():
 x=json.loads(line);src=x['source'];dst=x['candidate'];p=src['path'];assert p not in seen;seen.add(p);o=original[p];v=x['audit'];assert src['size']==o['size']==v['SourceBytes'];assert src['checksum']=='sha256:'+o['sha256'];assert v['Keys']==o['counts']['keys'] and v['Records']==o['counts']['records'];assert v['Singletons']==o['counts'].get('key_count_bucket/1',0);assert v['Singletons']+v['MultiLists']==v['Keys'];assert bytes(v['DictionaryDigest']).hex()==o['dictionary_digest'];assert v['MultiBytesCompared']==o['counts']['posting_bytes']-o['counts'].get('posting_bytes_bucket/1',0)
 for k,value in v.items():
  if k!='DictionaryDigest':a[k]+=value
 out=P/'corpus-v8'/p
 with out.open('rb') as durable:os.fsync(durable.fileno())
 digest=sha(out);assert 'sha256:'+digest==dst['checksum'];endchecks.append({'path':p,'sha256':digest})
 st=out.stat();assert st.st_size==dst['size']==v['CandidateBytes'];assert st.st_ino==x['candidate_inode'];allocated1+=st.st_blocks*512;allocated0+=(OLD/'fixed'/p).stat().st_blocks*512
 gain=src['size']-dst['size'];wins+=gain>0;losses+=gain<0;equal+=gain==0;largest.append({'path':p,'source_bytes':src['size'],'candidate_bytes':dst['size'],'saved_bytes':gain})
write('end-output-checksums.json',endchecks)
assert len(seen)==19949==len(original);assert a['SourceBytes']==154037203799;assert a['Keys']==2443423104 and a['Records']==14302423656;assert a['Singletons']==1847492115;assert a['MultiBytesCompared']==78206162033
old=read(OLD/'final-summary.json')['counts'];components=[{'part':'header','source':old['header_bytes'],'candidate':old['header_bytes']},{'part':'directory','source':old['directory_bytes'],'candidate':old['directory_bytes']+a['SparseBytes']},{'part':'key_pages','source':old['key_stored_bytes'],'candidate':a['CandidateBytes']-old['header_bytes']-old['directory_bytes']-a['SparseBytes']-a['MultiBytesCompared']},{'part':'external_postings','source':old['posting_bytes'],'candidate':a['MultiBytesCompared']}]
assert sum(c['source'] for c in components)==a['SourceBytes'];assert sum(c['candidate'] for c in components)==a['CandidateBytes'];largest.sort(key=lambda x:x['saved_bytes'],reverse=True)
write('space-final.json',{'complete':True,'files':len(seen),'counts':dict(a),'saved_bytes':a['SourceBytes']-a['CandidateBytes'],'saved_percent':100*(1-a['CandidateBytes']/a['SourceBytes']),'source_allocated':allocated0,'candidate_allocated':allocated1,'allocated_saved_bytes':allocated0-allocated1,'smaller_files':wins,'larger_files':losses,'equal_files':equal,'components':components,'largest_savings':largest[:20],'largest_growth':list(reversed(largest[-20:]))})
rows=[json.loads(l) for l in (R/'requests.jsonl').open()];assert all(x['correct'] for x in rows);assert read(R/'comparison-status.json')['complete'];resources={}
for f in R.glob('*/server-requests.jsonl'):
 mode='candidate' if 'candidate' in f.parent.name else 'baseline'
 for line in f.open():
  x=json.loads(line);key=(mode,x['id']);
  if x['id']==999999:continue
  assert key not in resources;resources[key]=x
measured=[]
def tv(x):return x['Sec']*1000+x['Usec']/1000
def io(x):return {k:int(v) for k,v in (l.split(':',1) for l in x.splitlines())}
for r in rows:
 x=resources[(r['mode'],r['id'])];assert x['params'][1]==r['tag'];z=dict(r);z['server_ms']=x['elapsed_ns']/1e6;z['alloc_bytes']=x['alloc_bytes'];z['cpu_ms']=sum(tv(x['usage_after'][k])-tv(x['usage_before'][k]) for k in ['Utime','Stime']);before=io(x['io_before']);after=io(x['io_after']);z.update({k:after[k]-before[k] for k in ['rchar','syscr','read_bytes']});measured.append(z)
groups=collections.defaultdict(list)
for r in measured:
 if r['cache'] in ['warm','fresh-process-os-uncontrolled','private-os-cold-fresh-process']:groups[(r['mode'],r['cache'],r['tag'])].append(r)
metrics=['milliseconds','server_ms','cpu_ms','alloc_bytes','rchar','syscr','read_bytes'];summary=[]
for (mode,cache,tag),v in sorted(groups.items()):
 summary.append({'mode':mode,'cache':cache,'tag':tag,'height':v[0]['height'],'n':len(v),**{k:{'median':statistics.median(x[k] for x in v),'min':min(x[k] for x in v),'max':max(x[k] for x in v)} for k in metrics}})
write('http-resource-summary.json',summary)
proofs=[read(q) for q in R.glob('os-cold-*-residency.json')];assert len(proofs)==56 and all(x['fraction']<0.01 for x in proofs)
ready=read(R/'comparison-status.json')['head']
def normalize_hash(value):
 # The unchanged old host used fmt %x on a Stringer, logging ASCII hex twice.
 try:
  decoded=bytes.fromhex(value).decode('ascii')
  if len(decoded)==64 and all(c in '0123456789abcdefABCDEF' for c in decoded):return decoded.lower()
 except (ValueError,UnicodeError):pass
 return value.lower()
normalized=dict(ready)
for name in ['head_hash','root']:normalized[name]=normalize_hash(ready[name])
assert normalized['root']=='8fbf149684146a59b1650b318a768f0edbae0c8c1c3ceb2c5c610129c10f76a5'
write('http-final.json',{'complete':True,'all_responses_correct':True,'requests':len(rows),'measured_requests':sum(len(v) for v in groups.values()),'cold_residency_proofs':len(proofs),'max_pre_start_residency':max(x['fraction'] for x in proofs),'head':normalized,'raw_host_head':ready,'host_hash_display_note':'Host fmt %x used a Stringer; normalized head/root decode one ASCII-hex layer only. Original ready receipts are retained.','baseline_sha256':sha(P/'baseline.test'),'candidate_sha256':sha(P/'candidate.test'),'oracle_specs_sha256':sha(R/'specs.json')})
# Preserve exact production process identity; no service actions.
x=dict(l.split('=',1) for l in subprocess.check_output(['systemctl','show','gtron','-p','MainPID','-p','ActiveState','-p','ExecMainStartTimestamp']).decode().splitlines());pid=int(x['MainPID']);x.update(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exe=os.readlink('/proc/%d/exe'%pid) if pid else None,sha256=sha(pathlib.Path('/proc/%d/exe'%pid)) if pid else None,cpu_count=os.cpu_count(),load=os.getloadavg(),meminfo=pathlib.Path('/proc/meminfo').read_text(),df=subprocess.check_output(['df','-B1','/data','/']).decode());write('final-context.json',x)
identity=read(P/'source-identity.json')
for variant,source in [('baseline',P/'baseline-source'),('candidate',P/'candidate-source')]:
 for name,digest in identity['source_inventories'][variant].items():assert sha(source/name)==digest,(variant,name)
write('toolchain-final.json',{'go_version':subprocess.check_output(['/data/go/bin/go','version']).decode().strip(),'sapling_sha256':sha(P/'candidate-source/third_party/librustzcash/target/release/librustzcash.a'),'production_source_hashes_unchanged':True})
files=[]
for q in P.iterdir():
 if q.is_file() and (q.suffix in ['.json','.jsonl','.log','.py','.txt','.gz','.bin']):files.append(q)
for q in R.rglob('*'):
 if q.is_file() and not any(part.endswith('-input') for part in q.relative_to(R).parts):files.append(q)
checks={str(q.relative_to(P)):sha(q) for q in files};write('evidence-sha256.json',checks);files.append(P/'evidence-sha256.json')
zpath=pathlib.Path('/tmp/gtron-kv-inline-directory-final-20261024-01.zip')
with zipfile.ZipFile(str(zpath),'w',zipfile.ZIP_DEFLATED) as z:
 for q in files:z.write(str(q),str(q.relative_to(P)))
os.chmod(str(zpath),0o644);print('EVIDENCE_ZIP',zpath.stat().st_size,sha(zpath));print((P/'space-final.json').read_text()[:2300]);print((P/'http-final.json').read_text())
