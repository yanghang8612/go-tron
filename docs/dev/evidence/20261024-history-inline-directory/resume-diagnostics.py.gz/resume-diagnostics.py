import ast,collections,contextlib,datetime,hashlib,json,os,pathlib,shutil,signal,statistics,subprocess,threading,time,traceback,urllib.request
LAB=pathlib.Path('/data/gtron/kv-inline-directory-20261024-01');ROOT=LAB/'tail-read-comparison';INPUT=pathlib.Path('/data/gtron/eth-call-fixed-20261020-01/capture-1');ADDR='0xa4997124a328a4615eab437cede31da47a31b375';inputs={x:LAB/(x+'-input') for x in ('baseline','candidate')}
state=json.loads((ROOT/'comparison-status.json').read_text());results=[json.loads(l) for l in (ROOT/'requests.jsonl').open()];specs=json.loads((ROOT/'specs.json').read_text());assert len(results)==282 and all(x['correct'] for x in results)
shutil.copy2(ROOT/'comparison-status.json',ROOT/'diagnostic-tool-failure-status.json');shutil.copy2(LAB/'pipeline-status.json',LAB/'pipeline-before-diagnostic-repair.json')
module=ast.parse((LAB/'compare.py').read_text());functions=[x for x in module.body if isinstance(x,ast.FunctionDef) and x.name in ['save','identity','waitfor','request','host','call']];exec(compile(ast.Module(body=functions),str(LAB/'compare.py'),'exec'))
env=dict(os.environ,PATH='/data/go/bin:'+os.environ.get('PATH',''),GOCACHE='/root/.cache/go-build',GOTOOLCHAIN='local',GOMAXPROCS='2',GOMEMLIMIT='3GiB')
def top(mode,directory):
 target=directory/'cpu-top.txt'
 if target.exists():shutil.copy2(target,directory/'cpu-top-first-attempt.txt')
 with target.open('wb') as out:subprocess.run(['/data/go/bin/go','tool','pprof','-top','-nodecount=40',str(LAB/(mode+'.test')),str(directory/'cpu.pprof')],stdout=out,stderr=subprocess.STDOUT,env=env,check=True,timeout=180)
 with (directory/'cpu-cumulative.txt').open('wb') as out:subprocess.run(['/data/go/bin/go','tool','pprof','-top','-cum','-nodecount=60',str(LAB/(mode+'.test')),str(directory/'cpu.pprof')],stdout=out,stderr=subprocess.STDOUT,env=env,check=True,timeout=180)
def profile(mode,name,spec):
 state['phase']=name;save()
 with host(mode,name,input_=inputs[mode]) as (ready,directory):
  call(mode,ready,spec,'profile-warmup-excluded',0);errors=[];count=[0]
  def workload():
   start=time.monotonic()
   try:
    while time.monotonic()-start<12:
     response=request(ready['url'],'eth_call',[{'to':ADDR,'data':'0x9fa6a6e3'},spec['tag']],999999)
     assert response.get('result')==spec['expected'] and 'error' not in response
     count[0]+=1
   except BaseException as e:errors.append(repr(e))
  thread=threading.Thread(target=workload);thread.start()
  with urllib.request.urlopen(ready['url']+'debug/pprof/profile?seconds=10',timeout=30) as response:(directory/'cpu.pprof').write_bytes(response.read())
  thread.join(timeout=30);assert not thread.is_alive() and not errors,errors
  (directory/'workload.json').write_text(json.dumps({'responses_correct':True,'requests':count[0]}));top(mode,directory)
try:
 state['phase']='repair-pprof-tool-environment';save();top('baseline',ROOT/'nine-million-profile-baseline')
 nine=next(x for x in specs if x['height']==9000000)
 with host('candidate','nine-million-trace-candidate',input_=inputs['candidate'],trace=True) as (ready,directory):call('candidate',ready,nine,'trace-excluded',0)
 profile('candidate','nine-million-profile-candidate',nine)
 # Diagnose the observed oldest-height warm CPU increase without changing or
 # replacing any measured request. These requests remain explicitly excluded.
 old=next(x for x in specs if x['height']==3144020)
 for mode in ('baseline','candidate'):
  with host(mode,'birth-height-trace-'+mode,input_=inputs[mode],trace=True) as (ready,directory):call(mode,ready,old,'trace-excluded',0)
  profile(mode,'birth-height-profile-'+mode,old)
 grouped=collections.defaultdict(list)
 for row in results:
  if row['cache'] in ('warm','fresh-process-os-uncontrolled','private-os-cold-fresh-process'):grouped[(row['mode'],row['cache'],row['tag'])].append(row['milliseconds'])
 summary=[{'mode':a,'cache':b,'tag':c,'n':len(v),'median_ms':statistics.median(v),'min_ms':min(v),'max_ms':max(v)} for (a,b,c),v in sorted(grouped.items())]
 assert sum(len(x) for x in grouped.values())==238
 (ROOT/'summary.json').write_text(json.dumps(summary,indent=2));state['after_identity']=identity();assert state['before_identity']==state['after_identity'];state.pop('error',None);state.pop('traceback',None);state.update(complete=True,phase='complete',requests=len(results),all_responses_correct=all(x['correct'] for x in results),diagnostic_repair={'reason':'go tool pprof required GOCACHE in the transient systemd environment','measured_requests_repeated':0,'additional_oldest_height_diagnostics':True});save()
 for name in ['corpus-status.json','muhash-census.json','history-restore.json']:assert json.loads((LAB/name).read_text())['complete']
 (LAB/'pipeline-status.json').write_text(json.dumps({'complete':True,'phase':'complete','production_mutations':False,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'recovered_diagnostic_tool_error':True,'original_status':'pipeline-before-diagnostic-repair.json'},indent=2))
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
