import os,pathlib,json,shutil,sys,subprocess,datetime,traceback,hashlib,collections,statistics,threading,time,urllib.request
P=pathlib.Path('/data/gtron/history-offset-pages-20261024-01');R=P/'tail-read-comparison'
os.environ['GOCACHE']='/root/.cache/go-build'
for name in ['pipeline-status.json','finalizer-status.json','tail-read-comparison/comparison-status.json','comparison.log']:
 q=P/name;copy=q.with_name(q.stem+'.initial-failed'+q.suffix);assert not copy.exists();shutil.copy2(q,copy)
first=R/'nine-million-profile-baseline/cpu-top.txt';shutil.copy2(first,first.with_name('cpu-top-initial-failed.txt'))
initial_rows=(R/'requests.jsonl').read_bytes();initial_timed=[x for x in map(json.loads,initial_rows.splitlines()) if x['cache'] in ['warm','fresh-process-os-uncontrolled','private-os-cold-fresh-process']];assert len(initial_timed)==238 and all(x['correct'] for x in initial_timed)
recovery={'complete':False,'production_mutations':False,'phase':'diagnostics-only','initial_timed_rows':238,'timed_json_sha256':hashlib.sha256(json.dumps(initial_timed,sort_keys=True).encode()).hexdigest(),'reason':'go tool pprof lacked GOCACHE/HOME; original timing samples retained, no timing rerun','premature_perf_archive_attempt':'asserted pipeline completion and exited before writing any archive'}
def receipt():
 recovery['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(P/'diagnostic-recovery.json').write_text(json.dumps(recovery,indent=2))
try:
 receipt();sys.argv=['compare.py','tail-read']
 prefix=(P/'compare.py').read_text().split('\ntry:\n state[',1)[0].replace('ROOT.mkdir(exist_ok=False)','assert ROOT.is_dir()')
 ns={};exec(compile(prefix,str(P/'compare.py'), 'exec'),ns)
 ns['state']=json.loads((R/'comparison-status.json').read_text());ns['state'].pop('error',None);ns['state'].pop('traceback',None);ns['results']=list(map(json.loads,initial_rows.splitlines()));ns['inputs']={'baseline':P/'baseline-input','candidate':P/'candidate-input'};ns['specs']=json.loads((R/'specs.json').read_text())
 ns['state']['phase']='diagnostics-recovery';ns['save']()
 def pprof(mode):
  d=R/('nine-million-profile-'+mode)
  with (d/'cpu-top.txt').open('wb') as out:subprocess.run(['/data/go/bin/go','tool','pprof','-top','-nodecount=35',str(P/(mode+'.test')),str(d/'cpu.pprof')],env=dict(os.environ,GOCACHE='/root/.cache/go-build'),stdout=out,stderr=subprocess.STDOUT,check=True,timeout=120)
 pprof('baseline')
 nine=next(s for s in ns['specs'] if s['tag']==hex(9000000));mode='candidate'
 with ns['host'](mode,'nine-million-trace-'+mode,input_=ns['inputs'][mode],trace=True) as (ready,directory):ns['call'](mode,ready,nine,'trace-excluded',0)
 with ns['host'](mode,'nine-million-profile-'+mode,input_=ns['inputs'][mode]) as (ready,directory):
  ns['call'](mode,ready,nine,'profile-warmup-excluded',0);errors=[];count=[0]
  def workload():
   start=time.monotonic()
   try:
    while time.monotonic()-start<12:
     response=ns['request'](ready['url'],'eth_call',[{'to':ns['ADDR'],'data':'0x9fa6a6e3'},nine['tag']],999999);assert response.get('result')==nine['expected'] and 'error' not in response;count[0]+=1
   except BaseException as e:errors.append(repr(e))
  thread=threading.Thread(target=workload);thread.start()
  with urllib.request.urlopen(ready['url']+'debug/pprof/profile?seconds=10',timeout=30) as response:(directory/'cpu.pprof').write_bytes(response.read())
  thread.join(timeout=30);assert not thread.is_alive() and not errors,(count,errors);(directory/'workload.json').write_text(json.dumps({'responses_correct':True,'requests':count[0]}))
 pprof('candidate')
 rows=ns['results'];assert (R/'requests.jsonl').read_bytes().startswith(initial_rows)
 timed=[x for x in rows if x['cache'] in ['warm','fresh-process-os-uncontrolled','private-os-cold-fresh-process']];assert timed==initial_timed
 grouped=collections.defaultdict(list)
 for x in timed:grouped[(x['mode'],x['cache'],x['tag'])].append(x['milliseconds'])
 summary=[{'mode':a,'cache':b,'tag':c,'n':len(v),'median_ms':statistics.median(v),'min_ms':min(v),'max_ms':max(v)} for (a,b,c),v in sorted(grouped.items())];(R/'summary.json').write_text(json.dumps(summary,indent=2))
 ns['state']['after_identity']=ns['identity']();ns['state']['environment_identity_changed']=ns['state']['before_identity']!=ns['state']['after_identity'];ns['state'].update(complete=True,phase='complete',requests=len(rows),all_responses_correct=all(x['correct'] for x in rows),diagnostic_recovery=True);ns['save']()
 pipeline=json.loads((P/'pipeline-status.json').read_text());pipeline.pop('error',None);pipeline.pop('traceback',None);pipeline.update(complete=True,phase='complete',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),diagnostic_recovery=True);(P/'pipeline-status.json').write_text(json.dumps(pipeline,indent=2))
 recovery.update(complete=True,phase='complete',final_timed_rows=len(timed),total_rows=len(rows),original_timed_rows_unchanged=True);receipt()
 subprocess.run(['/usr/bin/python3',str(P/'run-finalize.py')],check=True,timeout=5500)
except BaseException as e:
 recovery.update(phase='failed',error=repr(e),traceback=traceback.format_exc());receipt();raise
