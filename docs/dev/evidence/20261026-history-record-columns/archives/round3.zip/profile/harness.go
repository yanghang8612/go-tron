package snapshots

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"testing"
	"time"
)

type hcCostSample struct {
	Path                                    string
	Page                                    int
	Mode                                    int
	CanonicalBytes, PlainBytes, ColumnBytes int
	SHA256                                  string
	Raw, Plain, Columns                     []byte `json:"-"`
}

func TestOfflineHistoryRecordColumnsCost(t *testing.T) {
	root := os.Getenv("GTRON_RECORD_COLUMNS_ROOT")
	if root == "" {
		t.Skip("private immutable sample")
	}
	b, e := os.ReadFile(filepath.Join(root, "probe-plan.json"))
	if e != nil {
		t.Fatal(e)
	}
	var plan []hcProbePlan
	if e = json.Unmarshal(b, &plan); e != nil {
		t.Fatal(e)
	}
	z, dec, e := cbCodec()
	if e != nil {
		t.Fatal(e)
	}
	var samples []hcCostSample
	for _, index := range []int{2, 4, 8, 9, 10, 11, 12, 13} {
		p := plan[index]
		r, h, size, e := openStateDomainChangeBinaryCompactionRecordReader(context.Background(), p.Dir, p.History)
		if e != nil {
			t.Fatal(e)
		}
		sr := r.(*stateDomainChangeHistoryReader)
		c := sr.historySegmentReader.(*compressedBlockReader)
		page := len(c.table) / 2
		start := c.table[page].uncompressedStart
		n, e := compressedBlockExpectedLen(c.table, size, page)
		if e != nil {
			t.Fatal(e)
		}
		_, off, e := readStateDomainChangeBinaryTxRangeTableAt(r, size, p.History, h)
		if e != nil {
			t.Fatal(e)
		}
		var starts []uint32
		var frame [21]byte
		for i := uint64(0); i < h.count && off < start+n; i++ {
			if _, e = c.ReadAt(frame[:], int64(off)); e != nil {
				t.Fatal(e)
			}
			length := uint64(binary.BigEndian.Uint32(frame[17:21]))
			if binary.BigEndian.Uint32(frame[:4]) != uint32(17+length) || off+21+length > size {
				t.Fatal("frame")
			}
			if off >= start && off+21 <= start+n {
				starts = append(starts, uint32(off-start))
			}
			off += 21 + length
		}
		if len(starts) == 0 {
			t.Fatal("no sample headers", index)
		}
		raw := make([]byte, n)
		if _, e = c.ReadAt(raw, int64(start)); e != nil {
			t.Fatal(e)
		}
		if e = r.Close(); e != nil {
			t.Fatal(e)
		}
		sum := sha256.Sum256(raw)
		s := hcCostSample{Path: p.History.Path, Page: page, Mode: -1, CanonicalBytes: len(raw), SHA256: hex.EncodeToString(sum[:]), Raw: raw, Plain: z.EncodeAll(raw, nil)}
		s.PlainBytes = len(s.Plain)
		best := len(s.Plain)
		for mode := uint32(0); mode < 3; mode++ {
			tr, e := encodeHistoryRecordColumns(raw, starts, mode)
			if e != nil {
				t.Fatal(e)
			}
			comp := z.EncodeAll(tr, nil)
			if len(comp)+1 < best {
				best = len(comp) + 1
				s.Mode = int(mode)
				s.Columns = comp
			}
		}
		if s.Mode < 0 {
			s.Columns = s.Plain
		}
		s.ColumnBytes = len(s.Columns) + 1
		samples = append(samples, s)
	}
	for _, s := range samples {
		tr, e := dec.DecodeAll(s.Columns, make([]byte, 0, 2*historyRecordColumnPageMax+historyRecordColumnHeader))
		if e != nil {
			t.Fatal(e)
		}
		got := tr
		if s.Mode >= 0 {
			got, e = decodeHistoryRecordColumns(tr, uint64(len(s.Raw)), nil)
		}
		if e != nil || !bytes.Equal(got, s.Raw) {
			t.Fatal("full canonical oracle", e)
		}
	}
	var rows []any
	for block := 0; block < 2; block++ {
		for j := 0; j < 2; j++ {
			arm := j
			if block == 1 {
				arm = 1 - j
			}
			for repeat := 0; repeat < 5; repeat++ {
				transformed := make([][]byte, len(samples))
				outputs := make([][]byte, len(samples))
				for i, s := range samples {
					transformed[i] = make([]byte, 0, 2*historyRecordColumnPageMax+historyRecordColumnHeader)
					outputs[i] = make([]byte, 0, len(s.Raw))
				}
				const iterations = 320
				tick := time.Now()
				for k := 0; k < iterations; k++ {
					for i, s := range samples {
						if arm == 0 || s.Mode < 0 {
							got, e := dec.DecodeAll(s.Plain, outputs[i][:0])
							if e != nil || !bytes.Equal(got, s.Raw) {
								t.Fatal("plain oracle", e)
							}
							outputs[i] = got
						} else {
							tr, e := dec.DecodeAll(s.Columns, transformed[i][:0])
							if e != nil {
								t.Fatal(e)
							}
							transformed[i] = tr
							got, e := decodeHistoryRecordColumns(tr, uint64(len(s.Raw)), outputs[i][:0])
							if e != nil || !bytes.Equal(got, s.Raw) {
								t.Fatal("columns oracle", e)
							}
							outputs[i] = got
						}
					}
				}
				elapsed := time.Since(tick).Nanoseconds()
				rows = append(rows, map[string]any{"arm": []string{"ordinary-128KiB", "record-columns-128KiB"}[arm], "block": block, "repeat": repeat, "decodes": iterations * len(samples), "nanoseconds": elapsed, "ns_per_decode": float64(elapsed) / float64(iterations*len(samples))})
			}
		}
	}
	sort.Slice(samples, func(i, j int) bool { return samples[i].Path < samples[j].Path })
	output := map[string]any{"complete": true, "all_canonical_oracles_equal": true, "samples": samples, "rows": rows, "scope": "Resident compressed frames and reused output buffers; same canonical 128KiB pages; full Zstd plus reconstruction and equality check. Not HTTP, I/O or allocation measurement."}
	b, e = json.MarshalIndent(output, "", "  ")
	if e != nil {
		t.Fatal(e)
	}
	if e = os.WriteFile(filepath.Join(root, "page-cost.json"), b, 0600); e != nil {
		t.Fatal(e)
	}
	fmt.Fprintln(os.Stdout, "complete page decode ABBA", len(samples))
}
