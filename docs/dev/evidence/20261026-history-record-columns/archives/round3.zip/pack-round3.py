import pathlib,json,hashlib,zipfile,statistics,collections,datetime,subprocess,base64
P=pathlib.Path('/data/gtron/history-record-columns-20261026-01');R=P/'round3';state=json.loads((R/'round3-status.json').read_text());assert state['complete']and state['canonical_sample_identity_equal']
rows=[json.loads(x)for x in (R/'probe-rows.jsonl').read_text().splitlines()];assert len(rows)==14
cost=json.loads((R/'page-cost.json').read_text());assert cost['complete']and cost['all_canonical_oracles_equal']
groups=collections.defaultdict(list)
for r in cost['rows']:groups[r['arm']].append(r['ns_per_decode'])
summary=dict(complete=True,source_bytes=sum(r['SourceBytes']for r in rows),variants=[dict(mode=i,projected_bytes=sum(r['Variants'][i]['AfterFallbackBytes']for r in rows),selected_pages=sum(r['Variants'][i]['SelectedPages']for r in rows))for i in range(3)],cost_medians_ns={k:statistics.median(v)for k,v in groups.items()},production_identity=subprocess.check_output(['systemctl','show','gtron','-p','MainPID','-p','ActiveState']).decode(),production_mutations=False,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(R/'summary.json').write_text(json.dumps(summary,indent=2))
files={f.name:f.read_bytes()for f in R.iterdir()if f.is_file()and f.suffix in ('.json','.jsonl','.log')}
for n in ['history_record_columns.v3.go','history_record_columns_test.v3.go','round3-driver.py','pack-round3.py']:files[n]=(P/n).read_bytes()
for n in ['profile-status.json','page-cost.json','profile-top.log','cpu.pprof']:files['profile/'+n]=(P/'profile'/n).read_bytes()
files['profile/harness.go']=(P/'offline_history_record_columns_profile.go').read_bytes()
checks={n:hashlib.sha256(v).hexdigest()for n,v in files.items()};target=pathlib.Path('/tmp/gtron-history-record-columns-round3-20261026-01.zip');assert not target.exists()
with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED)as z:
 for n,v in files.items():z.writestr(n,v)
 z.writestr('evidence-sha256.json',json.dumps(checks,indent=2))
receipt=dict(bytes=target.stat().st_size,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),members=len(files)+1,utc=summary['utc'])
pathlib.Path('/tmp/gtron-history-record-columns-round3-20261026-01-receipt.json').write_text(json.dumps(receipt,indent=2))
print('BEGIN_HC_ROUND3_META');print(json.dumps(receipt));print('END_HC_ROUND3_META');print('BEGIN_HC_ROUND3_B64');print(base64.encodebytes(target.read_bytes()).decode());print('END_HC_ROUND3_B64')
