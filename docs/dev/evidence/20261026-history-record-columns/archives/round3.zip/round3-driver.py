import pathlib,json,hashlib,subprocess,os,datetime,traceback,shutil,statistics,collections
P=pathlib.Path('/data/gtron/history-record-columns-20261026-01');R=P/'round3';S=R/'source';state={'complete':False,'production_mutations':False}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save():state['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(R/'round3-status.json').write_text(json.dumps(state,indent=2))
try:
 assert json.loads((P/'round2/round2-status.json').read_text())['complete'];R.mkdir();save();shutil.copytree(P/'round2/source',S,copy_function=os.link,symlinks=True)
 state['inputs']={}
 for source,dest in [('history_record_columns.v3.go','history_record_columns.go'),('history_record_columns_test.v3.go','history_record_columns_test.go')]:
  target=S/'core/state/snapshots'/dest;tmp=target.with_suffix('.round3.tmp');tmp.write_bytes((P/source).read_bytes());os.replace(tmp,target);state['inputs'][dest]=sha(target)
 save();shutil.copyfile(P/'probe-plan.json',R/'probe-plan.json')
 env=dict(os.environ,PATH='/data/go/bin:'+os.environ.get('PATH',''),GOCACHE='/root/.cache/go-build',GOPATH='/root/go',GOTOOLCHAIN='local',CGO_ENABLED='1',GOMAXPROCS='2',GOMEMLIMIT='1536MiB',GTRON_RECORD_COLUMNS_ROOT=str(R))
 for label,args in [('round3-unit',['/data/go/bin/go','test','./core/state/snapshots','-run','^TestHistoryRecordColumns','-count=1','-timeout=120s']),('round3-build',['/data/go/bin/go','test','-c','./core/state/snapshots','-o',str(R/'probe.test')]),('round3-probe',[str(R/'probe.test'),'-test.run=^TestOfflineHistoryRecordColumnsProbe$','-test.v','-test.timeout=25m']),('round3-cost',[str(R/'probe.test'),'-test.run=^TestOfflineHistoryRecordColumnsCost$','-test.v','-test.timeout=10m'])]:
  state['phase']=label;save()
  with (R/(label+'.log')).open('wb')as out:subprocess.run(args,cwd=S,env=env,stdout=out,stderr=subprocess.STDOUT,check=True,timeout=1550)
 a=[json.loads(s)for s in(P/'probe-rows.jsonl').read_text().splitlines()];b=[json.loads(s)for s in(R/'probe-rows.jsonl').read_text().splitlines()];assert len(a)==len(b)==14
 for x,y in zip(a,b):
  for k in ['Path','SourceBytes','LogicalBytes','Records','FullHeaders','CrossingHeaders','Pages','SamePagePlainBytes','CanonicalSHA256']:assert x[k]==y[k],k
 c=json.loads((R/'page-cost.json').read_text());old=json.loads((P/'page-cost.json').read_text());assert c['complete']and c['all_canonical_oracles_equal']
 for x,y in zip(c['samples'],old['samples']):
  for k in ['Path','Page','CanonicalBytes','PlainBytes','SHA256']:assert x[k]==y[k],k
 state.update(complete=True,phase='complete',binary_sha256=sha(R/'probe.test'),canonical_sample_identity_equal=True,production_identity=subprocess.check_output(['systemctl','show','gtron','-p','MainPID','-p','ActiveState']).decode());save()
except BaseException as e:
 R.mkdir(exist_ok=True);state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
