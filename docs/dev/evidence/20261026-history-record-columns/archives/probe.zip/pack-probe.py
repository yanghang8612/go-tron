import pathlib,json,hashlib,zipfile,subprocess,datetime,statistics,collections
P=pathlib.Path('/data/gtron/history-record-columns-20261026-01')
assert json.loads((P/'driver-status.json').read_text())['complete']and json.loads((P/'cost-driver-status.json').read_text())['complete']
rows=[json.loads(x)for x in (P/'probe-rows.jsonl').read_text().splitlines()];assert len(rows)==14
cost=json.loads((P/'page-cost.json').read_text());assert cost['complete']and cost['all_canonical_oracles_equal']
for n,d in json.loads((P/'driver-status.json').read_text())['inputs'].items():assert hashlib.sha256((P/n).read_bytes()).hexdigest()==d
arms=collections.defaultdict(list)
for r in cost['rows']:arms[r['arm']].append(r['ns_per_decode'])
summary=dict(complete=True,scope='Fourteen immutable source files; exact encoded page lengths with complete projected footer/table/mode overhead; no new production container emitted.',source_bytes=sum(r['SourceBytes']for r in rows),same_page_plain_bytes=sum(r['SamePagePlainBytes']for r in rows),variants=[dict(mode=i,encoded_bytes=sum(r['Variants'][i]['EncodedBytes']for r in rows),after_whole_file_fallback_bytes=sum(r['Variants'][i]['AfterFallbackBytes']for r in rows),selected_pages=sum(r['Variants'][i]['SelectedPages']for r in rows))for i in range(3)],cost_medians_ns={k:statistics.median(v)for k,v in arms.items()},production_identity=subprocess.check_output(['systemctl','show','gtron','-p','MainPID','-p','ActiveState']).decode(),production_mutations=False,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(P/'summary.json').write_text(json.dumps(summary,indent=2))
files={f.name:f.read_bytes()for f in P.iterdir()if f.is_file()and f.suffix in ('.go','.json','.jsonl','.py','.log')}
checks={n:hashlib.sha256(b).hexdigest()for n,b in files.items()};target=pathlib.Path('/tmp/gtron-history-record-columns-probe-20261026-01.zip');assert not target.exists()
with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED)as z:
 for n,b in sorted(files.items()):z.writestr(n,b)
 z.writestr('evidence-sha256.json',json.dumps(checks,indent=2))
receipt=dict(bytes=target.stat().st_size,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),members=len(files)+1,utc=summary['utc'])
pathlib.Path('/tmp/gtron-history-record-columns-probe-20261026-01-receipt.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(summary,indent=2));print(json.dumps(receipt,indent=2))
