import pathlib,hashlib,json,subprocess,datetime,os,shutil,traceback
P=pathlib.Path('/data/gtron/history-record-columns-20261026-01');OLD=pathlib.Path('/data/gtron/history-account-delta-20261025-01');S=P/'source';state={'complete':False,'production_mutations':False}
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def save():
 state['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();f=P/'driver-status.json';f.with_suffix('.tmp').write_text(json.dumps(state,indent=2));f.with_suffix('.tmp').replace(f)
try:
 assert shutil.disk_usage('/data').free>100*(1<<30)
 before=subprocess.check_output(['systemctl','show','gtron','-p','MainPID','-p','ActiveState']).decode()
 (P/'preflight.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),production_identity=before,free_bytes=shutil.disk_usage('/data').free,meminfo=pathlib.Path('/proc/meminfo').read_text(),production_mutations=False),indent=2))
 inventory=json.loads((OLD/'final-source-inventory.json').read_text())
 for n,d in inventory.items():assert sha(OLD/'candidate-source'/n)==d,n
 def ignore(path,names):return ['.git','build']if path==str(OLD/'candidate-source')else[]
 shutil.copytree(OLD/'candidate-source',S,symlinks=True,copy_function=os.link,ignore=ignore)
 new=['history_record_columns.go','history_record_columns_test.go','offline_history_record_columns_probe_test.go']
 for n in new:
  target=S/'core/state/snapshots'/n;assert not target.exists();shutil.copyfile(P/n,target)
 state['inputs']={n:sha(P/n)for n in new};state['baseline_inventory_sha256']=sha(OLD/'final-source-inventory.json');save()
 shutil.copyfile(OLD/'probe-plan.json',P/'probe-plan.json')
 env=dict(os.environ,PATH='/data/go/bin:'+os.environ.get('PATH',''),GOCACHE='/root/.cache/go-build',GOPATH='/root/go',GOTOOLCHAIN='local',CGO_ENABLED='1',GOMAXPROCS='2',GOMEMLIMIT='1536MiB',GTRON_RECORD_COLUMNS_ROOT=str(P))
 for label,args in [('unit',['/data/go/bin/go','test','./core/state/snapshots','-run','^TestHistoryRecordColumns','-count=1','-timeout=120s']),('build',['/data/go/bin/go','test','-c','./core/state/snapshots','-o',str(P/'probe.test')]),('probe',[str(P/'probe.test'),'-test.run=^TestOfflineHistoryRecordColumnsProbe$','-test.v','-test.timeout=25m'])]:
  state['phase']=label;save()
  with (P/(label+'.log')).open('wb')as f:subprocess.run(args,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1550,check=True)
 state['binary_sha256']=sha(P/'probe.test')
 assert json.loads((P/'probe-status.json').read_text())['complete']
 for n,d in inventory.items():assert sha(OLD/'candidate-source'/n)==d and sha(S/n)==d,n
 for n,d in state['inputs'].items():assert sha(S/'core/state/snapshots'/n)==d,n
 state.update(complete=True,phase='complete',production_identity_before=before,production_identity_after=subprocess.check_output(['systemctl','show','gtron','-p','MainPID','-p','ActiveState']).decode());save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
