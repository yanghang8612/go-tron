import pathlib,json,hashlib,subprocess,os,datetime,traceback,shutil
P=pathlib.Path('/data/gtron/history-record-columns-20261026-01');S=P/'source';state={'complete':False,'production_mutations':False}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save():state['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(P/'cost-driver-status.json').write_text(json.dumps(state,indent=2))
try:
 assert json.loads((P/'driver-status.json').read_text())['complete']
 f='offline_history_record_columns_cost_test.go';target=S/'core/state/snapshots'/f;assert not target.exists();shutil.copyfile(P/f,target);state['harness_sha256']=sha(target);save()
 env=dict(os.environ,PATH='/data/go/bin:'+os.environ.get('PATH',''),GOCACHE='/root/.cache/go-build',GOPATH='/root/go',GOTOOLCHAIN='local',CGO_ENABLED='1',GOMAXPROCS='2',GOMEMLIMIT='1536MiB',GTRON_RECORD_COLUMNS_ROOT=str(P))
 for label,args in [('cost-build',['/data/go/bin/go','test','-c','./core/state/snapshots','-o',str(P/'cost.test')]),('cost',[str(P/'cost.test'),'-test.run=^TestOfflineHistoryRecordColumnsCost$','-test.v','-test.timeout=10m'])]:
  state['phase']=label;save()
  with (P/(label+'.log')).open('wb')as out:subprocess.run(args,cwd=S,env=env,stdout=out,stderr=subprocess.STDOUT,check=True,timeout=650)
 assert json.loads((P/'page-cost.json').read_text())['complete'];state.update(complete=True,phase='complete',binary_sha256=sha(P/'cost.test'));save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
