import pathlib,json,hashlib,subprocess,os,datetime,traceback,shutil
P=pathlib.Path('/data/gtron/history-record-columns-20261026-01');R=P/'adaptive';S=R/'source';state={'complete':False,'production_mutations':False}
def save():state['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(R/'adaptive-status.json').write_text(json.dumps(state,indent=2))
try:
 assert json.loads((P/'round3/round3-status.json').read_text())['complete'];R.mkdir();save();shutil.copytree(P/'round3/source',S,copy_function=os.link,symlinks=True)
 target=S/'core/state/snapshots/offline_history_record_columns_probe_test.go';tmp=target.with_suffix('.adaptive.tmp');tmp.write_bytes((P/'offline_history_record_columns_adaptive.go').read_bytes());os.replace(tmp,target);state['harness_sha256']=hashlib.sha256(target.read_bytes()).hexdigest();save();shutil.copyfile(P/'probe-plan.json',R/'probe-plan.json')
 env=dict(os.environ,PATH='/data/go/bin:'+os.environ.get('PATH',''),GOCACHE='/root/.cache/go-build',GOPATH='/root/go',GOTOOLCHAIN='local',CGO_ENABLED='1',GOMAXPROCS='2',GOMEMLIMIT='1536MiB',GTRON_RECORD_COLUMNS_ROOT=str(R))
 for label,args in [('adaptive-build',['/data/go/bin/go','test','-c','./core/state/snapshots','-o',str(R/'probe.test')]),('adaptive-probe',[str(R/'probe.test'),'-test.run=^TestOfflineHistoryRecordColumnsProbe$','-test.v','-test.timeout=25m'])]:
  state['phase']=label;save()
  with (R/(label+'.log')).open('wb')as out:subprocess.run(args,cwd=S,env=env,stdout=out,stderr=subprocess.STDOUT,check=True,timeout=1550)
 a=[json.loads(x)for x in(P/'round3/probe-rows.jsonl').read_text().splitlines()];b=[json.loads(x)for x in(R/'probe-rows.jsonl').read_text().splitlines()];assert len(a)==len(b)==14
 for x,y in zip(a,b):
  for k in ['Path','SourceBytes','LogicalBytes','Records','FullHeaders','CrossingHeaders','Pages','SamePagePlainBytes','CanonicalSHA256']:assert x[k]==y[k],k
  for u,v in zip(x['Variants'],y['Variants']):assert u['EncodedBytes']==v['EncodedBytes']and u['AfterFallbackBytes']==v['AfterFallbackBytes']
  assert y['AdaptiveAfterFallbackBytes']<=min(v['AfterFallbackBytes']for v in y['Variants'])
 state.update(complete=True,phase='complete',canonical_and_uniform_controls_equal=True,binary_sha256=hashlib.sha256((R/'probe.test').read_bytes()).hexdigest());save()
except BaseException as e:
 R.mkdir(exist_ok=True);state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
