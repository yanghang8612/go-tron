import pathlib,json,hashlib,zipfile,datetime,base64
P=pathlib.Path('/data/gtron/history-record-columns-20261026-01');R=P/'adaptive';s=json.loads((R/'adaptive-status.json').read_text());assert s['complete']and s['canonical_and_uniform_controls_equal']
files={f.name:f.read_bytes()for f in R.iterdir()if f.is_file()and f.suffix in ('.json','.jsonl','.log')}
for n in ['offline_history_record_columns_adaptive.go','adaptive-driver.py','pack-adaptive.py']:files[n]=(P/n).read_bytes()
m={n:hashlib.sha256(b).hexdigest()for n,b in files.items()};target=pathlib.Path('/tmp/gtron-history-record-columns-adaptive-20261026-01.zip');assert not target.exists()
with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED)as z:
 for n,b in files.items():z.writestr(n,b)
 z.writestr('evidence-sha256.json',json.dumps(m,indent=2))
r=dict(bytes=target.stat().st_size,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),members=len(files)+1,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
print('BEGIN_HC_ADAPTIVE_META');print(json.dumps(r));print('END_HC_ADAPTIVE_META');print('BEGIN_HC_ADAPTIVE_B64');print(base64.encodebytes(target.read_bytes()).decode());print('END_HC_ADAPTIVE_B64')
