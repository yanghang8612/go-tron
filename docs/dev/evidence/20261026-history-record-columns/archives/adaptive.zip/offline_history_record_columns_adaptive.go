package snapshots

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"testing"
	"time"
)

type hcProbePlan struct {
	Dir               string
	History, Accessor SegmentRef
}
type hcProbeVariant struct {
	Mode                                                                                                                                         uint32
	EncodedBytes, AfterFallbackBytes, SelectedPages, HeaderBytes, SelectedCanonicalBytes, TransformedBytes, EncodeNanoseconds, DecodeNanoseconds uint64
}
type hcProbeRow struct {
	AdaptiveEncodedBytes, AdaptiveAfterFallbackBytes                                            uint64
	Path                                                                                        string
	SourceBytes, LogicalBytes, Records, FullHeaders, CrossingHeaders, Pages, SamePagePlainBytes uint64
	Variants                                                                                    []hcProbeVariant
	CanonicalSHA256                                                                             string
	Seconds                                                                                     float64
}

func hcProbeSHA(path string) (string, error) {
	f, e := os.Open(path)
	if e != nil {
		return "", e
	}
	defer f.Close()
	h := sha256.New()
	_, e = io.Copy(h, f)
	return "sha256:" + hex.EncodeToString(h.Sum(nil)), e
}
func TestOfflineHistoryRecordColumnsProbe(t *testing.T) {
	root := os.Getenv("GTRON_RECORD_COLUMNS_ROOT")
	if root == "" {
		t.Skip("isolated immutable inputs")
	}
	b, e := os.ReadFile(filepath.Join(root, "probe-plan.json"))
	if e != nil {
		t.Fatal(e)
	}
	var plan []hcProbePlan
	if e = json.Unmarshal(b, &plan); e != nil {
		t.Fatal(e)
	}
	output, e := os.OpenFile(filepath.Join(root, "probe-rows.jsonl"), os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if e != nil {
		t.Fatal(e)
	}
	defer output.Close()
	out := json.NewEncoder(output)
	for _, p := range plan {
		r, e := hcProbeFile(p)
		if e != nil {
			t.Fatalf("%s: %v", p.History.Path, e)
		}
		if e = out.Encode(r); e != nil {
			t.Fatal(e)
		}
		if e = output.Sync(); e != nil {
			t.Fatal(e)
		}
		t.Logf("%s source=%d plain=%d variants=%+v", r.Path, r.SourceBytes, r.SamePagePlainBytes, r.Variants)
	}
	b, e = json.Marshal(map[string]any{"complete": true, "files": len(plan), "production_mutations": false})
	if e != nil {
		t.Fatal(e)
	}
	if e = os.WriteFile(filepath.Join(root, "probe-status.json"), b, 0600); e != nil {
		t.Fatal(e)
	}
}
func hcProbeFile(p hcProbePlan) (result hcProbeRow, err error) {
	started := time.Now()
	result.Path = p.History.Path
	result.SourceBytes = p.History.Size
	physical, e := hcProbeSHA(filepath.Join(p.Dir, p.History.Path))
	if e != nil || physical != p.History.Checksum {
		return result, fmt.Errorf("source SHA: %v", e)
	}
	r, h, size, e := openStateDomainChangeBinaryCompactionRecordReader(context.Background(), p.Dir, p.History)
	if e != nil {
		return result, e
	}
	defer r.Close()
	sr, ok := r.(*stateDomainChangeHistoryReader)
	if !ok {
		return result, fmt.Errorf("reader type")
	}
	c, ok := sr.historySegmentReader.(*compressedBlockReader)
	if !ok || c.cdc != nil || c.accountDelta || h.version != stateDomainChangeBinaryVersionV6 {
		return result, fmt.Errorf("V6/footer baseline required")
	}
	result.LogicalBytes = size
	result.Pages = uint64(len(c.table))
	result.Records = h.count
	starts := make([][]uint32, len(c.table))
	_, off, e := readStateDomainChangeBinaryTxRangeTableAt(r, size, p.History, h)
	if e != nil {
		return result, e
	}
	var scratch []byte
	for i := uint64(0); i < h.count; i++ {
		payload, next, borrowed, e := c.ReadRecordFrameAt(off, scratch)
		if e != nil {
			return result, e
		}
		if !borrowed {
			scratch = payload
		}
		if len(payload) < 17 || uint64(binary.BigEndian.Uint32(payload[13:17])) != uint64(len(payload)-17) || payload[12] > 1 {
			return result, fmt.Errorf("V6 header")
		}
		page := sort.Search(len(c.table), func(j int) bool { return c.table[j].uncompressedStart > off }) - 1
		if page < 0 {
			return result, fmt.Errorf("header before page")
		}
		n, e := compressedBlockExpectedLen(c.table, c.uncSize, page)
		if e != nil {
			return result, e
		}
		if off+21 <= c.table[page].uncompressedStart+n {
			starts[page] = append(starts[page], uint32(off-c.table[page].uncompressedStart))
			result.FullHeaders++
		} else {
			result.CrossingHeaders++
		}
		off = next
	}
	if off != size {
		return result, fmt.Errorf("canonical EOF")
	}
	z, _, e := cbCodec()
	if e != nil {
		return result, e
	}
	base := uint64(compressedBlockHeaderSize+compressedBlockTrailerSize) + uint64(len(c.table))*compressedBlockTableEntry
	result.SamePagePlainBytes = base
	result.AdaptiveEncodedBytes = base
	for mode := uint32(0); mode < 3; mode++ {
		result.Variants = append(result.Variants, hcProbeVariant{Mode: mode, EncodedBytes: base})
	}
	digest := sha256.New()
	for i, pb := range c.table {
		n, e := compressedBlockExpectedLen(c.table, c.uncSize, i)
		if e != nil {
			return result, e
		}
		raw := make([]byte, n)
		if _, e = c.ReadAt(raw, int64(pb.uncompressedStart)); e != nil {
			return result, e
		}
		digest.Write(raw)
		plain := z.EncodeAll(raw, nil)
		result.SamePagePlainBytes += uint64(len(plain))
		adaptiveBest := len(plain)
		for mode := range result.Variants {
			v := &result.Variants[mode]
			best := len(plain)
			if len(starts[i]) != 0 {
				tick := time.Now()
				transformed, e := encodeHistoryRecordColumns(raw, starts[i], uint32(mode))
				if e != nil {
					return result, e
				}
				compressed := z.EncodeAll(transformed, nil)
				adaptiveBest = min(adaptiveBest, len(compressed))
				v.EncodeNanoseconds += uint64(time.Since(tick))
				tick = time.Now()
				got, e := decodeHistoryRecordColumns(transformed, n, nil)
				v.DecodeNanoseconds += uint64(time.Since(tick))
				if e != nil || !bytes.Equal(got, raw) {
					return result, fmt.Errorf("page %d mode %d complete canonical oracle: %v", i, mode, e)
				}
				if len(compressed) < best {
					best = len(compressed)
					v.SelectedPages++
					v.HeaderBytes += uint64(len(starts[i]) * 21)
					v.SelectedCanonicalBytes += n
					v.TransformedBytes += uint64(len(transformed))
				}
			}
			// One discriminator for every independent page, all directory/footer bytes charged.
			v.EncodedBytes += uint64(best) + 1
		}
		result.AdaptiveEncodedBytes += uint64(adaptiveBest) + 1
	}
	for i := range result.Variants {
		v := &result.Variants[i]
		v.AfterFallbackBytes = min(v.EncodedBytes, p.History.Size)
	}
	result.AdaptiveAfterFallbackBytes = min(result.AdaptiveEncodedBytes, p.History.Size)
	result.CanonicalSHA256 = hex.EncodeToString(digest.Sum(nil))
	result.Seconds = time.Since(started).Seconds()
	after, e := hcProbeSHA(filepath.Join(p.Dir, p.History.Path))
	if e != nil || after != physical {
		return result, fmt.Errorf("source changed")
	}
	return result, nil
}
