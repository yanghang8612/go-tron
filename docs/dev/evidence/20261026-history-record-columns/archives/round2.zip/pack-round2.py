import pathlib,json,hashlib,zipfile,statistics,collections,datetime,subprocess
P=pathlib.Path('/data/gtron/history-record-columns-20261026-01');R=P/'round2';s=json.loads((R/'round2-status.json').read_text());assert s['complete']
a=json.loads((P/'page-cost.json').read_text());b=json.loads((R/'page-cost.json').read_text());assert a['samples']==b['samples']and b['complete']and b['all_canonical_oracles_equal']
medians={}
for label,d in [('v1',a),('v2',b)]:
 groups=collections.defaultdict(list)
 for r in d['rows']:groups[r['arm']].append(r['ns_per_decode'])
 assert len(groups)==2 and all(len(v)==10 for v in groups.values())
 medians[label]={k:statistics.median(v)for k,v in groups.items()}
summary=dict(complete=True,identical_canonical_and_encoded_samples=True,medians_ns=medians,production_identity=subprocess.check_output(['systemctl','show','gtron','-p','MainPID','-p','ActiveState']).decode(),production_mutations=False,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(R/'comparison.json').write_text(json.dumps(summary,indent=2))
files={f.name:f.read_bytes()for f in R.iterdir()if f.is_file()and f.suffix in ('.json','.log')}
for n in ['history_record_columns.v2.go','cost-round2.py','pack-round2.py']:files[n]=(P/n).read_bytes()
checks={n:hashlib.sha256(v).hexdigest()for n,v in files.items()};target=pathlib.Path('/tmp/gtron-history-record-columns-round2-20261026-01.zip');assert not target.exists()
with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED)as z:
 for n,v in files.items():z.writestr(n,v)
 z.writestr('evidence-sha256.json',json.dumps(checks,indent=2))
receipt=dict(bytes=target.stat().st_size,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),members=len(files)+1,utc=summary['utc'])
pathlib.Path('/tmp/gtron-history-record-columns-round2-20261026-01-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(summary,indent=2));print(json.dumps(receipt,indent=2))
