import pathlib,json,hashlib,subprocess,os,datetime,traceback,shutil
P=pathlib.Path('/data/gtron/history-record-columns-20261026-01');R=P/'round2';S=R/'source';state={'complete':False,'production_mutations':False}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save():state['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(R/'round2-status.json').write_text(json.dumps(state,indent=2))
try:
 assert json.loads((P/'cost-driver-status.json').read_text())['complete'];R.mkdir();save()
 shutil.copytree(P/'source',S,copy_function=os.link,symlinks=True)
 target=S/'core/state/snapshots/history_record_columns.go';state['previous_source_sha256']=sha(target)
 tmp=target.with_suffix('.round2.tmp');tmp.write_bytes((P/'history_record_columns.v2.go').read_bytes());os.replace(tmp,target)
 state['candidate_source_sha256']=sha(target);state['harness_sha256']=sha(S/'core/state/snapshots/offline_history_record_columns_cost_test.go');save()
 shutil.copyfile(P/'probe-plan.json',R/'probe-plan.json')
 env=dict(os.environ,PATH='/data/go/bin:'+os.environ.get('PATH',''),GOCACHE='/root/.cache/go-build',GOPATH='/root/go',GOTOOLCHAIN='local',CGO_ENABLED='1',GOMAXPROCS='2',GOMEMLIMIT='1536MiB',GTRON_RECORD_COLUMNS_ROOT=str(R))
 for label,args in [('round2-unit',['/data/go/bin/go','test','./core/state/snapshots','-run','^TestHistoryRecordColumns','-count=1','-timeout=120s']),('round2-build',['/data/go/bin/go','test','-c','./core/state/snapshots','-o',str(R/'cost.test')]),('round2-cost',[str(R/'cost.test'),'-test.run=^TestOfflineHistoryRecordColumnsCost$','-test.v','-test.timeout=10m'])]:
  state['phase']=label;save()
  with (R/(label+'.log')).open('wb')as out:subprocess.run(args,cwd=S,env=env,stdout=out,stderr=subprocess.STDOUT,check=True,timeout=650)
 assert json.loads((R/'page-cost.json').read_text())['complete'];assert sha(P/'source/core/state/snapshots/history_record_columns.go')==state['previous_source_sha256']
 state.update(complete=True,phase='complete',binary_sha256=sha(R/'cost.test'));save()
except BaseException as e:
 R.mkdir(exist_ok=True);state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
