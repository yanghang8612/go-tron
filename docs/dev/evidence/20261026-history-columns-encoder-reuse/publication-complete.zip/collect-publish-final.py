import pathlib,hashlib,json,subprocess,datetime,zipfile,os
P=pathlib.Path('/data/gtron/history-columns-encoder-reuse-20261026-01')
OLD=pathlib.Path('/data/gtron/history-record-columns-container-20261026-01')
POLICY=pathlib.Path('/data/gtron/history-auto-columns-policy-20261026-01')
def sha(path):
 h=hashlib.sha256()
 with path.open('rb')as f:
  for b in iter(lambda:f.read(4<<20),b''):h.update(b)
 return h.hexdigest()
status=json.loads((P/'publish-status.json').read_text())
assert status['complete'] and status['total_samples']==45 and status['timed_samples']==36
proof={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'production_mutations':False,'sources':{}}
for arm,root in [('old',OLD),('policy',POLICY),('new',P)]:
 source=root/'candidate-source';inv=json.loads((root/'source-inventory.json').read_text());expected=dict(inv)
 extra_path=root/('inherited-harness-inventory.json' if arm=='old' else 'inherited-extra-go-inventory.json')
 extra=json.loads(extra_path.read_text());expected.update(extra)
 if arm=='old':
  for n in ['offline_record_column_capture_test.go','offline_record_column_parallel_test.go','offline_record_column_controls_test.go','offline_record_column_publish_test.go']:
   expected['core/state/snapshots/'+n]=sha(root/n)
 bad=[n for n,h in expected.items()if not(source/n).is_file()or sha(source/n)!=h]
 unknown=sorted(str(q.relative_to(source))for q in source.rglob('*.go')if str(q.relative_to(source))not in expected)
 lib=source/'third_party/librustzcash/target/release/librustzcash.a'
 proof['sources'][arm]={'product_source_files':len(inv),'checked_files':len(expected),'inventory_sha256':sha(root/'source-inventory.json'),'mismatches':bad,'unaccounted_go_files':unknown,'sapling_library_sha256':sha(lib)}
 assert not bad and not unknown, (arm,bad,unknown)
 assert proof['sources'][arm]['sapling_library_sha256']=='b6c99f8fabac36d5a836c644bb79059449c89740bf33670d66088d094447e7ea'
native=json.loads((P/'native-status.json').read_text());assert native['complete']and not native.get('error')
proof['binaries']={n:sha(P/n)for n in native['binaries']};assert proof['binaries']==native['binaries']
fields=['MainPID','ActiveState','SubState','ExecMainStatus','LoadState']
for key,unit in [('production_identity','gtron.service'),('private_unit','gtron-columns-encoder-reuse-native-20261026-01.service')]:
 args=['systemctl','show',unit]
 for field in fields:args+=['-p',field]
 text=subprocess.check_output(args,universal_newlines=True);proof[key]=dict(l.split('=',1)for l in text.splitlines()if '='in l)
assert proof['production_identity']['MainPID']==status['after_identity']['MainPID']=='0'
(P/'publish-final-source-proof.json').write_text(json.dumps(proof,sort_keys=True,indent=2)+'\n')
summary=json.loads((P/'publish-summary.json').read_text());compact={'status':status,'source_proof':proof,'rows':[{k:v for k,v in row.items()if k not in ('canonical_and_companion_sha','physical_output_sha')}for row in summary],'summary_sha256':sha(P/'publish-summary.json')}
blob=(json.dumps(compact,sort_keys=True,separators=(',',':'))+'\n').encode();assert len(blob)<=6144
(P/'publish-final-compact.json').write_bytes(blob)
items={n:(P/n).read_bytes()for n in ['publish-status.json','publish-summary.json','publish-samples.jsonl','publish-old.log','publish-new.log','publish-driver.log','publish-final-source-proof.json','publish-final-compact.json','native-status.json','native-summary.json','native-start-receipt.json','source-verification.json','native-page-benchmark.log','run-publish.py','offline_column_reuse_publish_test.go']}
items['evidence-manifest.json']=(json.dumps({n:hashlib.sha256(b).hexdigest()for n,b in items.items()},sort_keys=True,indent=2)+'\n').encode()
q=pathlib.Path('/tmp/gtron-columns-encoder-reuse-publish-20261026-01.zip');assert not q.exists()
with zipfile.ZipFile(str(q),'w',zipfile.ZIP_DEFLATED)as z:
 for name,b in sorted(items.items()):z.writestr(name,b)
with q.open('rb')as f:os.fsync(f.fileno())
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'path':str(q),'bytes':q.stat().st_size,'sha256':sha(q),'members':len(items),'production_mutations':False}
(P/'publish-final-archive-receipt.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
