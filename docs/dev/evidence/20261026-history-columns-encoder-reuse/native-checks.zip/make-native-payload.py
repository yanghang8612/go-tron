import ast
import hashlib
import io
import json
import pathlib
import subprocess
import zipfile

R = pathlib.Path('/Users/asuka/.codex/worktrees/history-auto-columns-policy/go-tron')
P = R/'build/benchmarks/20261026-history-columns-encoder-reuse'
base_raw = (R/'build/benchmarks/20261026-history-auto-columns-policy/source-inventory.json').read_bytes()
base = json.loads(base_raw)
raw = (P/'source-inventory.json').read_bytes()
current = json.loads(raw)
changed = sorted(n for n, h in current.items() if base.get(n) != h)
assert len(base) == 2146 and len(current) == 2148 and len(changed) == 4
sha = lambda b: hashlib.sha256(b).hexdigest()
assert all(sha((R/n).read_bytes()) == h for n,h in current.items())
runner = (P/'prepare-native.py').read_bytes()
ast.parse(runner, feature_version=(3,6))
commit = subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
assert json.loads((P/'local-status.json').read_text())['complete'], 'finish local checks before staging'
identity = dict(source_commit=commit, source_inventory_sha256=sha(raw), base_inventory_sha256=sha(base_raw),
                changed_source_files=changed, target_source_files=len(current), native_gate='all prior heavy jobs complete; private checks before new publication',
                default_policy='auto', opt_in_policy='auto-columns', byte_identical_encoder=True, source_tree_dirty=bool(subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip()), production_mutations=False)
items = {'source/'+n:(R/n).read_bytes() for n in changed}
items.update({'base-inventory.json':base_raw, 'source-inventory.json':raw, 'prepare-native.py':runner, 'run-publish.py':(P/'run-publish.py').read_bytes(), 'offline_column_reuse_publish_test.go':(P/'offline_column_reuse_publish_test.go').read_bytes(), 'local-status.json':(P/'local-status.json').read_bytes(),
              'encoder-identity.json':(json.dumps(identity,sort_keys=True,indent=2)+'\n').encode()})
items['payload-manifest.json']=(json.dumps({n:sha(b) for n,b in items.items()},sort_keys=True,indent=2)+'\n').encode()
out=io.BytesIO()
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,b in sorted(items.items()):
        i=zipfile.ZipInfo(n,date_time=(2026,10,26,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16;z.writestr(i,b)
data=out.getvalue();path=P/'native-source-payload.zip';assert not path.exists();path.write_bytes(data)
chunks=[]
for index,start in enumerate(range(0,len(data),20000)):
    value=data[start:start+20000];name='native-payload-part-{:03d}'.format(index);(P/name).write_bytes(value)
    chunks.append(dict(index=index,bytes=len(value),sha256=sha(value)))
receipt=dict(bytes=len(data),sha256=sha(data),members=len(items),source_files=len(current),changed_source_files=len(changed),
             source_commit=commit,chunk_bytes=20000,chunks=chunks)
(P/'native-upload-plan.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
