package snapshots

import (
	"bufio"
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/binary"
	"errors"
	"fmt"
	"hash"
	"io"
	"os"
	"path/filepath"
	"sort"
	"sync"

	"github.com/klauspost/compress/zstd"
	"github.com/tronprotocol/go-tron/core/maintenance"
)

// Compressed block segment format ("gtcblk01"). A record stream is grouped into
// fixed-count blocks; each block is zstd-compressed independently. A block table
// maps an UNCOMPRESSED record offset to its (compressed block, position), so an
// external key/tx accessor can keep storing plain uncompressed offsets while the
// payload on disk is compressed. This is the seekable-compression primitive for
// cold history segments (see project_archive_compression_arc): block compression
// captures the heavy cross-record redundancy (repeated BlockHash/owner/etc.) that
// per-record compression cannot, measured ~2.7x on realistic history.
//
// Layout:
//
//	header (48 bytes): magic[8] version blockSize recordCount blockCount
//	                   uncompressedSize dataOffset
//	block table:       blockCount x { uncompressedStart, compressedStart,
//	                                  compressedLen, records }
//	data:              compressed blocks back to back (at dataOffset)
const (
	compressedBlockMagic               = "gtcblk01"
	compressedBlockVersion             = uint32(1)
	compressedBlockHeaderSize          = 8 + 4 + 4 + 8 + 8 + 8 + 8 // = 48
	compressedBlockTableEntry          = 8 + 8 + 8 + 4             // = 28
	CompressedBlockDefaultSize         = 128                       // matches the .bt block size
	compressedBlockMaxDecodedBlockSize = 256 << 20
	minParallelHistoryCompressionBytes = 1 << 20
	maxHistoryCompressionWorkers       = 4
)

type stateDomainChangeHistoryCompressionChunk [historyCompressChunkSize]byte

const stateDomainChangeHistoryEncodedChunkCapacity = historyCompressChunkSize + 64

type stateDomainChangeHistoryEncodedChunk [stateDomainChangeHistoryEncodedChunkCapacity]byte

var stateDomainChangeHistoryCompressionChunkPool = sync.Pool{
	New: func() any { return new(stateDomainChangeHistoryCompressionChunk) },
}

var stateDomainChangeHistoryEncodedChunkPool = sync.Pool{
	New: func() any { return new(stateDomainChangeHistoryEncodedChunk) },
}

func acquireStateDomainChangeHistoryCompressionChunk(chunkSize int) []byte {
	if chunkSize != historyCompressChunkSize {
		return make([]byte, 0, chunkSize)
	}
	return stateDomainChangeHistoryCompressionChunkPool.Get().(*stateDomainChangeHistoryCompressionChunk)[:0]
}

func releaseStateDomainChangeHistoryCompressionChunk(chunk *[]byte, chunkSize int) {
	if chunk == nil || *chunk == nil {
		return
	}
	buffer := *chunk
	*chunk = nil
	if chunkSize == historyCompressChunkSize && cap(buffer) == historyCompressChunkSize {
		stateDomainChangeHistoryCompressionChunkPool.Put((*stateDomainChangeHistoryCompressionChunk)(buffer[:historyCompressChunkSize]))
	}
}

func acquireStateDomainChangeHistoryEncodedChunk(encoder *zstd.Encoder, chunkSize int) []byte {
	if encoder == nil || chunkSize != historyCompressChunkSize || encoder.MaxEncodedSize(chunkSize) > stateDomainChangeHistoryEncodedChunkCapacity {
		return nil
	}
	return stateDomainChangeHistoryEncodedChunkPool.Get().(*stateDomainChangeHistoryEncodedChunk)[:0]
}

func releaseStateDomainChangeHistoryEncodedChunk(encoded *[]byte, chunkSize int) {
	if encoded == nil || *encoded == nil {
		return
	}
	buffer := *encoded
	*encoded = nil
	if chunkSize == historyCompressChunkSize && cap(buffer) == stateDomainChangeHistoryEncodedChunkCapacity {
		stateDomainChangeHistoryEncodedChunkPool.Put((*stateDomainChangeHistoryEncodedChunk)(buffer[:stateDomainChangeHistoryEncodedChunkCapacity]))
	}
}

// Shared zstd encoder/decoder. klauspost's EncodeAll/DecodeAll are documented
// safe for concurrent use; the decoder is built with concurrency 0 so DecodeAll
// stays single-allocation per call and goroutine-safe.
var (
	cbEnc     *zstd.Encoder
	cbDec     *zstd.Decoder
	cbInit    sync.Once
	cbInitErr error
)

func cbCodec() (*zstd.Encoder, *zstd.Decoder, error) {
	cbInit.Do(func() {
		cbEnc, cbInitErr = zstd.NewWriter(nil, zstd.WithEncoderLevel(zstd.SpeedDefault))
		if cbInitErr != nil {
			return
		}
		cbDec, cbInitErr = zstd.NewReader(nil, zstd.WithDecoderConcurrency(0), zstd.WithDecodeAllCapLimit(true))
	})
	return cbEnc, cbDec, cbInitErr
}

type cbBlock struct {
	uncompressedStart uint64
	compressedStart   uint64
	compressedLen     uint64
	records           uint32
}

// The common base-step and lower compaction outputs fit in this 16 KiB table.
// Larger frozen files grow normally and are deliberately not retained by the
// pool, keeping cached build metadata bounded per concurrent writer.
const stateDomainChangeHistoryBlockTableCapacity = (8 << 20) / historyCompressChunkSize

type stateDomainChangeHistoryBlockTable [stateDomainChangeHistoryBlockTableCapacity]cbBlock

var stateDomainChangeHistoryBlockTablePool = sync.Pool{
	New: func() any { return new(stateDomainChangeHistoryBlockTable) },
}

func acquireStateDomainChangeHistoryBlockTable() []cbBlock {
	return stateDomainChangeHistoryBlockTablePool.Get().(*stateDomainChangeHistoryBlockTable)[:0]
}

func releaseStateDomainChangeHistoryBlockTable(table *[]cbBlock) {
	if table == nil || *table == nil {
		return
	}
	blocks := *table
	*table = nil
	if cap(blocks) == stateDomainChangeHistoryBlockTableCapacity {
		stateDomainChangeHistoryBlockTablePool.Put((*stateDomainChangeHistoryBlockTable)(blocks[:stateDomainChangeHistoryBlockTableCapacity]))
	}
}

// compressedBlockWriter accumulates opaque records, compressing them one block at
// a time into a temp file, and assembles the final file on Finish. Peak memory is
// one uncompressed block plus the in-memory block table (~32 bytes per block).
type compressedBlockWriter struct {
	enc            *zstd.Encoder
	blockSize      int
	tmp            *os.File
	tmpWriter      *bufio.Writer
	tmpName        string
	table          []cbBlock
	buf            []byte
	encoded        []byte
	bufRecs        int
	uncTotal       uint64
	compTotal      uint64
	recCount       uint64
	footerMetadata *snapshotMetadataWriter
	accountDelta   bool
	recordColumns  bool
}

type snapshotFileMetadata struct {
	size     uint64
	checksum [sha256.Size]byte
}

type snapshotMetadataWriter struct {
	dst    io.Writer
	digest hash.Hash
	size   uint64
}

func newSnapshotMetadataWriter(dst io.Writer) *snapshotMetadataWriter {
	return &snapshotMetadataWriter{dst: dst, digest: sha256.New()}
}

func (w *snapshotMetadataWriter) Write(p []byte) (int, error) {
	n, err := w.dst.Write(p)
	if n > 0 {
		_, _ = w.digest.Write(p[:n])
		w.size += uint64(n)
	}
	return n, err
}

func (w *snapshotMetadataWriter) Metadata() snapshotFileMetadata {
	var metadata snapshotFileMetadata
	if w == nil || w.digest == nil {
		return metadata
	}
	metadata.size = w.size
	copy(metadata.checksum[:], w.digest.Sum(nil))
	return metadata
}

func newCompressedBlockWriter(dir string, blockSize int) (*compressedBlockWriter, error) {
	if blockSize <= 0 {
		blockSize = CompressedBlockDefaultSize
	}
	enc, _, err := cbCodec()
	if err != nil {
		return nil, err
	}
	tmp, err := os.CreateTemp(dir, ".cbw-*.tmp")
	if err != nil {
		return nil, err
	}
	return &compressedBlockWriter{
		enc:       enc,
		blockSize: blockSize,
		tmp:       tmp,
		tmpWriter: acquireStateDomainChangeHistoryWriter(tmp),
		tmpName:   tmp.Name(),
		table:     acquireStateDomainChangeHistoryBlockTable(),
	}, nil
}

// Append adds one record and returns its uncompressed offset (the value an
// external accessor stores to address this record later).
func (w *compressedBlockWriter) Append(rec []byte) (uint64, error) {
	off := w.uncTotal
	w.buf = append(w.buf, rec...)
	w.uncTotal += uint64(len(rec))
	w.recCount++
	w.bufRecs++
	if w.bufRecs >= w.blockSize {
		if err := w.flushBlock(); err != nil {
			return 0, err
		}
	}
	return off, nil
}

func (w *compressedBlockWriter) flushBlock() error {
	if w.bufRecs == 0 {
		return nil
	}
	w.encoded = w.enc.EncodeAll(w.buf, w.encoded[:0])
	comp := w.encoded
	if _, err := w.tmpWriter.Write(comp); err != nil {
		return err
	}
	w.table = append(w.table, cbBlock{
		uncompressedStart: w.uncTotal - uint64(len(w.buf)),
		compressedStart:   w.compTotal,
		compressedLen:     uint64(len(comp)),
		records:           uint32(w.bufRecs),
	})
	w.compTotal += uint64(len(comp))
	w.buf = w.buf[:0]
	w.bufRecs = 0
	return nil
}

// appendEncodedBlock is the ordered reducer half of file compression. Encoding
// may happen out of order in workers, but the block table and temp data must be
// appended in source order so existing uncompressed accessor offsets remain
// valid and output stays deterministic.
func (w *compressedBlockWriter) appendEncodedBlock(uncompressedLen int, comp []byte) error {
	if uncompressedLen <= 0 {
		return errors.New("snapshots: cannot append empty encoded block")
	}
	if w.bufRecs != 0 {
		return errors.New("snapshots: cannot mix buffered and pre-encoded blocks")
	}
	if _, err := w.tmpWriter.Write(comp); err != nil {
		return err
	}
	w.table = append(w.table, cbBlock{
		uncompressedStart: w.uncTotal,
		compressedStart:   w.compTotal,
		compressedLen:     uint64(len(comp)),
		records:           1,
	})
	w.uncTotal += uint64(uncompressedLen)
	w.compTotal += uint64(len(comp))
	w.recCount++
	return nil
}

// Finish flushes the last partial block and writes the assembled file to path.
func (w *compressedBlockWriter) Finish(path string) (err error) {
	defer func() {
		releaseStateDomainChangeHistoryBlockTable(&w.table)
		releaseStateDomainChangeHistoryWriter(&w.tmpWriter)
		_ = w.tmp.Close()
		_ = os.Remove(w.tmpName)
	}()
	if e := w.flushBlock(); e != nil {
		return e
	}
	if err = w.tmpWriter.Flush(); err != nil {
		return err
	}
	if _, err = w.tmp.Seek(0, io.SeekStart); err != nil {
		return err
	}
	out, err := os.Create(path)
	if err != nil {
		return err
	}
	defer func() {
		if cerr := out.Close(); err == nil {
			err = cerr
		}
	}()

	// The body writer is idle after Flush. Repoint its pooled buffer at the final
	// file for metadata instead of borrowing a second large bufio.Writer.
	w.tmpWriter.Reset(out)
	if err = writeCompressedBlockHeaderAndTable(w.tmpWriter, w.blockSize, w.recCount, w.uncTotal, w.table, 0, false); err != nil {
		return err
	}
	if err = w.tmpWriter.Flush(); err != nil {
		return err
	}
	releaseStateDomainChangeHistoryWriter(&w.tmpWriter)
	if _, err = copyStateDomainChangeHistoryData(out, w.tmp); err != nil {
		return err
	}
	return out.Sync()
}

// finishWithPrefix assembles a stream whose first logical chunk stayed in
// memory so callers could backpatch fixed header fields. The body temp already
// contains independently compressed later chunks; its compressed offsets are
// shifted by the encoded prefix length while uncompressed offsets remain those
// of the original byte stream.
func (w *compressedBlockWriter) finishWithPrefix(path string, prefix []byte) error {
	return w.finishWithPrefixMetadata(path, prefix, nil)
}

func (w *compressedBlockWriter) finishWithPrefixMetadata(path string, prefix []byte, metadata *snapshotFileMetadata) (err error) {
	return w.finishWithPrefixMetadataContext(context.Background(), path, prefix, metadata)
}

func (w *compressedBlockWriter) finishWithPrefixMetadataContext(ctx context.Context, path string, prefix []byte, metadata *snapshotFileMetadata) (err error) {
	if metadata != nil {
		*metadata = snapshotFileMetadata{}
	}
	defer func() {
		releaseStateDomainChangeHistoryBlockTable(&w.table)
		releaseStateDomainChangeHistoryWriter(&w.tmpWriter)
		_ = w.tmp.Close()
		_ = os.Remove(w.tmpName)
	}()
	if err := contextError(ctx); err != nil {
		return err
	}
	if w.bufRecs != 0 || len(w.buf) != 0 {
		return errors.New("snapshots: prefixed compressed writer has buffered records")
	}
	if err = w.tmpWriter.Flush(); err != nil {
		return err
	}
	if _, err = w.tmp.Seek(0, io.SeekStart); err != nil {
		return err
	}

	var prefixComp []byte
	prefixRecords := uint64(0)
	uncTotal := w.uncTotal
	if len(prefix) != 0 {
		w.encoded = w.enc.EncodeAll(prefix, w.encoded[:0])
		prefixComp = w.encoded
		prefixRecords = 1
		if w.recCount == 0 {
			uncTotal = uint64(len(prefix))
		} else if len(w.table) == 0 || w.table[0].uncompressedStart != uint64(len(prefix)) {
			return errors.New("snapshots: compressed body does not follow retained prefix")
		}
	} else if w.recCount != 0 {
		return errors.New("snapshots: compressed body has no retained prefix")
	}

	out, err := os.Create(path)
	if err != nil {
		return err
	}
	defer func() {
		if cerr := out.Close(); err == nil {
			err = cerr
		}
	}()
	finalOut := io.Writer(contextWriter{ctx: ctx, w: out})
	var metadataWriter *snapshotMetadataWriter
	if metadata != nil {
		metadataWriter = newSnapshotMetadataWriter(finalOut)
		finalOut = metadataWriter
	}

	// The body writer is idle after Flush. Repoint its pooled buffer at the final
	// file for metadata instead of borrowing a second large bufio.Writer.
	w.tmpWriter.Reset(finalOut)
	if err = writeCompressedBlockHeaderAndTable(w.tmpWriter, w.blockSize, w.recCount+prefixRecords, uncTotal, w.table, uint64(len(prefixComp)), prefixRecords != 0); err != nil {
		return err
	}
	if err = w.tmpWriter.Flush(); err != nil {
		return err
	}
	releaseStateDomainChangeHistoryWriter(&w.tmpWriter)
	if len(prefixComp) != 0 {
		if _, err = finalOut.Write(prefixComp); err != nil {
			return err
		}
	}
	if _, err = copyStateDomainChangeHistoryData(finalOut, contextReader{ctx: ctx, r: w.tmp}); err != nil {
		return err
	}
	if err = out.Sync(); err != nil {
		return err
	}
	if metadata != nil {
		*metadata = metadataWriter.Metadata()
	}
	return nil
}

// writeCompressedBlockHeaderAndTable emits the fixed metadata straight into a
// pooled buffered writer. Emitting the final fixed-width encoding directly
// avoids allocating and growing a second whole-table buffer during every finish.
func writeCompressedBlockHeaderAndTable(out io.Writer, blockSize int, recCount, uncTotal uint64, table []cbBlock, prefixCompressedLen uint64, hasPrefix bool) error {
	blockCount := uint64(len(table))
	if hasPrefix {
		blockCount++
	}
	tableLen, err := compressedBlockTableLen(blockCount)
	if err != nil {
		return err
	}
	dataOffset, overflow := checkedAdd(compressedBlockHeaderSize, tableLen)
	if overflow {
		return errors.New("snapshots: compressed-block data offset overflows")
	}

	var header [compressedBlockHeaderSize]byte
	copy(header[:8], compressedBlockMagic)
	binary.BigEndian.PutUint32(header[8:12], compressedBlockVersion)
	binary.BigEndian.PutUint32(header[12:16], uint32(blockSize))
	binary.BigEndian.PutUint64(header[16:24], recCount)
	binary.BigEndian.PutUint64(header[24:32], blockCount)
	binary.BigEndian.PutUint64(header[32:40], uncTotal)
	binary.BigEndian.PutUint64(header[40:48], dataOffset)
	if _, err := out.Write(header[:]); err != nil {
		return err
	}

	var entry [compressedBlockTableEntry]byte
	if hasPrefix {
		binary.BigEndian.PutUint64(entry[16:24], prefixCompressedLen)
		binary.BigEndian.PutUint32(entry[24:28], 1)
		if _, err := out.Write(entry[:]); err != nil {
			return err
		}
	}
	for _, block := range table {
		compressedStart, overflow := checkedAdd(block.compressedStart, prefixCompressedLen)
		if overflow {
			return errors.New("snapshots: compressed-block data position overflows")
		}
		binary.BigEndian.PutUint64(entry[0:8], block.uncompressedStart)
		binary.BigEndian.PutUint64(entry[8:16], compressedStart)
		binary.BigEndian.PutUint64(entry[16:24], block.compressedLen)
		binary.BigEndian.PutUint32(entry[24:28], block.records)
		if _, err := out.Write(entry[:]); err != nil {
			return err
		}
	}
	return nil
}

// compressedBlockReader serves records by uncompressed offset, decompressing the
// containing block on demand with a one-block cache (so a sequential walk
// decompresses each block exactly once). Concurrent callers are serialized on mu
// and always receive a private copy, so the reader is safe to share.
type compressedBlockReader struct {
	accountDelta  bool
	recordColumns bool
	columnScratch []byte
	cdc           *cdcReader
	prefixCache   *historyHeaderCache
	headerPrefix  *historyHeaderPrefix
	f             compressedBlockPhysicalFile
	dec           *zstd.Decoder
	blockSize     int
	recCount      uint64
	uncSize       uint64
	dataOff       uint64
	fileSize      uint64
	table         []cbBlock

	mu         sync.Mutex
	cacheLimit int
	compressed []byte
	cache      []cbCacheEntry // small MRU-ordered decompressed-block cache (front = newest)
}

// The owner may coalesce physical reads while preserving the same descriptor
// identity, diagnostics and Close lifetime. This is below all codec validation.
type compressedBlockPhysicalFile interface {
	io.ReaderAt
	io.Closer
	Name() string
}

type cbCacheEntry struct {
	idx   int
	bytes []byte
}

// cbCacheBlocks bounds the decompressed-block cache. 1 is optimal for sequential
// scans (range reads); a keyed binary search probes ~2·log N random blocks and a
// 1-block cache thrashes, so a small MRU cache lets the search's narrowing phase
// re-hit recent blocks. ~16 × block-size of transient memory per open reader.
const cbCacheBlocks = 16

func openCompressedBlockReader(path string) (*compressedBlockReader, error) {
	return openCompressedBlockReaderWithCacheLimit(path, cbCacheBlocks)
}

func openCompressedBlockReaderWithCacheLimit(path string, cacheLimit int) (*compressedBlockReader, error) {
	return openCompressedBlockReaderWithCacheLimitContext(nil, path, cacheLimit)
}

// Initialization owns no codec locks, so metadata reads and table validation
// may cooperatively yield. The stored reader remains unwrapped: runtime codec
// reads hold its private mutex and must only checkpoint at the outer reader.
func openCompressedBlockReaderWithCacheLimitContext(ctx context.Context, path string, cacheLimit int) (*compressedBlockReader, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	stat, err := f.Stat()
	if err != nil {
		_ = f.Close()
		return nil, err
	}
	return openCompressedBlockFileWithCacheLimitContext(ctx, f, stat, cacheLimit)
}

// Takes ownership of f on success AND failure. Magic dispatchers pass the
// same descriptor they already sized/inspected, avoiding a second open/stat
// and a path-replacement race between physical identity and decoding.
func openCompressedBlockFileWithCacheLimitContext(ctx context.Context, f compressedBlockPhysicalFile, stat os.FileInfo, cacheLimit int) (*compressedBlockReader, error) {
	if cacheLimit < 1 || cacheLimit > cbCacheBlocks {
		_ = f.Close()
		return nil, fmt.Errorf("snapshots: compressed-block cache limit %d outside [1,%d]", cacheLimit, cbCacheBlocks)
	}
	_, dec, err := cbCodec()
	if err != nil {
		_ = f.Close()
		return nil, err
	}
	fileSize := uint64(stat.Size())
	if fileSize < compressedBlockHeaderSize {
		_ = f.Close()
		return nil, fmt.Errorf("snapshots: compressed-block file %q size %d below header size %d", f.Name(), fileSize, compressedBlockHeaderSize)
	}
	hdr := make([]byte, compressedBlockHeaderSize)
	if _, err := (contextReaderAt{ctx: ctx, r: f}).ReadAt(hdr, 0); err != nil {
		_ = f.Close()
		return nil, err
	}
	if string(hdr[:8]) != compressedBlockMagic {
		_ = f.Close()
		return nil, errors.New("snapshots: bad compressed-block magic")
	}
	if binary.BigEndian.Uint32(hdr[8:12]) == compressedBlockCDCVersion {
		cdc, err := openCDCReaderContext(ctx, contextReaderAt{ctx: ctx, r: f}, fileSize, hdr)
		if err != nil {
			_ = f.Close()
			return nil, err
		}
		cdc.src = f
		return &compressedBlockReader{f: f, dec: dec, uncSize: cdc.logical, fileSize: fileSize, cdc: cdc}, nil
	}
	if binary.BigEndian.Uint32(hdr[8:12]) == compressedBlockFooterVersion || accountDeltaFooterVersion(hdr) || recordColumnFooterVersion(hdr) {
		layout, err := readCompressedBlockFooterLayoutContext(ctx, contextReaderAt{ctx: ctx, r: f}, fileSize, hdr)
		if err != nil {
			_ = f.Close()
			return nil, err
		}
		return &compressedBlockReader{accountDelta: accountDeltaFooterVersion(hdr), recordColumns: recordColumnFooterVersion(hdr), f: f, dec: dec, blockSize: layout.blockSize,
			recCount: layout.recCount, uncSize: layout.uncSize, dataOff: compressedBlockHeaderSize,
			fileSize: fileSize, table: layout.table, cacheLimit: accountDeltaDecodedCacheLimit(hdr, layout, cacheLimit)}, nil
	}
	if ver := binary.BigEndian.Uint32(hdr[8:12]); ver != compressedBlockVersion {
		_ = f.Close()
		return nil, fmt.Errorf("snapshots: unsupported compressed-block version %d", ver)
	}
	r := &compressedBlockReader{
		f:          f,
		dec:        dec,
		blockSize:  int(binary.BigEndian.Uint32(hdr[12:16])),
		recCount:   binary.BigEndian.Uint64(hdr[16:24]),
		dataOff:    binary.BigEndian.Uint64(hdr[40:48]),
		fileSize:   fileSize,
		cacheLimit: cacheLimit,
	}
	blockCount := binary.BigEndian.Uint64(hdr[24:32])
	r.uncSize = binary.BigEndian.Uint64(hdr[32:40])
	if r.blockSize <= 0 {
		_ = f.Close()
		return nil, errors.New("snapshots: compressed-block has zero block size")
	}
	tableLen, err := compressedBlockTableLen(blockCount)
	if err != nil {
		_ = f.Close()
		return nil, err
	}
	tableEnd, overflow := checkedAdd(compressedBlockHeaderSize, tableLen)
	if overflow || tableEnd > fileSize {
		_ = f.Close()
		return nil, fmt.Errorf("snapshots: compressed-block table end %d outside file size %d", tableEnd, fileSize)
	}
	if r.dataOff != tableEnd {
		_ = f.Close()
		return nil, fmt.Errorf("snapshots: compressed-block data offset %d, want table end %d", r.dataOff, tableEnd)
	}
	tableBytes := make([]byte, int(tableLen))
	if _, err := (contextReaderAt{ctx: ctx, r: f}).ReadAt(tableBytes, compressedBlockHeaderSize); err != nil {
		_ = f.Close()
		return nil, err
	}
	r.table = make([]cbBlock, blockCount)
	for i := uint64(0); i < blockCount; i++ {
		if i%1024 == 0 {
			if err := maintenance.WorkCheckpoint(ctx, 0); err != nil {
				_ = f.Close()
				return nil, err
			}
		}
		o := i * compressedBlockTableEntry
		r.table[i] = cbBlock{
			uncompressedStart: binary.BigEndian.Uint64(tableBytes[o : o+8]),
			compressedStart:   binary.BigEndian.Uint64(tableBytes[o+8 : o+16]),
			compressedLen:     binary.BigEndian.Uint64(tableBytes[o+16 : o+24]),
			records:           binary.BigEndian.Uint32(tableBytes[o+24 : o+28]),
		}
	}
	if err := validateCompressedBlockPhysicalTableContext(ctx, r.table, r.recCount, r.uncSize, r.dataOff, fileSize, false); err != nil {
		_ = f.Close()
		return nil, err
	}
	return r, nil
}

func (r *compressedBlockReader) Close() error { return r.f.Close() }

func compressedBlockMaxAlloc() uint64 {
	return uint64(int(^uint(0) >> 1))
}

func compressedBlockTableLen(blockCount uint64) (uint64, error) {
	if blockCount > uint64(1)<<40 {
		return 0, fmt.Errorf("snapshots: implausible compressed-block count %d", blockCount)
	}
	tableLen, overflow := checkedMul(blockCount, compressedBlockTableEntry)
	if overflow || tableLen > compressedBlockMaxAlloc() {
		return 0, fmt.Errorf("snapshots: compressed-block table size overflows: count=%d", blockCount)
	}
	return tableLen, nil
}

func validateCompressedBlockTable(table []cbBlock, recCount, uncSize, dataOff, fileSize uint64) error {
	return validateCompressedBlockPhysicalTable(table, recCount, uncSize, dataOff, fileSize, false)
}

func validateCompressedBlockPhysicalTable(table []cbBlock, recCount, uncSize, dataOff, fileSize uint64, prefixAtEnd bool) error {
	return validateCompressedBlockPhysicalTableContext(nil, table, recCount, uncSize, dataOff, fileSize, prefixAtEnd)
}

func validateCompressedBlockPhysicalTableContext(ctx context.Context, table []cbBlock, recCount, uncSize, dataOff, fileSize uint64, prefixAtEnd bool) error {
	if len(table) == 0 {
		if recCount != 0 || uncSize != 0 {
			return fmt.Errorf("snapshots: empty compressed-block table with records=%d uncompressed=%d", recCount, uncSize)
		}
		if dataOff != fileSize {
			return fmt.Errorf("snapshots: empty compressed-block data offset %d, want file size %d", dataOff, fileSize)
		}
		return nil
	}
	if recCount == 0 || uncSize == 0 {
		return fmt.Errorf("snapshots: compressed-block table has %d blocks with records=%d uncompressed=%d", len(table), recCount, uncSize)
	}
	var expectedCompStart uint64
	var prevUncStart uint64
	var records uint64
	for i, block := range table {
		if i%1024 == 0 {
			if err := maintenance.WorkCheckpoint(ctx, 0); err != nil {
				return err
			}
		}
		if block.records == 0 {
			return fmt.Errorf("snapshots: compressed-block table entry %d has zero records", i)
		}
		if i == 0 {
			if block.uncompressedStart != 0 {
				return fmt.Errorf("snapshots: compressed-block first uncompressed offset %d, want 0", block.uncompressedStart)
			}
		} else if block.uncompressedStart <= prevUncStart {
			return fmt.Errorf("snapshots: compressed-block uncompressed offsets are not increasing at entry %d", i)
		}
		if block.uncompressedStart >= uncSize {
			return fmt.Errorf("snapshots: compressed-block uncompressed offset %d outside size %d", block.uncompressedStart, uncSize)
		}
		if (!prefixAtEnd || i != 0) && block.compressedStart != expectedCompStart {
			return fmt.Errorf("snapshots: compressed-block entry %d compressed offset %d, want %d", i, block.compressedStart, expectedCompStart)
		}
		if block.compressedLen == 0 {
			return fmt.Errorf("snapshots: compressed-block entry %d has zero compressed length", i)
		}
		compEnd, overflow := checkedAdd(block.compressedStart, block.compressedLen)
		if overflow {
			return fmt.Errorf("snapshots: compressed-block entry %d compressed range overflows", i)
		}
		physicalStart, overflow := checkedAdd(dataOff, block.compressedStart)
		if overflow {
			return fmt.Errorf("snapshots: compressed-block entry %d physical offset overflows", i)
		}
		physicalEnd, overflow := checkedAdd(dataOff, compEnd)
		if overflow || physicalEnd > fileSize {
			return fmt.Errorf("snapshots: compressed-block entry %d range [%d,%d] outside file size %d", i, physicalStart, physicalEnd, fileSize)
		}
		var recordsOverflow bool
		records, recordsOverflow = checkedAdd(records, uint64(block.records))
		if recordsOverflow {
			return fmt.Errorf("snapshots: compressed-block record count overflows")
		}
		if !prefixAtEnd || i != 0 {
			expectedCompStart = compEnd
		}
		prevUncStart = block.uncompressedStart
	}
	if prefixAtEnd {
		if expectedCompStart != table[0].compressedStart {
			return errors.New("snapshots: footer body does not end at retained prefix")
		}
		expectedCompStart += table[0].compressedLen // range overflow was checked above
	}
	physicalEnd, overflow := checkedAdd(dataOff, expectedCompStart)
	if overflow || physicalEnd != fileSize {
		return fmt.Errorf("snapshots: compressed-block data end %d, want file size %d", physicalEnd, fileSize)
	}
	if records != recCount {
		return fmt.Errorf("snapshots: compressed-block records=%d, want %d", records, recCount)
	}
	return nil
}

func compressedBlockExpectedLen(table []cbBlock, uncSize uint64, index int) (uint64, error) {
	if index < 0 || index >= len(table) {
		return 0, fmt.Errorf("snapshots: compressed-block index %d outside table", index)
	}
	start := table[index].uncompressedStart
	end := uncSize
	if index+1 < len(table) {
		end = table[index+1].uncompressedStart
	}
	if end <= start {
		return 0, fmt.Errorf("snapshots: compressed-block entry %d has invalid uncompressed range [%d,%d]", index, start, end)
	}
	length := end - start
	if length > compressedBlockMaxAlloc() {
		return 0, fmt.Errorf("snapshots: compressed-block entry %d uncompressed length %d exceeds allocation limit", index, length)
	}
	if length > compressedBlockMaxDecodedBlockSize {
		return 0, fmt.Errorf("snapshots: compressed-block entry %d uncompressed length %d exceeds decoded block limit %d", index, length, compressedBlockMaxDecodedBlockSize)
	}
	return length, nil
}

// findBlock returns the index of the block whose uncompressed range contains
// offset, or -1.
func (r *compressedBlockReader) findBlock(offset uint64) int {
	i := sort.Search(len(r.table), func(k int) bool { return r.table[k].uncompressedStart > offset })
	return i - 1
}

// blockBytes returns the decompressed bytes of block i (caller holds r.mu). The
// returned slice aliases the cache and must not be retained past the unlock.
func (r *compressedBlockReader) blockBytes(i int) ([]byte, error) {
	for j := range r.cache {
		if r.cache[j].idx == i {
			e := r.cache[j]
			copy(r.cache[1:j+1], r.cache[:j]) // move to front (MRU)
			r.cache[0] = e
			return e.bytes, nil
		}
	}
	comp, expectedLen, err := r.readCompressedBlock(i)
	if err != nil {
		return nil, err
	}
	return r.decodeBlock(i, comp, expectedLen)
}

// readCompressedBlock retains the complete physical bounds and allocation checks
// even when a previously decoded header prefix may be reused.
func (r *compressedBlockReader) readCompressedBlock(i int) ([]byte, uint64, error) {
	b := r.table[i]
	expectedLen, err := compressedBlockExpectedLen(r.table, r.uncSize, i)
	if err != nil {
		return nil, 0, err
	}
	compStart, overflow := checkedAdd(r.dataOff, b.compressedStart)
	if overflow {
		return nil, 0, fmt.Errorf("snapshots: compressed-block entry %d physical offset overflows", i)
	}
	compEnd, overflow := checkedAdd(compStart, b.compressedLen)
	if overflow || compEnd > r.fileSize {
		return nil, 0, fmt.Errorf("snapshots: compressed-block entry %d range [%d,%d] outside file size %d", i, compStart, compEnd, r.fileSize)
	}
	if compEnd > uint64(1<<63-1) {
		return nil, 0, fmt.Errorf("snapshots: compressed-block entry %d end %d exceeds int64", i, compEnd)
	}
	if b.compressedLen > compressedBlockMaxAlloc() {
		return nil, 0, fmt.Errorf("snapshots: compressed-block entry %d compressed length %d exceeds allocation limit", i, b.compressedLen)
	}
	compressedLen := int(b.compressedLen)
	if cap(r.compressed) < compressedLen {
		r.compressed = make([]byte, compressedLen)
	}
	comp := r.compressed[:compressedLen]
	if _, err := r.f.ReadAt(comp, int64(compStart)); err != nil {
		return nil, 0, err
	}
	return comp, expectedLen, nil
}

func (r *compressedBlockReader) decodeBlock(i int, comp []byte, expectedLen uint64) ([]byte, error) {
	var decoded []byte
	if len(r.cache) >= r.cacheLimit {
		decoded = r.cache[len(r.cache)-1].bytes[:0]
	}
	if uint64(cap(decoded)) < expectedLen {
		decoded = make([]byte, 0, int(expectedLen))
	}
	var dst []byte
	var err error
	if r.recordColumns {
		dst, r.columnScratch, err = decodeRecordColumnStoredPage(comp, expectedLen, decoded, r.columnScratch)
	} else if r.accountDelta {
		dst, err = decodeAccountDeltaStoredPage(comp, expectedLen, decoded)
	} else {
		dst, err = r.dec.DecodeAll(comp, decoded)
	}
	if err != nil {
		return nil, err
	}
	if uint64(len(dst)) != expectedLen {
		return nil, fmt.Errorf("snapshots: compressed-block entry %d decoded to %d bytes, want %d", i, len(dst), expectedLen)
	}
	if len(r.cache) < r.cacheLimit {
		r.cache = append(r.cache, cbCacheEntry{})
	}
	copy(r.cache[1:], r.cache[:len(r.cache)-1]) // shift down, evicting the tail
	r.cache[0] = cbCacheEntry{idx: i, bytes: dst}
	return dst, nil
}

// RecordTailAt returns a private copy of the decompressed block from the record
// at offset to the end of its block. The caller decodes one self-delimiting
// record from the head of the returned slice. Used for keyed point lookups.
func (r *compressedBlockReader) RecordTailAt(offset uint64) ([]byte, error) {
	if r.cdc != nil {
		data, start, err := r.cdc.BlockAt(offset)
		if err != nil {
			return nil, err
		}
		return data[offset-start:], nil
	}
	if offset >= r.uncSize {
		return nil, fmt.Errorf("snapshots: compressed-block offset %d >= size %d", offset, r.uncSize)
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	i := r.findBlock(offset)
	if i < 0 {
		return nil, fmt.Errorf("snapshots: no compressed block for offset %d", offset)
	}
	blk, err := r.blockBytes(i)
	if err != nil {
		return nil, err
	}
	intra := offset - r.table[i].uncompressedStart
	if intra > uint64(len(blk)) {
		return nil, fmt.Errorf("snapshots: compressed-block intra offset %d > block len %d", intra, len(blk))
	}
	return append([]byte(nil), blk[intra:]...), nil
}

// ReadAt implements io.ReaderAt over the uncompressed logical content: it fills p
// with bytes starting at uncompressed offset off, decompressing whatever blocks
// the range spans (one-block cache makes a sequential scan decompress each block
// once). This is the seam that lets existing offset/ReadAt-based readers operate
// over a compressed segment unchanged: store the segment's plain bytes through
// compressBlobToFile, then hand the reader this ReadAt and the logical size.
func (r *compressedBlockReader) ReadAt(p []byte, off int64) (int, error) {
	if r.cdc != nil {
		return r.cdc.ReadAt(p, off)
	}
	if off < 0 {
		return 0, errors.New("snapshots: negative compressed-block read offset")
	}
	if len(p) == 0 {
		return 0, nil
	}
	uoff := uint64(off)
	if uoff >= r.uncSize {
		return 0, io.EOF
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	return r.readAtLocked(p, uoff)
}

func (r *compressedBlockReader) readAtLocked(p []byte, uoff uint64) (int, error) {
	if r.prefixCache != nil && len(r.table) != 0 && r.table[0].uncompressedStart == 0 && uoff < historyHeaderPrefixBytes && uint64(len(p)) <= historyHeaderPrefixBytes-uoff && uoff+uint64(len(p)) <= r.uncSize {
		return r.readHeaderPrefix(p, uoff)
	}
	n := 0
	for n < len(p) {
		cur := uoff + uint64(n)
		if cur >= r.uncSize {
			return n, io.EOF
		}
		i := r.findBlock(cur)
		if i < 0 {
			return n, fmt.Errorf("snapshots: no compressed block for offset %d", cur)
		}
		blk, err := r.blockBytes(i)
		if err != nil {
			return n, err
		}
		intra := cur - r.table[i].uncompressedStart
		if intra >= uint64(len(blk)) {
			return n, io.ErrUnexpectedEOF
		}
		n += copy(p[n:], blk[intra:])
	}
	return n, nil
}

// ReadRecordFrameAt reads one uint32-length-prefixed logical record. Frames
// contained by one decoded block borrow that cache entry directly, matching an
// Erigon Getter.Next-style sequential view. A frame crossing block boundaries
// is copied into scratch, which is returned for reuse by the next call.
//
// A borrowed payload is valid only until the next reader operation. Callers
// must consume it synchronously and must not modify it.
func (r *compressedBlockReader) ReadRecordFrameAt(offset uint64, scratch []byte) (payload []byte, next uint64, borrowed bool, err error) {
	if r == nil {
		return scratch, 0, false, errors.New("snapshots: nil compressed-block record reader")
	}
	if r.cdc != nil {
		return r.cdc.ReadRecordFrameAt(offset, scratch)
	}
	if offset > r.uncSize || r.uncSize-offset < 4 {
		return scratch, 0, false, io.ErrUnexpectedEOF
	}
	r.mu.Lock()
	defer r.mu.Unlock()

	i := r.findBlock(offset)
	if i < 0 {
		return scratch, 0, false, fmt.Errorf("snapshots: no compressed block for record offset %d", offset)
	}
	blk, err := r.blockBytes(i)
	if err != nil {
		return scratch, 0, false, err
	}
	intra := offset - r.table[i].uncompressedStart
	var prefix [4]byte
	if intra <= uint64(len(blk)) && uint64(len(blk))-intra >= uint64(len(prefix)) {
		copy(prefix[:], blk[intra:intra+uint64(len(prefix))])
	} else if _, err := r.readAtLocked(prefix[:], offset); err != nil {
		return scratch, 0, false, err
	}
	length := uint64(binary.BigEndian.Uint32(prefix[:]))
	frameSize, overflow := checkedAdd(4, length)
	if overflow || frameSize > r.uncSize-offset {
		return scratch, 0, false, io.ErrUnexpectedEOF
	}
	next = offset + frameSize
	if intra <= uint64(len(blk)) && frameSize <= uint64(len(blk))-intra {
		start := intra + 4
		return blk[start : start+length], next, true, nil
	}
	if length > compressedBlockMaxAlloc() {
		return scratch, 0, false, fmt.Errorf("snapshots: compressed-block record length %d exceeds allocation limit", length)
	}
	if cap(scratch) < int(length) {
		scratch = make([]byte, length)
	} else {
		scratch = scratch[:length]
	}
	if _, err := r.readAtLocked(scratch, offset+4); err != nil {
		return scratch, 0, false, err
	}
	return scratch, next, false, nil
}

// UncompressedSize returns the total uncompressed logical size, i.e. the value a
// caller passes as fileSize to a bounded reader operating over ReadAt.
func (r *compressedBlockReader) UncompressedSize() uint64 { return r.uncSize }

// isCompressedBlockBlob reports whether data begins with the compressed-block
// magic — i.e. whether a segment file is compressed.
func isCompressedBlockBlob(data []byte) bool {
	return len(data) >= len(compressedBlockMagic) && string(data[:len(compressedBlockMagic)]) == compressedBlockMagic
}

// decompressBlockBlob returns the full uncompressed logical content of an
// in-memory compressed-block blob (the inverse of compressBlobToFile). Used by
// the whole-segment readers/checkers that scan the entire segment in memory.
func decompressBlockBlob(data []byte) ([]byte, error) {
	if len(data) < compressedBlockHeaderSize || !isCompressedBlockBlob(data) {
		return nil, errors.New("snapshots: not a compressed-block blob")
	}
	_, dec, err := cbCodec()
	if err != nil {
		return nil, err
	}
	version := binary.BigEndian.Uint32(data[8:12])
	if version == compressedBlockCDCVersion {
		return decompressCDCBlob(data)
	}
	if version == compressedBlockFooterVersion || version == compressedBlockAccountDeltaVersion || version == compressedBlockRecordColumnsVersion {
		layout, err := readCompressedBlockFooterLayout(bytes.NewReader(data), uint64(len(data)), data[:compressedBlockHeaderSize])
		if err != nil {
			return nil, err
		}
		if version == compressedBlockAccountDeltaVersion {
			return decompressAccountDeltaBlob(data, layout)
		}
		if version == compressedBlockRecordColumnsVersion {
			return decompressRecordColumnBlob(data, layout)
		}
		return decodeCompressedBlockBlob(data, dec, layout.table, layout.uncSize, compressedBlockHeaderSize)
	}
	if version != compressedBlockVersion {
		return nil, fmt.Errorf("snapshots: unsupported compressed-block version %d", version)
	}
	blockCount := binary.BigEndian.Uint64(data[24:32])
	uncSize := binary.BigEndian.Uint64(data[32:40])
	dataOff := binary.BigEndian.Uint64(data[40:48])
	tableLen, err := compressedBlockTableLen(blockCount)
	if err != nil {
		return nil, err
	}
	tableEnd, overflow := checkedAdd(compressedBlockHeaderSize, tableLen)
	if overflow || tableEnd > uint64(len(data)) {
		return nil, errors.New("snapshots: corrupt compressed-block blob header")
	}
	if dataOff != tableEnd {
		return nil, fmt.Errorf("snapshots: compressed-block data offset %d, want table end %d", dataOff, tableEnd)
	}
	table := make([]cbBlock, blockCount)
	for i := uint64(0); i < blockCount; i++ {
		o := uint64(compressedBlockHeaderSize) + i*compressedBlockTableEntry
		table[i] = cbBlock{
			uncompressedStart: binary.BigEndian.Uint64(data[o : o+8]),
			compressedStart:   binary.BigEndian.Uint64(data[o+8 : o+16]),
			compressedLen:     binary.BigEndian.Uint64(data[o+16 : o+24]),
			records:           binary.BigEndian.Uint32(data[o+24 : o+28]),
		}
	}
	if err := validateCompressedBlockTable(table, binary.BigEndian.Uint64(data[16:24]), uncSize, dataOff, uint64(len(data))); err != nil {
		return nil, err
	}
	return decodeCompressedBlockBlob(data, dec, table, uncSize, dataOff)
}

func decodeCompressedBlockBlob(data []byte, dec *zstd.Decoder, table []cbBlock, uncSize, dataOff uint64) ([]byte, error) {
	if uncSize > compressedBlockMaxAlloc() {
		return nil, fmt.Errorf("snapshots: compressed-block uncompressed size %d exceeds allocation limit", uncSize)
	}
	out := make([]byte, 0)
	for i := range table {
		expectedLen, err := compressedBlockExpectedLen(table, uncSize, i)
		if err != nil {
			return nil, err
		}
		start, overflow := checkedAdd(dataOff, table[i].compressedStart)
		if overflow {
			return nil, fmt.Errorf("snapshots: compressed-block blob block %d offset overflows", i)
		}
		end, overflow := checkedAdd(start, table[i].compressedLen)
		if overflow || end > uint64(len(data)) {
			return nil, errors.New("snapshots: corrupt compressed-block blob block")
		}
		dst, err := dec.DecodeAll(data[start:end], make([]byte, 0, int(expectedLen)))
		if err != nil {
			return nil, err
		}
		if uint64(len(dst)) != expectedLen {
			return nil, fmt.Errorf("snapshots: compressed-block blob block %d decoded to %d bytes, want %d", i, len(dst), expectedLen)
		}
		out = append(out, dst...)
	}
	if uint64(len(out)) != uncSize {
		return nil, fmt.Errorf("snapshots: compressed-block blob decompressed to %d bytes, want %d", len(out), uncSize)
	}
	return out, nil
}

// compressBlobToFile stores blob block-compressed at path, chunked into chunkSize
// pieces (one block each). The result is byte-addressable via ReadAt at the same
// offsets as the original blob — so an existing segment's serialized bytes can be
// compressed on disk while its .idx/.kv accessor offsets stay valid.
func compressBlobToFile(dir, path string, blob []byte, chunkSize int) error {
	if chunkSize <= 0 {
		chunkSize = 16384
	}
	footer, err := historyCompressionFooterEnabled()
	if err != nil {
		return err
	}
	if footer {
		// The footer publishes the temporary inode with rename. Keep it on the
		// destination filesystem even when a history tier is mounted elsewhere.
		var stream historyCompressedStream
		var err error
		if os.Getenv("GTRON_HISTORY_COMPRESSION_FORMAT") == "3" {
			stream, err = newCDCStreamWriterWorkers(context.Background(), filepath.Dir(path), chunkSize, 1)
		} else {
			stream, err = newCompressedBlockStreamWriterWithFooter(filepath.Dir(path), chunkSize, 1, true)
		}
		if err != nil {
			return err
		}
		defer stream.Abort()
		if _, err := stream.Write(blob); err != nil {
			return err
		}
		return stream.Finish(path)
	}
	w, err := newCompressedBlockWriter(dir, 1)
	if err != nil {
		return err
	}
	for off := 0; off < len(blob); off += chunkSize {
		end := off + chunkSize
		if end > len(blob) {
			end = len(blob)
		}
		if _, err := w.Append(blob[off:end]); err != nil {
			releaseStateDomainChangeHistoryBlockTable(&w.table)
			releaseStateDomainChangeHistoryWriter(&w.tmpWriter)
			_ = w.tmp.Close()
			_ = os.Remove(w.tmpName)
			return err
		}
	}
	return w.Finish(path)
}

// historyCompressionConcurrency follows Erigon's ordered page-compression
// worker model while reserving CPU for block execution and Pebble compaction.
// Keep the automatic limit independent of a large host-wide CPU count. V3
// uses this budget for bounded parallel anchors as well as large-input cuts;
// increasing the budget must be justified by end-to-end stage measurements.
func historyCompressionConcurrency(procs int) int {
	if procs < 1 {
		return 1
	}
	if procs > maxHistoryCompressionWorkers {
		return maxHistoryCompressionWorkers
	}
	return procs
}

type compressedFileJob struct {
	seq  uint64
	data []byte
}

type compressedFileResult struct {
	seq          uint64
	uncompressed []byte
	compressed   []byte
}

// orderedCompressionPipeline accepts owned, fixed-size logical chunks from one
// writer, encodes them on bounded workers, and appends results to out in input
// order. The caller owns exactly one additional current chunk; the pool holds
// the other workers*2-1 chunks, keeping total uncompressed in-flight memory at
// workers*2 chunks. A matching bounded pool of encoded destinations follows
// each result through the ordered reducer and is reused only after its bytes
// have been written to the body file.
type orderedCompressionPipeline struct {
	out       *compressedBlockWriter
	chunkSize int
	jobs      chan compressedFileJob
	results   chan compressedFileResult
	pool      chan []byte
	encoded   chan []byte
	done      chan struct{}
	cancel    sync.Once
	closeJobs sync.Once
	workers   sync.WaitGroup
	reducer   sync.WaitGroup

	errMu sync.Mutex
	err   error
	seq   uint64
}

func newOrderedCompressionPipeline(out *compressedBlockWriter, chunkSize, workers int) *orderedCompressionPipeline {
	inFlight := workers * 2
	p := &orderedCompressionPipeline{
		out:       out,
		chunkSize: chunkSize,
		jobs:      make(chan compressedFileJob, inFlight),
		results:   make(chan compressedFileResult, inFlight),
		pool:      make(chan []byte, inFlight),
		encoded:   make(chan []byte, inFlight),
		done:      make(chan struct{}),
	}
	// The stream writer transfers its current chunk as the final pool member.
	for i := 1; i < inFlight; i++ {
		p.pool <- acquireStateDomainChangeHistoryCompressionChunk(chunkSize)
	}
	for range inFlight {
		p.encoded <- acquireStateDomainChangeHistoryEncodedChunk(out.enc, chunkSize)
	}

	p.workers.Add(workers)
	for range workers {
		go func() {
			defer p.workers.Done()
			for {
				select {
				case job, ok := <-p.jobs:
					if !ok {
						return
					}
					var encoded []byte
					select {
					case encoded = <-p.encoded:
					case <-p.done:
						return
					}
					result := compressedFileResult{
						seq:          job.seq,
						uncompressed: job.data,
						compressed:   p.out.enc.EncodeAll(job.data, encoded[:0]),
					}
					select {
					case p.results <- result:
					case <-p.done:
						return
					}
				case <-p.done:
					return
				}
			}
		}()
	}
	go func() {
		p.workers.Wait()
		close(p.results)
	}()
	p.reducer.Add(1)
	go p.reduce()
	return p
}

func (p *orderedCompressionPipeline) reduce() {
	defer p.reducer.Done()
	pending := make(map[uint64]compressedFileResult, cap(p.results))
	var next uint64
	for result := range p.results {
		if p.Err() != nil {
			continue
		}
		pending[result.seq] = result
		for {
			ready, ok := pending[next]
			if !ok {
				break
			}
			if err := p.out.appendEncodedBlock(len(ready.uncompressed), ready.compressed); err != nil {
				p.setError(err)
				break
			}
			delete(pending, next)
			select {
			case p.pool <- ready.uncompressed[:0]:
			case <-p.done:
			}
			select {
			case p.encoded <- ready.compressed[:0]:
			case <-p.done:
			}
			next++
		}
	}
	if p.Err() == nil && len(pending) != 0 {
		p.setError(fmt.Errorf("snapshots: streaming compression reducer stopped with %d pending blocks", len(pending)))
	}
}

func (p *orderedCompressionPipeline) setError(err error) {
	if err == nil {
		return
	}
	p.errMu.Lock()
	if p.err == nil {
		p.err = err
		p.cancel.Do(func() { close(p.done) })
	}
	p.errMu.Unlock()
}

func (p *orderedCompressionPipeline) Err() error {
	p.errMu.Lock()
	defer p.errMu.Unlock()
	return p.err
}

func (p *orderedCompressionPipeline) Submit(data []byte) error {
	if err := p.Err(); err != nil {
		return err
	}
	job := compressedFileJob{seq: p.seq, data: data}
	select {
	case p.jobs <- job:
		p.seq++
		return nil
	case <-p.done:
		return p.Err()
	}
}

func (p *orderedCompressionPipeline) Acquire() ([]byte, error) {
	select {
	case buf := <-p.pool:
		return buf, nil
	case <-p.done:
		return nil, p.Err()
	}
}

func (p *orderedCompressionPipeline) Close() error {
	p.closeJobs.Do(func() { close(p.jobs) })
	p.reducer.Wait()
	p.releaseAvailableBuffers()
	return p.Err()
}

func (p *orderedCompressionPipeline) Abort() {
	p.cancel.Do(func() { close(p.done) })
	p.closeJobs.Do(func() { close(p.jobs) })
	p.reducer.Wait()
	p.releaseAvailableBuffers()
}

// releaseAvailableBuffers runs only after workers and the ordered reducer have
// joined. Buffers present in the channels are idle and uniquely owned here;
// buffers abandoned in queued jobs/results on an error remain for GC rather
// than risk returning storage that another goroutine may still reference.
func (p *orderedCompressionPipeline) releaseAvailableBuffers() {
	for len(p.pool) != 0 {
		chunk := <-p.pool
		releaseStateDomainChangeHistoryCompressionChunk(&chunk, p.chunkSize)
	}
	for len(p.encoded) != 0 {
		buffer := <-p.encoded
		releaseStateDomainChangeHistoryEncodedChunk(&buffer, p.chunkSize)
	}
}

// compressedBlockStreamWriter preserves only the first logical chunk for
// fixed-header WriteAt updates. Every later full chunk is immediately encoded;
// after the measured break-even size, encoding moves to the ordered worker
// pipeline above. No complete uncompressed segment is written to disk.
type compressedBlockStreamWriter struct {
	accountDeltas *accountDeltaStreamNotes
	recordHeaders *recordColumnStreamNotes
	dir           string
	chunkSize     int
	prefixSize    int
	workers       int
	body          *compressedBlockWriter
	first         []byte
	chunk         []byte
	parallel      *orderedCompressionPipeline
	logical       uint64
	bodyStart     bool
	footer        bool
	closed        bool
}

func newCompressedBlockStreamWriter(dir string, chunkSize, workers int) (*compressedBlockStreamWriter, error) {
	footer, err := historyCompressionFooterEnabled()
	if err != nil {
		return nil, err
	}
	return newCompressedBlockStreamWriterWithFooter(dir, chunkSize, workers, footer)
}

func newCompressedBlockStreamWriterWithFooter(dir string, chunkSize, workers int, footer bool) (*compressedBlockStreamWriter, error) {
	return newCompressedBlockStreamWriterWithPrefix(dir, chunkSize, chunkSize, workers, footer)
}

// Prefix and body have independent boundaries. History point reads need only
// the header, dictionary commitment and range count, not a 128 KiB range table.
// Both remain ordinary independently checksummed compression blocks.
func newCompressedBlockStreamWriterWithPrefix(dir string, chunkSize, prefixSize, workers int, footer bool) (*compressedBlockStreamWriter, error) {
	if chunkSize <= 0 {
		chunkSize = 16384
	}
	if prefixSize <= 0 || prefixSize > chunkSize {
		prefixSize = chunkSize
	}
	if workers < 1 {
		workers = 1
	}
	body, err := newCompressedBlockStreamBody(dir, footer)
	if err != nil {
		return nil, err
	}
	body.encoded = acquireStateDomainChangeHistoryEncodedChunk(body.enc, chunkSize)
	return &compressedBlockStreamWriter{
		dir:        dir,
		chunkSize:  chunkSize,
		prefixSize: prefixSize,
		workers:    workers,
		body:       body,
		footer:     footer,
		first:      acquireStateDomainChangeHistoryCompressionChunk(chunkSize),
	}, nil
}

func (w *compressedBlockStreamWriter) Write(p []byte) (int, error) {
	if w == nil || w.closed || w.body == nil {
		return 0, errors.New("snapshots: compressed stream writer is closed")
	}
	written := 0
	if len(w.first) < w.prefixSize {
		n := w.prefixSize - len(w.first)
		if n > len(p) {
			n = len(p)
		}
		w.first = append(w.first, p[:n]...)
		p = p[n:]
		written += n
		w.logical += uint64(n)
		if len(p) == 0 {
			return written, nil
		}
	}
	if w.chunk == nil {
		w.chunk = acquireStateDomainChangeHistoryCompressionChunk(w.chunkSize)
	}
	for len(p) != 0 {
		chunkTarget := w.chunkSize
		if !w.bodyStart && w.prefixSize < w.chunkSize {
			// Split only the original first chunk. Subsequent chunk boundaries
			// stay aligned, preserving their compressed bytes and IO locality.
			chunkTarget -= w.prefixSize
		}
		n := chunkTarget - len(w.chunk)
		if n > len(p) {
			n = len(p)
		}
		w.chunk = append(w.chunk, p[:n]...)
		p = p[n:]
		written += n
		w.logical += uint64(n)
		if len(w.chunk) == chunkTarget {
			if err := w.flushChunk(false); err != nil {
				return written, err
			}
		}
	}
	return written, nil
}

func (w *compressedBlockStreamWriter) WriteAt(p []byte, off int64) (int, error) {
	if w == nil || w.closed || w.body == nil {
		return 0, errors.New("snapshots: compressed stream writer is closed")
	}
	if off < 0 || off > int64(len(w.first)) || int64(len(p)) > int64(len(w.first))-off {
		return 0, errors.New("snapshots: compressed stream WriteAt is outside retained prefix")
	}
	return copy(w.first[int(off):], p), nil
}

func (w *compressedBlockStreamWriter) flushChunk(final bool) error {
	if len(w.chunk) == 0 {
		return nil
	}
	if !w.bodyStart {
		w.body.uncTotal = uint64(len(w.first))
		w.bodyStart = true
	}
	if w.recordHeaders != nil {
		starts := w.recordHeadersForPage(w.body.uncTotal, len(w.chunk))
		stored, err := w.recordHeaders.encoder.encode(w.chunk, starts, w.body.enc)
		if err != nil {
			return err
		}
		if err = w.body.appendEncodedBlock(len(w.chunk), stored); err != nil {
			return err
		}
		w.chunk = w.chunk[:0]
		return nil
	}
	if w.accountDeltas != nil {
		notes := w.accountNotesForPage(w.body.uncTotal, len(w.chunk))
		stored, _, err := encodeAccountDeltaStoredPage(w.chunk, notes, w.accountDeltas.depth, w.body.enc, nil)
		if err != nil {
			return err
		}
		if err = w.body.appendEncodedBlock(len(w.chunk), stored); err != nil {
			return err
		}
		w.chunk = w.chunk[:0]
		return nil
	}
	if w.parallel == nil && w.workers > 1 && w.logical >= minParallelHistoryCompressionBytes {
		w.parallel = newOrderedCompressionPipeline(w.body, w.chunkSize, w.workers)
	}
	if w.parallel == nil {
		w.body.encoded = w.body.enc.EncodeAll(w.chunk, w.body.encoded[:0])
		comp := w.body.encoded
		if err := w.body.appendEncodedBlock(len(w.chunk), comp); err != nil {
			return err
		}
		w.chunk = w.chunk[:0]
		return nil
	}
	if err := w.parallel.Submit(w.chunk); err != nil {
		return err
	}
	w.chunk = nil
	if !final {
		chunk, err := w.parallel.Acquire()
		if err != nil {
			return err
		}
		w.chunk = chunk
	}
	return nil
}

func (w *compressedBlockStreamWriter) Finish(path string) error {
	return w.finish(path, nil)
}

func (w *compressedBlockStreamWriter) FinishWithMetadata(path string) (snapshotFileMetadata, error) {
	return w.FinishWithMetadataContext(context.Background(), path)
}

func (w *compressedBlockStreamWriter) FinishWithMetadataContext(ctx context.Context, path string) (snapshotFileMetadata, error) {
	var metadata snapshotFileMetadata
	err := w.finishContext(ctx, path, &metadata)
	return metadata, err
}

func (w *compressedBlockStreamWriter) finish(path string, metadata *snapshotFileMetadata) error {
	return w.finishContext(context.Background(), path, metadata)
}

func (w *compressedBlockStreamWriter) finishContext(ctx context.Context, path string, metadata *snapshotFileMetadata) error {
	if w == nil || w.closed || w.body == nil {
		return errors.New("snapshots: compressed stream writer is closed")
	}
	if err := contextError(ctx); err != nil {
		w.Abort()
		return err
	}
	if pipeline := w.parallel; pipeline != nil && ctx != nil {
		stop := context.AfterFunc(ctx, func() { pipeline.setError(ctx.Err()) })
		defer stop()
	}
	if err := w.flushChunk(true); err != nil {
		w.Abort()
		return err
	}
	if w.parallel != nil {
		if err := w.parallel.Close(); err != nil {
			w.Abort()
			return err
		}
		w.parallel = nil
	}
	body := w.body
	w.body = nil
	w.closed = true
	first := w.first
	w.first = nil
	releaseStateDomainChangeHistoryCompressionChunk(&w.chunk, w.chunkSize)
	defer releaseStateDomainChangeHistoryCompressionChunk(&first, w.chunkSize)
	defer releaseStateDomainChangeHistoryEncodedChunk(&body.encoded, w.chunkSize)
	if w.footer {
		return body.finishWithFooterContext(ctx, path, first, metadata)
	}
	return body.finishWithPrefixMetadataContext(ctx, path, first, metadata)
}

func (w *compressedBlockStreamWriter) Reset() error {
	if w == nil || w.closed {
		return errors.New("snapshots: compressed stream writer is closed")
	}
	w.abortBody()
	version := compressedBlockFooterVersion
	if w.accountDeltas != nil {
		version = compressedBlockAccountDeltaVersion
	}
	if w.recordHeaders != nil {
		version = compressedBlockRecordColumnsVersion
	}
	body, err := newCompressedBlockStreamBodyVersion(w.dir, w.footer, version)
	if err != nil {
		w.closed = true
		return err
	}
	body.encoded = acquireStateDomainChangeHistoryEncodedChunk(body.enc, w.chunkSize)
	w.body = body
	w.first = w.first[:0]
	if w.chunk != nil {
		w.chunk = w.chunk[:0]
	}
	w.logical = 0
	w.bodyStart = false
	if w.accountDeltas != nil {
		w.accountDeltas.values = w.accountDeltas.values[:0]
	}
	if w.recordHeaders != nil {
		s := w.recordHeaders
		s.offsets = s.offsets[:0]
		s.starts = s.starts[:0]
		s.last, s.haveLast = 0, false
	}
	return nil
}

func (w *compressedBlockStreamWriter) Abort() {
	if w == nil || w.closed {
		return
	}
	w.abortBody()
	releaseStateDomainChangeHistoryCompressionChunk(&w.first, w.chunkSize)
	releaseStateDomainChangeHistoryCompressionChunk(&w.chunk, w.chunkSize)
	w.closed = true
}

func (w *compressedBlockStreamWriter) abortBody() {
	if w.parallel != nil {
		w.parallel.Abort()
		w.parallel = nil
	}
	if w.body != nil {
		releaseStateDomainChangeHistoryEncodedChunk(&w.body.encoded, w.chunkSize)
		releaseStateDomainChangeHistoryBlockTable(&w.body.table)
		releaseStateDomainChangeHistoryWriter(&w.body.tmpWriter)
		_ = w.body.tmp.Close()
		_ = os.Remove(w.body.tmpName)
		w.body = nil
	}
}

// BlockAt returns a private copy of the decompressed block containing offset plus
// that block's uncompressed start. Used for sequential range iteration: the
// caller walks records across blocks, calling BlockAt(start+len(block)) next.
func (r *compressedBlockReader) BlockAt(offset uint64) ([]byte, uint64, error) {
	if r.cdc != nil {
		return r.cdc.BlockAt(offset)
	}
	if offset >= r.uncSize {
		return nil, 0, fmt.Errorf("snapshots: compressed-block offset %d >= size %d", offset, r.uncSize)
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	i := r.findBlock(offset)
	if i < 0 {
		return nil, 0, fmt.Errorf("snapshots: no compressed block for offset %d", offset)
	}
	blk, err := r.blockBytes(i)
	if err != nil {
		return nil, 0, err
	}
	return append([]byte(nil), blk...), r.table[i].uncompressedStart, nil
}
