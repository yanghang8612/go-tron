import pathlib,json,subprocess,hashlib,zipfile,datetime,os,base64
P=pathlib.Path('/data/gtron/history-columns-encoder-reuse-20261026-01');S=P/'candidate-source'
status=json.loads((P/'profile-status.json').read_text());assert status['complete'] and status['source_unchanged']
env=dict(os.environ,PATH='/data/go/bin:'+os.environ.get('PATH',''),GOCACHE='/root/.cache/go-build',GOPATH='/root/go',GOTOOLCHAIN='local')
for fmt in ['2','5']:
 paths=sorted((P/'cpu-profile-comparison').glob('*-profile-format-'+fmt+'.pprof'));assert len(paths)==3
 q=P/('cpu-format-'+fmt+'-cum.log')
 assert not q.exists()
 with q.open('wb')as f:subprocess.run(['/data/go/bin/go','tool','pprof','-top','-cum','-nodecount=40',str(P/'reuse-profile.test')]+[str(p)for p in paths],cwd=str(S),env=env,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=120)
items={n:(P/n).read_bytes()for n in ['profile-status.json','profile-dispatch-receipt.json','profile-payload.zip','cpu-profile-overlay.json','run-profile.py','profile_publish_overlay_test.go','offline_column_reuse_profile_test.go','cpu-profile-build.log','cpu-profile-real-pairs.log','cpu-format-2-top.log','cpu-format-5-top.log','cpu-format-2-cum.log','cpu-format-5-cum.log']}
for profile in status['profiles']:
 n=profile['path'];b=(P/n).read_bytes();assert len(b)==profile['bytes'] and hashlib.sha256(b).hexdigest()==profile['sha256'];items[n]=b
items['evidence-manifest.json']=(json.dumps({n:hashlib.sha256(b).hexdigest()for n,b in items.items()},sort_keys=True,indent=2)+'\n').encode()
q=pathlib.Path('/tmp/gtron-columns-encoder-reuse-cpu-20261026-01.zip');assert not q.exists()
with zipfile.ZipFile(str(q),'w',zipfile.ZIP_DEFLATED)as z:
 for name,b in sorted(items.items()):z.writestr(name,b)
with q.open('rb')as f:os.fsync(f.fileno())
data=q.read_bytes();st=q.stat();file_sha=hashlib.sha256(data).hexdigest()
for index,offset in enumerate(range(0,len(data),4096)):
 b=data[offset:offset+4096];v={'name':q.name,'index':index,'offset':offset,'bytes':len(b),'file_bytes':len(data),'file_sha256':file_sha,'device':str(st.st_dev),'inode':str(st.st_ino),'mtime_ns':str(st.st_mtime_ns),'sha256':hashlib.sha256(b).hexdigest(),'base64':base64.b64encode(b).decode()};part=P/('cpu-zip-part-%03d.json'%index);assert not part.exists();blob=(json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode();assert len(blob)<6144;part.write_bytes(blob)
v={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'path':str(q),'bytes':len(data),'sha256':file_sha,'members':len(items),'parts':(len(data)+4095)//4096,'production_mutations':False}
(P/'cpu-archive-receipt.json').write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
