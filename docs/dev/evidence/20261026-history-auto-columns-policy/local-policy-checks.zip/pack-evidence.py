import datetime
import hashlib
import json
import pathlib
import zipfile

ROOT = pathlib.Path('/Users/asuka/.codex/worktrees/history-auto-columns-policy/go-tron')
FROZEN = pathlib.Path('/Users/asuka/.codex/worktrees/cold-throughput-followup/go-tron')
P = ROOT / 'build/benchmarks/20261026-history-auto-columns-policy'
OUT = ROOT / 'docs/dev/evidence/20261026-history-auto-columns-policy'
OUT.mkdir(parents=True, exist_ok=True)
status = json.loads((P/'local-status.json').read_bytes())
assert status['complete'] and all(c['returncode'] == 0 for c in status['checks'])
new_raw = (P/'source-inventory.json').read_bytes()
new = json.loads(new_raw)
with zipfile.ZipFile(FROZEN/'docs/dev/evidence/20261026-history-columns-container/local-source-and-harness.zip') as z:
    old_raw = z.read('source-inventory.json')
old = json.loads(old_raw)
assert len(old) == 2145 and len(new) == 2146 and set(old) < set(new)
changed = sorted(n for n, h in new.items() if old.get(n) != h)
assert len(changed) == 14
sha = lambda b: hashlib.sha256(b).hexdigest()
assert all(sha((ROOT/n).read_bytes()) == h for n, h in new.items())
mismatch = [n for n, h in old.items() if sha((FROZEN/n).read_bytes()) != h]
assert not mismatch
files = {'baseline-source-inventory.json': old_raw}
for n in ['local-status.json', 'source-inventory.json', 'tracked-source.patch', 'focused.log', 'packages.log',
          'race.log', 'vet.log', 'sapling-build.log', 'binary-build-info.txt', 'run-checks.py', 'pack-evidence.py']:
    files[n] = (P/n).read_bytes()
for path in sorted((P/'first-revision').iterdir()):
    assert path.is_file()
    files['first-revision/'+path.name] = path.read_bytes()
for n in changed:
    files['source/'+n] = (ROOT/n).read_bytes()
old_bench = FROZEN/'build/benchmarks/20261026-history-columns-container'
for n in ['server-progress-live-14.json', 'server-progress-live-14.json.transport.json']:
    files['frozen-experiment/'+n] = (old_bench/n).read_bytes()
scope = dict(local_complete=True, native_policy_complete=False, production_mutations=False,
             base_commit=status['base_commit'], source_files=len(new), changed_source_files=changed,
             baseline_source_inventory_sha256=sha(old_raw), source_inventory_sha256=sha(new_raw),
             frozen_source_check=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                                      files=len(old), mismatches=mismatch),
             scope='Local opt-in writer policy only. The separate frozen V5 fixed-copy experiment is still running; its old-binary results do not attest this policy.')
files['scope.json'] = (json.dumps(scope, sort_keys=True, indent=2)+'\n').encode()
files['evidence-manifest.json'] = (json.dumps({n: sha(b) for n,b in files.items()}, sort_keys=True, indent=2)+'\n').encode()
out = OUT/'local-policy-checks.zip'
assert not out.exists()
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for n, b in sorted(files.items()):
        info = zipfile.ZipInfo(n, date_time=(2026,10,26,0,0,0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        z.writestr(info,b)
print(json.dumps(dict(bytes=out.stat().st_size, sha256=sha(out.read_bytes()), members=len(files)), indent=2))
