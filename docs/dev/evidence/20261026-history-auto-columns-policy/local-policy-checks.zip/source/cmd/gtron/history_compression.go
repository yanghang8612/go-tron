package main

import (
	"fmt"
	"os"

	"github.com/urfave/cli/v2"
)

var historyBlockDedupFlag = &cli.BoolFlag{Name: "history.block-dedup", Usage: "Deduplicate repeated large values within each hot history block pack (adds foreground CPU; benchmark representative replay before enabling)"}

var historyCrossBlockDedupFlag = &cli.BoolFlag{Name: "history.cross-block-dedup", Usage: "Share persistent chunks across hot history blocks in fixed buckets; requires a reader-compatible rollback binary"}

var historyCompressionFormatFlag = &cli.StringFlag{
	Name:    "history.compression-format",
	Value:   "auto",
	EnvVars: []string{"GTRON_HISTORY_COMPRESSION_FORMAT"},
	Usage:   "Cold history container: auto selects CDC for repeated large values; auto-columns keeps that CDC policy and uses 128 KiB record columns for ordinary V6 builds/merges (experimental); 1=legacy, 2=streaming footer, 3=CDC for every history segment, 4=bounded account delta pages (experimental), 5=128 KiB record columns (experimental)",
}

// Configure once before opening stores/starting any node lifecycle. Individual
// builders select an explicit per-build format; they never temporarily mutate
// the environment around a concurrent build or merge.
func applyRuntimeHistoryCompression(ctx *cli.Context) (string, error) {
	format := ctx.String(historyCompressionFormatFlag.Name)
	if format == "" {
		format = "auto"
	}
	switch format {
	case "auto", "auto-columns", "1", "2", "3", "4", "5":
	default:
		return "", fmt.Errorf("invalid history.compression-format %q (want auto, auto-columns, 1, 2, 3, 4 or 5)", format)
	}
	if err := os.Setenv("GTRON_HISTORY_COMPRESSION_FORMAT", format); err != nil {
		return "", err
	}
	return format, nil
}
