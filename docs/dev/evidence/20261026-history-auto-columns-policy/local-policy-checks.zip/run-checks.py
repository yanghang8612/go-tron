import datetime
import hashlib
import json
import os
import pathlib
import subprocess
import time
import traceback

ROOT = pathlib.Path('/Users/asuka/.codex/worktrees/history-auto-columns-policy/go-tron')
P = ROOT / 'build/benchmarks/20261026-history-auto-columns-policy'
state = {'complete': False, 'production_mutations': False, 'checks': []}


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(4 << 20), b''):
            h.update(b)
    return h.hexdigest()


def inventory():
    names = subprocess.check_output(['rg', '--files', '-g', '*.go', '-g', 'go.mod', '-g', 'go.sum'], cwd=ROOT, text=True).splitlines()
    return {n: sha(ROOT / n) for n in sorted(names)}


def save():
    state['utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    temp = P / 'local-status.json.tmp'
    temp.write_text(json.dumps(state, sort_keys=True, indent=2)+'\n')
    temp.replace(P / 'local-status.json')


try:
    before = inventory()
    (P / 'source-inventory.json').write_text(json.dumps(before, sort_keys=True, indent=2)+'\n')
    state['source_files'] = len(before)
    state['source_inventory_sha256'] = sha(P / 'source-inventory.json')
    state['base_commit'] = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    patch = subprocess.check_output(['git', 'diff', '--binary'], cwd=ROOT)
    (P / 'tracked-source.patch').write_bytes(patch)
    state['tracked_patch_sha256'] = sha(P / 'tracked-source.patch')
    lib = ROOT / 'third_party/librustzcash/target/release/librustzcash.a'
    state['sapling_library_sha256'] = sha(lib)
    env = dict(os.environ, CGO_ENABLED='1', GOMAXPROCS='2', GOMEMLIMIT='3GiB')
    packages = ['./core/rawdb', './core/state', './core/state/snapshots', './core', './cmd/gtron']
    checks = [
        ('focused', ['go', 'test', './core/state/snapshots', './cmd/gtron', '-run', 'TestAutoColumns|TestCDCAutoBuildAndMergeSelection|TestRuntimeHistoryCompressionPrecedence|TestDBHistorySharedPipelineFullTrioByteEquivalence|TestDBHistoryColdBenchmarkCompleteModesAndReadOnly|TestDBHistoryReference', '-count=1', '-v', '-timeout=300s'], 650),
        ('packages', ['go', 'test', '-p', '1'] + packages + ['-count=1', '-timeout=900s'], 2400),
        ('race', ['go', 'test', '-race', './core/state/snapshots', './cmd/gtron', '-run', 'TestAutoColumns|TestCDCAutoBuildAndMergeSelection|TestRuntimeHistoryCompressionPrecedence', '-count=1', '-timeout=300s'], 650),
        ('vet', ['go', 'vet'] + packages, 600),
        ('sapling-build', ['make', 'gtron'], 900),
    ]
    for label, args, timeout in checks:
        state['phase'] = label
        save()
        started = time.monotonic()
        with (P / (label+'.log')).open('wb') as log:
            proc = subprocess.run(args, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=timeout)
        state['checks'].append({'label': label, 'args': args, 'returncode': proc.returncode, 'seconds': time.monotonic()-started, 'log_sha256': sha(P / (label+'.log'))})
        save()
        assert proc.returncode == 0, label+' failed; see retained log'
    assert inventory() == before, 'source changed while checks ran'
    assert sha(lib) == state['sapling_library_sha256'], 'Sapling library changed'
    state['binary_sha256'] = sha(ROOT / 'build/bin/gtron')
    (P / 'binary-build-info.txt').write_bytes(subprocess.check_output(['go', 'version', '-m', str(ROOT / 'build/bin/gtron')], cwd=ROOT, env=env))
    state.update(complete=True, phase='complete')
    save()
except BaseException as error:
    state.update(phase='failed', error=repr(error), traceback=traceback.format_exc())
    save()
    raise
