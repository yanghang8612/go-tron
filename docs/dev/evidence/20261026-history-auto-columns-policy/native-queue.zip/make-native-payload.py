import ast
import hashlib
import io
import json
import pathlib
import subprocess
import zipfile

R = pathlib.Path('/Users/asuka/.codex/worktrees/history-auto-columns-policy/go-tron')
P = R/'build/benchmarks/20261026-history-auto-columns-policy'
old_zip = R/'docs/dev/evidence/20261026-history-auto-columns-policy/local-policy-checks.zip'
with zipfile.ZipFile(old_zip) as z:
    base_raw = z.read('baseline-source-inventory.json')
base = json.loads(base_raw)
raw = (P/'source-inventory.json').read_bytes()
current = json.loads(raw)
changed = sorted(n for n, h in current.items() if base.get(n) != h)
assert len(base) == 2145 and len(current) == 2146 and len(changed) == 14
sha = lambda b: hashlib.sha256(b).hexdigest()
assert all(sha((R/n).read_bytes()) == h for n,h in current.items())
runner = (P/'prepare-native.py').read_bytes()
ast.parse(runner, feature_version=(3,6))
commit = subprocess.check_output(['git','rev-parse','4d69f072'],cwd=R,text=True).strip()
assert commit.startswith('4d69f072')
identity = dict(source_commit=commit, source_inventory_sha256=sha(raw), base_inventory_sha256=sha(base_raw),
                changed_source_files=changed, target_source_files=len(current), native_gate='wait for old acceptance and publication',
                default_policy='auto', opt_in_policy='auto-columns', production_mutations=False)
items = {'source/'+n:(R/n).read_bytes() for n in changed}
items.update({'base-inventory.json':base_raw, 'source-inventory.json':raw, 'prepare-native.py':runner,
              'policy-identity.json':(json.dumps(identity,sort_keys=True,indent=2)+'\n').encode()})
items['payload-manifest.json']=(json.dumps({n:sha(b) for n,b in items.items()},sort_keys=True,indent=2)+'\n').encode()
out=io.BytesIO()
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,b in sorted(items.items()):
        i=zipfile.ZipInfo(n,date_time=(2026,10,26,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16;z.writestr(i,b)
data=out.getvalue();path=P/'native-source-payload.zip';assert not path.exists();path.write_bytes(data)
chunks=[]
for index,start in enumerate(range(0,len(data),20000)):
    value=data[start:start+20000];name='native-payload-part-{:03d}'.format(index);(P/name).write_bytes(value)
    chunks.append(dict(index=index,bytes=len(value),sha256=sha(value)))
receipt=dict(bytes=len(data),sha256=sha(data),members=len(items),source_files=len(current),changed_source_files=len(changed),
             source_commit=commit,chunk_bytes=20000,chunks=chunks)
(P/'native-upload-plan.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
