package snapshots

import (
	"context"
	"crypto/sha256"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"reflect"
	"runtime"
	"sort"
	"syscall"
	"testing"
	"time"
)

type columnPublishPair struct {
	Index                                                                  int
	FromTxNum, ToTxNum, Steps, InputBytes, InputLogicalBytes, InputRecords uint64
	Refs                                                                   []SegmentRef
}
type columnPublishRow struct {
	Pair                         columnPublishPair
	Format                       string
	Label                        string
	Timed                        bool
	Seconds, CPUSeconds          float64
	AllocBytes, GCs              uint64
	OutputRefs                   []SegmentRef
	OutputBytes, OutputAllocated uint64
	CanonicalAndCompanionSHA     map[string]string
	ColumnKeyModes               [3]uint64
	PlainPages                   uint64
	LoadStart, LoadEnd           string
	IOStart, IOEnd               string
}

func columnPublishFileSHA(path string) (string, error) {
	f, e := os.Open(path)
	if e != nil {
		return "", e
	}
	defer f.Close()
	h := sha256.New()
	_, e = io.CopyBuffer(h, f, make([]byte, 64<<10))
	return fmt.Sprintf("%x", h.Sum(nil)), e
}
func columnPublishCPU(r syscall.Rusage) float64 {
	return float64(r.Utime.Sec+r.Stime.Sec) + float64(r.Utime.Usec+r.Stime.Usec)/1e6
}
func runColumnPublish(t *testing.T, base, root string, pair columnPublishPair, format, label string, timed bool) (row columnPublishRow) {
	t.Helper()
	t.Setenv("GTRON_HISTORY_COMPRESSION_FORMAT", format)
	dir := filepath.Join(root, label)
	if e := os.Mkdir(dir, 0700); e != nil {
		t.Fatal(e)
	}
	row = columnPublishRow{Pair: pair, Format: format, Label: label, Timed: timed, CanonicalAndCompanionSHA: map[string]string{}}
	for _, r := range pair.Refs {
		a, b := filepath.Join(base, r.Path), filepath.Join(dir, r.Path)
		if e := os.MkdirAll(filepath.Dir(b), 0700); e != nil {
			t.Fatal(e)
		}
		if e := os.Link(a, b); e != nil {
			t.Fatal(e)
		}
	}
	if e := PublishManifest(dir, NewManifest(pair.FromTxNum, pair.ToTxNum, pair.Refs)); e != nil {
		t.Fatal(e)
	}
	runtime.GC()
	var m0, m1 runtime.MemStats
	runtime.ReadMemStats(&m0)
	var u0, u1 syscall.Rusage
	syscall.Getrusage(syscall.RUSAGE_SELF, &u0)
	a, _ := os.ReadFile("/proc/loadavg")
	row.LoadStart = string(a)
	a, _ = os.ReadFile("/proc/self/io")
	row.IOStart = string(a)
	start := time.Now()
	result, e := CompactHistoryDomainContext(context.Background(), dir, SegmentDatasetStateDomainChange, CompactionConfig{MaxSteps: pair.Steps, MinSteps: pair.Steps, DeleteObsolete: false})
	row.Seconds = time.Since(start).Seconds()
	syscall.Getrusage(syscall.RUSAGE_SELF, &u1)
	runtime.ReadMemStats(&m1)
	row.CPUSeconds = columnPublishCPU(u1) - columnPublishCPU(u0)
	row.AllocBytes = m1.TotalAlloc - m0.TotalAlloc
	row.GCs = uint64(m1.NumGC - m0.NumGC)
	a, _ = os.ReadFile("/proc/loadavg")
	row.LoadEnd = string(a)
	a, _ = os.ReadFile("/proc/self/io")
	row.IOEnd = string(a)
	if e != nil || !result.Merged || result.SegmentsMerged != 2 || result.FromTxNum != pair.FromTxNum || result.ToTxNum != pair.ToTxNum {
		t.Fatalf("publish %s: %+v %v", label, result, e)
	}
	row.OutputRefs = result.Segments
	unique := map[[2]uint64]bool{}
	for _, r := range result.Segments {
		path := filepath.Join(dir, r.Path)
		st, e := os.Stat(path)
		if e != nil {
			t.Fatal(e)
		}
		if uint64(st.Size()) != r.Size {
			t.Fatal("output size")
		}
		sum, e := columnPublishFileSHA(path)
		if e != nil || "sha256:"+sum != r.Checksum {
			t.Fatalf("output SHA %v", e)
		}
		row.OutputBytes += r.Size
		id := [2]uint64{uint64(st.Sys().(*syscall.Stat_t).Dev), st.Sys().(*syscall.Stat_t).Ino}
		if !unique[id] {
			row.OutputAllocated += uint64(st.Sys().(*syscall.Stat_t).Blocks) * 512
			unique[id] = true
		}
		switch r.Kind {
		case SegmentHistory:
			reader, e := openCompressedBlockReaderWithCacheLimit(path, 1)
			if e != nil {
				t.Fatal(e)
			}
			if reader.recordColumns != (format == "5") {
				t.Fatal("writer format did not follow explicit setting")
			}
			h := sha256.New()
			for i := range reader.table {
				stored, n, readErr := reader.readCompressedBlock(i)
				if readErr != nil {
					e = readErr
					break
				}
				raw, decodeErr := reader.decodeBlock(i, stored, n)
				if decodeErr != nil {
					e = decodeErr
					break
				}
				h.Write(raw)
				if reader.recordColumns && stored[0] == 1 {
					if len(reader.columnScratch) < historyRecordColumnHeader {
						t.Fatal("missing transformed header")
					}
					mode := binary.BigEndian.Uint32(reader.columnScratch[28:32])
					if mode > 2 {
						t.Fatal("invalid selected mode")
					}
					row.ColumnKeyModes[mode]++
				} else {
					row.PlainPages++
				}
			}
			ce := reader.Close()
			if e != nil || ce != nil {
				t.Fatalf("canonical output %v %v", e, ce)
			}
			row.CanonicalAndCompanionSHA[string(r.Kind)] = fmt.Sprintf("%x", h.Sum(nil))
		case SegmentInverted, SegmentAccessor:
			row.CanonicalAndCompanionSHA[string(r.Kind)] = sum
		}
	}
	if len(row.CanonicalAndCompanionSHA) != 3 {
		t.Fatalf("missing merged trio: %+v", row.OutputRefs)
	}
	if _, e = VerifyLoadedManifestFiles(dir, NewManifest(pair.FromTxNum, pair.ToTxNum, result.Segments), VerifyManifestOptions{RequireRegistered: true, RequireChecksums: true}); e != nil {
		t.Fatal(e)
	}
	for _, r := range pair.Refs {
		sum, e := columnPublishFileSHA(filepath.Join(base, r.Path))
		if e != nil || "sha256:"+sum != r.Checksum {
			t.Fatalf("source modified %v", e)
		}
	}
	return row
}
func TestRecordColumnPublishFixture(t *testing.T) {
	t.Setenv("GTRON_HISTORY_COMPACTION_SOURCE_WORKERS", "2")
	procs := runtime.GOMAXPROCS(2)
	defer runtime.GOMAXPROCS(procs)
	dir := t.TempDir()
	refs := writeV6StateDomainHistorySegmentForTest(t, dir, 1, 2048, v6StreamChanges(1, 2048, 1, 80))
	refs = append(refs, writeV6StateDomainHistorySegmentForTest(t, dir, 2049, 4096, v6StreamChanges(2049, 2048, 1, 80))...)
	compressV6StreamFixture(t, dir, refs, historyCompressChunkSize)
	p := columnPublishPair{FromTxNum: 1, ToTxNum: 4096, Steps: 2, Refs: refs}
	root := t.TempDir()
	a := runColumnPublish(t, dir, root, p, "2", "plain-fixture", false)
	b := runColumnPublish(t, dir, root, p, "5", "column-fixture", false)
	if !reflect.DeepEqual(a.CanonicalAndCompanionSHA, b.CanonicalAndCompanionSHA) {
		t.Fatal("publish canonical/companion difference")
	}
}
func TestOfflineRecordColumnPublish(t *testing.T) {
	root := os.Getenv("GTRON_COLUMN_CONTAINER_ROOT")
	if root == "" {
		t.Skip("isolated fixed capture")
	}
	if runtime.GOMAXPROCS(0) != 2 {
		t.Fatal("fixed two-core process budget required")
	}
	t.Setenv("GTRON_HISTORY_COMPACTION_SOURCE_WORKERS", "2")
	if !CompressHistorySegments {
		t.Fatal("production compression disabled")
	}
	statusPath := filepath.Join(root, "acceptance-status.json")
	b, e := os.ReadFile(statusPath)
	if e != nil {
		t.Fatal(e)
	}
	var gate struct{ Complete bool }
	if e = json.Unmarshal(b, &gate); e != nil || !gate.Complete {
		t.Fatal("full HTTP/census jobs must finish before timed publishing")
	}
	base := filepath.Join(root, "baseline-input/state-snapshots")
	m, e := loadProductionManifestReadOnly(base)
	if e != nil {
		t.Fatal(e)
	}
	cfg, _ := DefaultDomainRegistry().Dataset(SegmentDatasetStateDomainChange)
	all := historyCompactionCandidates(m, cfg)
	if len(all) != 4609 {
		t.Fatalf("fixed history count %d", len(all))
	}
	valid := map[int]columnPublishPair{}
	for i := 0; i+1 < len(all); i++ {
		a, z := all[i], all[i+1]
		steps := a.history.effectiveAggregationSteps()
		if steps == 0 || steps != z.history.effectiveAggregationSteps() || steps&(steps-1) != 0 || !historySegmentsAreContiguous(a.history, z.history) {
			continue
		}
		ca, e := readHistoryCompactionInputCost(context.Background(), base, a)
		if e != nil {
			t.Fatal(e)
		}
		cz, e := readHistoryCompactionInputCost(context.Background(), base, z)
		if e != nil {
			t.Fatal(e)
		}
		p := columnPublishPair{Index: i, FromTxNum: a.history.FromTxNum, ToTxNum: z.history.ToTxNum, Steps: 2 * steps, InputBytes: ca.bytes + cz.bytes, InputLogicalBytes: ca.logicalBytes + cz.logicalBytes, InputRecords: ca.records + cz.records}
		if p.InputBytes > 96<<20 || p.InputLogicalBytes > 256<<20 || p.InputRecords > 1500000 || p.InputRecords < 10000 {
			continue
		}
		p.Refs = append(p.Refs, a.history)
		p.Refs = append(p.Refs, a.companions...)
		p.Refs = append(p.Refs, z.history)
		p.Refs = append(p.Refs, z.companions...)
		valid[i] = p
	}
	if len(valid) < 3 {
		t.Fatalf("too few bounded real pairs %d", len(valid))
	}
	var indexes []int
	for i := range valid {
		indexes = append(indexes, i)
	}
	sort.Ints(indexes)
	used := map[int]bool{}
	var pairs []columnPublishPair
	for _, target := range []int{len(all) / 10, len(all) / 2, len(all) * 9 / 10} {
		best := -1
		distance := len(all) + 1
		for _, i := range indexes {
			d := i - target
			if d < 0 {
				d = -d
			}
			if !used[i] && d < distance {
				best, distance = i, d
			}
		}
		if best < 0 {
			t.Fatal("selection failed")
		}
		used[best] = true
		pairs = append(pairs, valid[best])
	}
	outRoot := filepath.Join(root, "publish-comparison")
	if e = os.Mkdir(outRoot, 0700); e != nil {
		t.Fatal(e)
	}
	plan, _ := json.MarshalIndent(map[string]any{"source_manifest": m, "selected": pairs, "eligible_pairs": len(valid), "scope": "Actual production CompactHistoryDomain merge, index construction, fsync and manifest publication; input preparation and independent validation excluded from timing. Same two immutable source trios per pair, explicit physical formats 2 and 5, GOMAXPROCS=2 and source workers=2. Warm-cache publishing only; not end-to-end mainnet synchronization speed."}, "", "  ")
	if e = os.WriteFile(filepath.Join(outRoot, "plan.json"), plan, 0600); e != nil {
		t.Fatal(e)
	}
	f, e := os.OpenFile(filepath.Join(outRoot, "samples.jsonl"), os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if e != nil {
		t.Fatal(e)
	}
	defer f.Close()
	started := time.Now()
	var rows []columnPublishRow
	save := func(complete bool) {
		data, _ := json.MarshalIndent(map[string]any{"complete": complete, "production_mutations": false, "samples": len(rows), "selected_pairs": len(pairs), "seconds": time.Since(started).Seconds()}, "", "  ")
		path := filepath.Join(root, "publish-status.json")
		if e = os.WriteFile(path+".tmp", data, 0600); e != nil {
			t.Fatal(e)
		}
		if e = os.Rename(path+".tmp", path); e != nil {
			t.Fatal(e)
		}
	}
	save(false)
	for group, p := range pairs {
		var expected map[string]string
		orders := [][]string{{"2", "5"}, {"2", "5"}, {"5", "2"}, {"5", "2"}, {"2", "5"}}
		for block, order := range orders {
			for _, format := range order {
				label := fmt.Sprintf("pair-%d-round-%d-format-%s", group, block, format)
				row := runColumnPublish(t, base, outRoot, p, format, label, block > 0)
				if expected == nil {
					expected = row.CanonicalAndCompanionSHA
				} else if !reflect.DeepEqual(expected, row.CanonicalAndCompanionSHA) {
					t.Fatal("canonical merged bytes or companions differ")
				}
				if e = json.NewEncoder(f).Encode(row); e != nil {
					t.Fatal(e)
				}
				if e = f.Sync(); e != nil {
					t.Fatal(e)
				}
				rows = append(rows, row)
				save(false)
			}
		}
	}
	save(true)
}
