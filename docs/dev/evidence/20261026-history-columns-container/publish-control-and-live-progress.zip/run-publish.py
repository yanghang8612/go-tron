import pathlib,os,json,subprocess,time,datetime,traceback,hashlib,collections,statistics
P=pathlib.Path('/data/gtron/history-record-columns-container-20261026-01');S=P/'candidate-source';state={'complete':False,'production_mutations':False,'scope':'Actual production history compaction, index construction, fsync and manifest publication; warm-cache fixed source trios, not mainnet synchronization speed'}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(4<<20),b''):h.update(b)
 return h.hexdigest()
def save():
 state['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();t=P/'publish-driver-status.json.tmp';t.write_text(json.dumps(state,sort_keys=True,indent=2));os.replace(str(t),str(P/'publish-driver-status.json'))
def identity():
 fields=dict(l.split('=',1)for l in subprocess.check_output(['systemctl','show','gtron','-p','MainPID','-p','ActiveState'],universal_newlines=True).splitlines());pid=int(fields['MainPID']);fields['binary_sha256']=sha(pathlib.Path('/proc/%d/exe'%pid))if pid else None;return fields
def check_source():
 for name in ['source-inventory.json','inherited-harness-inventory.json']:
  inv=json.loads((P/name).read_text());assert all(sha(S/n)==h for n,h in inv.items()),'source/harness drift'
 for n in ['offline_record_column_capture_test.go','offline_record_column_parallel_test.go','offline_record_column_controls_test.go']:
  assert sha(S/'core/state/snapshots'/n)==sha(P/n),'candidate harness drift'
def run(label,argv,env,timeout):
 state['phase']=label;save();start=time.monotonic()
 with(P/(label+'.log')).open('wb')as f:subprocess.run(argv,cwd=str(S),env=env,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=timeout)
 state.setdefault('checks',[]).append(dict(label=label,seconds=time.monotonic()-start,returncode=0));save()
try:
 state['phase']='wait-final-http-and-census';save();start=time.monotonic()
 while True:
  p=P/'acceptance-status.json';gate=json.loads(p.read_text())if p.exists()else{}
  if gate.get('phase')=='failed':raise RuntimeError('preceding acceptance failed: '+str(gate.get('error')))
  if gate.get('complete'):break
  if time.monotonic()-start>129600:raise TimeoutError('bounded acceptance wait')
  time.sleep(15)
 check_source();state['before_identity']=identity();state['acceptance_receipt_sha256']=sha(P/'acceptance-status.json');save()
 name='offline_record_column_publish_test.go';dst=S/'core/state/snapshots'/name;assert not dst.exists();dst.write_bytes((P/name).read_bytes());state['publish_harness_sha256']=sha(dst)
 env=dict(os.environ,PATH='/data/go/bin:'+os.environ.get('PATH',''),GOCACHE='/root/.cache/go-build',GOPATH='/root/go',GOTOOLCHAIN='local',CGO_ENABLED='1',GOMAXPROCS='2',GOMEMLIMIT='3GiB',GTRON_COLUMN_CONTAINER_ROOT=str(P));env.pop('GTRON_ACCOUNT_DELTA_ROOT',None);env.pop('GTRON_FIXED_INPUT',None)
 run('publish-build',['/data/go/bin/go','test','-c','./core/state/snapshots','-o',str(P/'columns-publish.test')],env,600);state['publish_binary_sha256']=sha(P/'columns-publish.test')
 run('publish-fixture',[str(P/'columns-publish.test'),'-test.run=^TestRecordColumnPublishFixture$','-test.v','-test.timeout=180s'],env,240)
 run('publish-real-pairs',[str(P/'columns-publish.test'),'-test.run=^TestOfflineRecordColumnPublish$','-test.v','-test.timeout=2h'],env,7250)
 status=json.loads((P/'publish-status.json').read_text());assert status['complete'];rows=[json.loads(s)for s in(P/'publish-comparison/samples.jsonl').read_text().splitlines()];assert len(rows)==30 and sum(r['Timed']for r in rows)==24
 groups=collections.defaultdict(list)
 for r in rows:
  if r['Timed']:groups[(r['Pair']['Index'],r['Format'])].append(r)
 summary=[]
 for (pair,format),items in sorted(groups.items()):
  assert len(items)==4;wall=[r['Seconds']for r in items];cpu=[r['CPUSeconds']for r in items];logical=items[0]['Pair']['InputLogicalBytes'];records=items[0]['Pair']['InputRecords'];assert all(r['CanonicalAndCompanionSHA']==items[0]['CanonicalAndCompanionSHA']for r in items);summary.append(dict(pair_index=pair,format=format,n=len(items),median_seconds=statistics.median(wall),min_seconds=min(wall),max_seconds=max(wall),median_cpu_seconds=statistics.median(cpu),input_logical_bytes=logical,input_records=records,logical_bytes_per_second=logical/statistics.median(wall),records_per_second=records/statistics.median(wall),output_bytes=items[0]['OutputBytes'],output_allocated=items[0]['OutputAllocated'],canonical_and_companion_sha=items[0]['CanonicalAndCompanionSHA'],column_key_modes=items[0]['ColumnKeyModes'],plain_pages=items[0]['PlainPages']))
 for pair in {r['pair_index']for r in summary}:
  arms=[r for r in summary if r['pair_index']==pair];assert len(arms)==2 and arms[0]['canonical_and_companion_sha']==arms[1]['canonical_and_companion_sha']
 (P/'publish-comparison/summary.json').write_text(json.dumps(summary,sort_keys=True,indent=2));check_source();assert sha(dst)==state['publish_harness_sha256'];state['after_identity']=identity();state['identity_changed']=state['before_identity']!=state['after_identity'];assert not state['identity_changed'],'production identity changed during publish timing';state.update(complete=True,phase='complete',timed_samples=24,total_samples=30);save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
