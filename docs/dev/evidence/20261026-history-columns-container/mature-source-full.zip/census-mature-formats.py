#!/usr/bin/env python3
"""Header-only census of the already pinned 25M--35M immutable cohort."""
import collections
import datetime
import hashlib
import json
import os
import pathlib

P = pathlib.Path('/data/gtron/history-record-columns-container-20261026-01')
OLD = pathlib.Path('/data/gtron/history-tx-runs-20261025-01')
SOURCE = OLD / 'census-input'
EXPECTED_PLAN = '108728f335f23009784a9af2931e70ba9176f28bd22bcc92b2130d8bead66b6c'


def main():
    status = json.loads((P / 'acceptance-status.json').read_text())
    assert status['phase'] == 'wait-conversion-and-native', 'Do not overlap HTTP or final census'
    raw = (OLD / 'census-plan.json').read_bytes()
    assert hashlib.sha256(raw).hexdigest() == EXPECTED_PLAN
    plan = json.loads(raw)
    assert len(plan) == 8651
    expected = {r['history_ref']['path'] for r in plan}
    actual = {str(f.relative_to(SOURCE)) for f in SOURCE.rglob('*.seg')}
    assert actual == expected and len(expected) == len(plan)
    groups = collections.defaultdict(lambda: dict(files=0, physical_bytes=0, records=0, logical_bytes=0))
    windows = collections.defaultdict(lambda: collections.defaultdict(lambda: dict(files=0, physical_bytes=0)))
    output = P / 'mature-source-formats-rows.jsonl'
    with output.open('xb') as out:
        for row in plan:
            ref = row['history_ref']
            path = SOURCE / ref['path']
            before = path.stat()
            assert before.st_size == ref['size']
            assert os.path.commonpath([str(SOURCE.resolve()), str(path.resolve())]) == str(SOURCE.resolve())
            with path.open('rb') as f:
                header = f.read(48)
            after = path.stat()
            assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
            assert len(header) == 48 and header[:8] == b'gtcblk01'
            version = str(int.from_bytes(header[8:12], 'big'))
            group = groups[version]
            group['files'] += 1
            group['physical_bytes'] += ref['size']
            group['records'] += row['records']
            group['logical_bytes'] += row['logical_bytes']
            window = ('25M-30M' if row['first_block'] >= 25000000 and row['last_block'] < 30000000 else
                      '30M-35M' if row['first_block'] >= 30000000 and row['last_block'] <= 35000000 else 'boundary')
            windows[window][version]['files'] += 1
            windows[window][version]['physical_bytes'] += ref['size']
            proof = dict(path=ref['path'], physical_version=int(version), header_hex=header.hex(),
                         bytes=after.st_size, inode=after.st_ino, device=after.st_dev, mtime_ns=after.st_mtime_ns,
                         first_block=row['first_block'], last_block=row['last_block'])
            out.write((json.dumps(proof, sort_keys=True) + '\n').encode())
        out.flush()
        os.fsync(out.fileno())
    rows = output.read_bytes()
    result = dict(complete=True, utc=datetime.datetime.utcnow().isoformat()+'Z',
                  production_mutations=False, header_only=True, physical_sha_recomputed=False,
                  source_plan_sha256=EXPECTED_PLAN, source_files=len(plan),
                  source_physical_bytes=sum(r['history_ref']['size'] for r in plan),
                  source_directory=str(SOURCE), groups=dict(groups), windows={k: dict(v) for k, v in windows.items()},
                  rows_sha256=hashlib.sha256(rows).hexdigest(), rows_bytes=len(rows),
                  scope='All immutable pinned 25M--35M overlapping files; header/size stability only. Full physical SHA and logical census belong to the prior frozen census, not this header-only pass.')
    (P / 'mature-source-formats-01.json').write_text(json.dumps(result, sort_keys=True, indent=2))
    print('MATURE_FORMATS_READY', len(plan))


if __name__ == '__main__':
    main()
