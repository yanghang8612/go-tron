#!/usr/bin/env python3
"""Seal only this task's completed header census for inbound transfer."""
import hashlib
import json
import pathlib
import zipfile

P = pathlib.Path('/data/gtron/history-record-columns-container-20261026-01')
names = ['census-mature-formats.py', 'archive-mature-formats.py',
         'mature-source-formats-01.json', 'mature-source-formats-rows.jsonl',
         'mature-source-locations-01.json', 'progress-live-08.json']
files = {n: (P / n).read_bytes() for n in names}
summary = json.loads(files['mature-source-formats-01.json'])
assert summary['complete'] and summary['header_only'] and not summary['physical_sha_recomputed']
assert hashlib.sha256(files['mature-source-formats-rows.jsonl']).hexdigest() == summary['rows_sha256']
files['evidence-manifest.json'] = (json.dumps({n: hashlib.sha256(v).hexdigest() for n, v in files.items()},
                                           sort_keys=True, indent=2) + '\n').encode()
out = pathlib.Path('/tmp/gtron-mature-formats-20261026-01.zip')
with zipfile.ZipFile(out, 'x', zipfile.ZIP_DEFLATED) as z:
    for n, v in sorted(files.items()):
        z.writestr(n, v)
receipt = dict(path=str(out), bytes=out.stat().st_size, sha256=hashlib.sha256(out.read_bytes()).hexdigest(),
               members=len(files), production_mutations=False)
(P / 'mature-formats-archive-receipt.json').write_text(json.dumps(receipt, sort_keys=True, indent=2))
print('MATURE_ARCHIVE_READY')
