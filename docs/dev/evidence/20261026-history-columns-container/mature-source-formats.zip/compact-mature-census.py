#!/usr/bin/env python3
"""Export all ordered format prefixes when SFTP's listing is stale.

The original 48-byte header/stat rows and complete ZIP remain on the server.
This transport supports the physical-version census, not full-file SHA claims.
"""
import base64
import hashlib
import json
import pathlib
import zlib

P = pathlib.Path('/data/gtron/history-record-columns-container-20261026-01')
OLD = pathlib.Path('/data/gtron/history-tx-runs-20261025-01')
plan_raw = (OLD / 'census-plan.json').read_bytes()
assert hashlib.sha256(plan_raw).hexdigest() == '108728f335f23009784a9af2931e70ba9176f28bd22bcc92b2130d8bead66b6c'
plan = json.loads(plan_raw)
rows_raw = (P / 'mature-source-formats-rows.jsonl').read_bytes()
rows = [json.loads(line) for line in rows_raw.splitlines()]
summary = json.loads((P / 'mature-source-formats-01.json').read_text())
assert hashlib.sha256(rows_raw).hexdigest() == summary['rows_sha256']
assert len(rows) == len(plan) == 8651
prefixes = bytearray()
for ref, row in zip(plan, rows):
    assert ref['history_ref']['path'] == row['path']
    assert ref['history_ref']['size'] == row['bytes']
    assert (ref['first_block'], ref['last_block']) == (row['first_block'], row['last_block'])
    header = bytes.fromhex(row['header_hex'])
    assert len(header) == 48 and header[:8] == b'gtcblk01'
    assert int.from_bytes(header[8:12], 'big') == row['physical_version']
    prefixes.extend(header[:16])
result = dict(complete=True, production_mutations=False, header_prefix_bytes=16, files=len(rows),
              source_plan_sha256=hashlib.sha256(plan_raw).hexdigest(), full_rows_sha256=summary['rows_sha256'],
              ordered_prefixes_sha256=hashlib.sha256(prefixes).hexdigest(),
              ordered_prefixes_zlib_base64=base64.b64encode(zlib.compress(prefixes, 9)).decode(),
              physical_sha_recomputed=False,
              scope='Every physical header format prefix in the original plan order; full 48-byte/stat rows remain in the sealed server ZIP. Does not authenticate file bodies.')
(P / 'mature-source-prefixes-01.json').write_text(json.dumps(result, sort_keys=True, indent=2))
print('MATURE_PREFIXES_READY')
