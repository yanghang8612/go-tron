import pathlib,os,json,hashlib,subprocess,time,datetime,traceback,collections,concurrent.futures
P=pathlib.Path('/data/gtron/history-record-columns-container-20261026-01');PREV=pathlib.Path('/data/gtron/history-account-delta-20261025-01');S=P/'candidate-source';state={'complete':False,'production_mutations':False,'all_old_files_retained':True}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(4<<20),b''):h.update(b)
 return h.hexdigest()
def save():
 state['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();t=P/'acceptance-status.json.tmp';t.write_text(json.dumps(state,sort_keys=True,indent=2));os.replace(str(t),str(P/'acceptance-status.json'))
def run(label,args,env,timeout):
 state['phase']=label;save();start=time.monotonic()
 with (P/(label+'.log')).open('wb')as f:subprocess.run(args,cwd=str(S),env=env,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=timeout)
 state.setdefault('checks',[]).append({'label':label,'seconds':time.monotonic()-start,'returncode':0});save()
def fingerprint():
 d=P/'candidate-input/chaindata';result={}
 for x in sorted(d.iterdir()):
  if not x.is_file() or not(x.suffix in ('.sst','.log')or x.name=='CURRENT'or x.name.startswith(('MANIFEST-','OPTIONS-'))):continue
  a=x.stat();value=sha(x);b=x.stat();assert (a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns)==(b.st_dev,b.st_ino,b.st_size,b.st_mtime_ns);result[x.name]=dict(inode=a.st_ino,device=a.st_dev,bytes=a.st_size,mtime_ns=a.st_mtime_ns,sha256=value)
 return result
def source_check():
 inv=json.loads((P/'source-inventory.json').read_text());assert all(sha(S/n)==h for n,h in inv.items()),'source drift'
 extra=json.loads((P/'inherited-harness-inventory.json').read_text());assert all(sha(S/n)==h for n,h in extra.items()),'inherited harness drift'
 for n in ('offline_record_column_capture_test.go','offline_record_column_parallel_test.go','offline_record_column_controls_test.go'):
  target=S/'core/state/snapshots'/n
  if target.exists():assert sha(target)==sha(P/n),'candidate harness drift'
 return len(inv)
try:
 state['phase']='wait-conversion-and-native';save();start=time.monotonic()
 while True:
  n=json.loads((P/'native-status.json').read_text())if(P/'native-status.json').exists()else{}
  c=json.loads((P/'capture-status.json').read_text())if(P/'capture-status.json').exists()else{}
  if n.get('error')or c.get('error'):raise RuntimeError('preparation failed: '+str((n.get('error'),c.get('error'))))
  if n.get('complete')and c.get('complete'):break
  if time.monotonic()-start>47000:raise TimeoutError('capture gate')
  time.sleep(10)
 state['verified_source_files']=source_check();native=json.loads((P/'native-status.json').read_text());prior=json.loads((PREV/'native-status.json').read_text());assert prior['binaries']['baseline.test']=='fff5e1dd9f51fdaa3fb25f5a93d73147178403890e95bdc5a0fb32d9b741d4bf'
 assert sha(PREV/'baseline.test')==prior['binaries']['baseline.test'];assert sha(S/'core/offline_fixed_http_test.go')==prior['http_harness_sha256']=='10e6015af7666bf83b5c405543681c368b7537f428b8278a3344f0312aacd3bf'
 assert sha(P/'columns-http.test')==native['binaries']['columns-http.test'];os.link(str(PREV/'baseline.test'),str(P/'baseline.test'));os.link(str(P/'columns-http.test'),str(P/'candidate.test'))
 state['baseline_binary_sha256']=sha(P/'baseline.test');state['candidate_binary_sha256']=sha(P/'candidate.test');state['baseline_native_receipt_sha256']=sha(PREV/'native-status.json');state['http_harness_sha256']=sha(S/'core/offline_fixed_http_test.go')
 for mode in ('baseline','candidate'):(P/(mode+'-build-info.txt')).write_bytes(subprocess.check_output(['/data/go/bin/go','version','-m',str(P/(mode+'.test'))]))
 assert (P/'baseline-build-info.txt').read_text().splitlines()[0].split()[-1]==(P/'candidate-build-info.txt').read_text().splitlines()[0].split()[-1]
 h=S/'core/state/snapshots/offline_record_column_controls_test.go';assert not h.exists();h.write_bytes((P/h.name).read_bytes());state['control_harness_sha256']=sha(h)
 env=dict(os.environ,PATH='/data/go/bin:'+os.environ.get('PATH',''),GOCACHE='/root/.cache/go-build',GOPATH='/root/go',GOTOOLCHAIN='local',CGO_ENABLED='1',GOMAXPROCS='2',GOMEMLIMIT='3GiB',GTRON_COLUMN_CONTAINER_ROOT=str(P));env.pop('GTRON_ACCOUNT_DELTA_ROOT',None);env.pop('GTRON_FIXED_INPUT',None)
 run('controls-build',['/data/go/bin/go','test','-c','./core/state/snapshots','-o',str(P/'columns-controls.test')],env,600)
 run('controls-fixtures',[str(P/'columns-controls.test'),'-test.run=^TestRecordColumnActualControlFixture$','-test.v','-test.timeout=180s'],env,240)
 run('same-boundary-controls',[str(P/'columns-controls.test'),'-test.run=^TestOfflineRecordColumnControls$','-test.v','-test.timeout=12h'],env,43300)
 assert json.loads((P/'column-controls-status.json').read_text())['complete']
 # Move only superseded hard links in this private candidate; retain every inode.
 state['phase']='retain-source-pins';save();root=P/'candidate-input/state-snapshots';active={r['path']for r in json.loads((root/'manifest.json').read_text())['segments']};pins=P/'original-source-pins';pins.mkdir();moved=[]
 for line in (P/'complete-input-files.jsonl').read_text().splitlines():
  row=json.loads(line)
  for ref in row['source']:
   if ref['path']in active:continue
   a=root/ref['path'];b=pins/ref['path'];assert a.is_file()and not b.exists();b.parent.mkdir(parents=True,exist_ok=True);st=a.stat();a.rename(b);now=b.stat();assert (st.st_dev,st.st_ino,st.st_size)==(now.st_dev,now.st_ino,now.st_size);moved.append(dict(path=ref['path'],bytes=st.st_size,inode=st.st_ino,retained=True))
 for d in [root/'history',pins/'history',pins]:
  if d.exists():fd=os.open(str(d),os.O_RDONLY);os.fsync(fd);os.close(fd)
 (P/'retained-source-relocations.json').write_text(json.dumps(dict(complete=True,production_mutations=False,retained_root=str(pins),files=moved)))
 state['phase']='chaindata-sha-before-muhash';save();before=fingerprint();(P/'chaindata-before.json').write_text(json.dumps(before,sort_keys=True,indent=2))
 env.update(GTRON_FIXED_INPUT=str(P/'candidate-input'),GTRON_FIXED_CENSUS=str(P/'muhash-census.json'),GTRON_ROUTING_ROOT=str(P))
 run('full-muhash',[str(P/'candidate.test'),'-test.run=^TestOfflineRequestFixedMuHash$','-test.v','-test.timeout=40m'],env,2450)
 census=json.loads((P/'muhash-census.json').read_text());assert census['complete']and census['muhash_verified']and census['block_num']==11818192 and census['tx_num']==601386177;assert bytes(census['muhash_root']).hex()=='8fbf149684146a59b1650b318a768f0edbae0c8c1c3ceb2c5c610129c10f76a5';assert census['source_rows']==[3484117,481,141418493]
 after=fingerprint();(P/'chaindata-after.json').write_text(json.dumps(after,sort_keys=True,indent=2));assert before==after;state['muhash_verified']=True;state['chaindata_full_sha_unchanged']=True;state['chaindata_files']=len(before);save()
 run('history-restore',[str(P/'columns-controls.test'),'-test.run=^TestOfflineAccountHistoryRestore$','-test.v','-test.timeout=30m'],env,1850);assert json.loads((P/'history-restore.json').read_text())['complete']
 run('comparison',['/usr/bin/python3',str(P/'compare-columns.py'),'tail-read'],env,10800);comparison=json.loads((P/'tail-read-comparison/comparison-status.json').read_text());assert comparison['complete']and comparison['all_responses_correct']and not comparison['environment_identity_changed']
 state['phase']='all-reference-physical-closure';save();roots={'baseline':(P/'baseline-input/state-snapshots').resolve(),'candidate':P/'candidate-input/state-snapshots'};manifests={k:json.loads((v/'manifest.json').read_text())for k,v in roots.items()};a,b=manifests.values()
 for k in ['chain','progress','sourceRows','commitmentScheme','elementVersion','visibleTxStart','visibleTxEnd']:assert a.get(k)==b.get(k),k
 tasks={};modes={}
 for mode,root in roots.items():
  refs={}
  for r in manifests[mode]['segments']:assert r['path']not in refs or refs[r['path']]==r;refs[r['path']]=r
  groups=collections.defaultdict(lambda:dict(files=0,bytes=0,allocated=0));unique={}
  for n,r in refs.items():
   file=root/n;assert os.path.commonpath([str(root.resolve()),str(file.resolve())])==str(root.resolve());st=file.stat();assert st.st_size==r['size']and r['checksum'].startswith('sha256:');key=(st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns);groups[r['kind']]['files']+=1;groups[r['kind']]['bytes']+=st.st_size;groups[r['kind']]['allocated']+=st.st_blocks*512;unique[(st.st_dev,st.st_ino)]=st.st_blocks*512
   if key in tasks:assert tasks[key][1]==r['checksum'][7:]
   else:tasks[key]=(file,r['checksum'][7:])
  mf=root/'manifest.json';ms=mf.stat();modes[mode]=dict(ref_files=len(refs),ref_file_bytes=sum(r['size']for r in refs.values()),allocated_unique=sum(unique.values()),by_kind=dict(groups),manifest_bytes=ms.st_size,manifest_allocated=ms.st_blocks*512,manifest_sha256=sha(mf),directory_du_bytes=int(subprocess.check_output(['du','-s','-B1',str(root.resolve())]).split()[0]))
 for line in (P/'column-controls-files.jsonl').read_text().splitlines():
  row=json.loads(line);file=pathlib.Path(row['ControlPath']);st=file.stat();assert st.st_size==row['ControlFileBytes'];key=(st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns)
  if key in tasks:assert tasks[key][1]==row['ControlSHA256']
  else:tasks[key]=(file,row['ControlSHA256'])
 def check(item):
  key,(f,want)=item;got=sha(f);assert got==want,str(f);st=f.stat();assert(st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns)==key;return dict(path=str(f),sha256=got,bytes=st.st_size,inode=st.st_ino,allocated=st.st_blocks*512)
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:checked=list(pool.map(check,tasks.items()))
 state['verified_source_files_after']=source_check();result=dict(complete=True,production_mutations=False,all_old_files_retained=True,production_reclaimed_bytes=0,canonical_chain_and_frontiers_unchanged=True,all_referenced_physical_sha_verified=True,modes=modes,unique_physical_files=len(checked),physical_bytes_hashed=sum(x['bytes']for x in checked),per_file=checked,net_active_ref_bytes_including_manifest=modes['baseline']['ref_file_bytes']+modes['baseline']['manifest_bytes']-modes['candidate']['ref_file_bytes']-modes['candidate']['manifest_bytes'],net_active_allocated_including_manifest=modes['baseline']['allocated_unique']+modes['baseline']['manifest_allocated']-modes['candidate']['allocated_unique']-modes['candidate']['manifest_allocated'],net_directory_du=modes['baseline']['directory_du_bytes']-modes['candidate']['directory_du_bytes'])
 (P/'final-space-and-physical-closure.json').write_text(json.dumps(result,sort_keys=True,indent=2));state.update(complete=True,phase='complete');save()
except BaseException as e:state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
