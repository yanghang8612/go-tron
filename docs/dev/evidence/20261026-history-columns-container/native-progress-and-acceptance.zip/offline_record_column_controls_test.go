package snapshots

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"golang.org/x/sync/errgroup"
	"io"
	"os"
	"path/filepath"
	"sync"
	"syscall"
	"testing"
	"time"
)

type columnControlReceipt struct {
	Source, Candidate []SegmentRef
	Audit             HistoryRecordColumnStats
}
type columnControlRow struct {
	Source, Candidate                                                                 SegmentRef
	SourceAllocated, CandidateAllocated, LogicalBytes, Pages, ColumnPages, PlainPages uint64
	SourceCanonicalSHA256, CandidateCanonicalSHA256                                   string
	SourceIsIdenticalOrdinaryFramesAndBoundaries                                      bool
	ControlPath, ControlSHA256, ControlRepresentation                                 string
	ControlFileBytes, ControlAllocated                                                uint64
	Seconds                                                                           float64
}

func buildColumnControl(base, dir, controls string, receipt columnControlReceipt, reserve uint64) (row columnControlRow, err error) {
	started := time.Now()
	row.Source, row.Candidate = receipt.Source[0], receipt.Candidate[0]
	a, e := os.Stat(filepath.Join(base, row.Source.Path))
	if e != nil {
		return row, e
	}
	b, e := os.Stat(filepath.Join(dir, row.Candidate.Path))
	if e != nil {
		return row, e
	}
	if uint64(a.Size()) != row.Source.Size || uint64(b.Size()) != row.Candidate.Size {
		return row, fmt.Errorf("file length mismatch")
	}
	row.SourceAllocated = uint64(a.Sys().(*syscall.Stat_t).Blocks) * 512
	row.CandidateAllocated = uint64(b.Sys().(*syscall.Stat_t).Blocks) * 512
	s, e := openCompressedBlockReaderWithCacheLimit(filepath.Join(base, row.Source.Path), 1)
	if e != nil {
		return row, e
	}
	defer s.Close()
	c, e := openCompressedBlockReaderWithCacheLimit(filepath.Join(dir, row.Candidate.Path), 1)
	if e != nil {
		return row, e
	}
	defer c.Close()
	if s.uncSize != c.uncSize {
		return row, fmt.Errorf("canonical size mismatch")
	}
	row.LogicalBytes = c.uncSize
	if c.cdc != nil || c.accountDelta {
		return row, fmt.Errorf("unexpected candidate container")
	}
	if receipt.Audit.Converted && !c.recordColumns {
		return row, fmt.Errorf("converted target is not record-column format")
	}
	enc, _, e := cbCodec()
	if e != nil {
		return row, e
	}
	sh, ch := sha256.New(), sha256.New()
	sourceBuf := make([]byte, historyRecordColumnPageMax)
	equal := s.cdc == nil && !s.accountDelta && !s.recordColumns && len(s.table) == len(c.table)
	for i, entry := range c.table {
		stored, n, e := c.readCompressedBlock(i)
		if e != nil {
			return row, e
		}
		raw, e := c.decodeBlock(i, stored, n)
		if e != nil {
			return row, e
		}
		if n > historyRecordColumnPageMax {
			return row, fmt.Errorf("candidate read unit exceeds cap")
		}
		src := sourceBuf[:int(n)]
		if e = historyReferenceReadAt(context.Background(), s, src, entry.uncompressedStart); e != nil {
			return row, e
		}
		if !bytes.Equal(src, raw) {
			return row, fmt.Errorf("canonical page mismatch")
		}
		sh.Write(src)
		ch.Write(raw)
		row.Pages++
		if c.recordColumns && stored[0] == 1 {
			row.ColumnPages++
		} else {
			row.PlainPages++
		}
		if equal {
			if s.table[i].uncompressedStart != entry.uncompressedStart {
				equal = false
				continue
			}
			old, oldn, e := s.readCompressedBlock(i)
			if e != nil {
				return row, e
			}
			if oldn != n || !bytes.Equal(old, enc.EncodeAll(raw, nil)) {
				equal = false
			}
		}
	}
	row.SourceCanonicalSHA256 = fmt.Sprintf("%x", sh.Sum(nil))
	row.CandidateCanonicalSHA256 = fmt.Sprintf("%x", ch.Sum(nil))
	if row.SourceCanonicalSHA256 != row.CandidateCanonicalSHA256 {
		return row, fmt.Errorf("canonical SHA differs")
	}
	row.SourceIsIdenticalOrdinaryFramesAndBoundaries = equal
	if equal {
		row.ControlPath = filepath.Join(base, row.Source.Path)
		row.ControlSHA256 = row.Source.Checksum[len("sha256:"):]
		row.ControlRepresentation = "original immutable ordinary-Zstd frames and identical logical boundaries"
		row.ControlFileBytes = row.Source.Size
		row.ControlAllocated = row.SourceAllocated
	} else {
		var space syscall.Statfs_t
		if e = syscall.Statfs(controls, &space); e != nil {
			return row, e
		}
		if space.Bavail*uint64(space.Bsize) < row.LogicalBytes+reserve {
			return row, fmt.Errorf("control free-space reserve exhausted")
		}
		w, e := newCompressedBlockStreamWriterWithPrefix(controls, historyRecordColumnPageMax, historyHeaderPrefixBytes, 1, true)
		if e != nil {
			return row, e
		}
		defer w.Abort()
		if _, e = io.CopyBuffer(w, io.NewSectionReader(c, 0, int64(c.uncSize)), make([]byte, 64<<10)); e != nil {
			return row, e
		}
		target := filepath.Join(controls, filepath.Base(row.Source.Path))
		if _, e = os.Stat(target); !os.IsNotExist(e) {
			return row, fmt.Errorf("fresh control target required")
		}
		meta, e := w.FinishWithMetadataContext(context.Background(), target)
		if e != nil {
			return row, e
		}
		row.ControlPath = target
		row.ControlSHA256 = fmt.Sprintf("%x", meta.checksum)
		row.ControlFileBytes = meta.size
		st, e := os.Stat(target)
		if e != nil {
			return row, e
		}
		row.ControlAllocated = uint64(st.Sys().(*syscall.Stat_t).Blocks) * 512
		r, e := openCompressedBlockReaderWithCacheLimit(target, 1)
		if e != nil {
			return row, e
		}
		defer r.Close()
		if len(r.table) != len(c.table) {
			return row, fmt.Errorf("control page count differs")
		}
		for i := range r.table {
			if r.table[i].uncompressedStart != c.table[i].uncompressedStart {
				return row, fmt.Errorf("control boundaries differ")
			}
		}
		if e = historyReferenceCompareVirtual(context.Background(), r, c, c.uncSize); e != nil {
			return row, e
		}
		row.ControlRepresentation = "materialized ordinary-Zstd physical V2 at identical 128 KiB boundaries"
	}
	row.Seconds = time.Since(started).Seconds()
	return row, nil
}

func TestOfflineRecordColumnControls(t *testing.T) {
	root := os.Getenv("GTRON_COLUMN_CONTAINER_ROOT")
	if root == "" {
		t.Skip("isolated fixed capture")
	}
	base, dir := filepath.Join(root, "baseline-input/state-snapshots"), filepath.Join(root, "candidate-input/state-snapshots")
	control := filepath.Join(root, "plain-controls")
	if e := os.Mkdir(control, 0700); e != nil {
		t.Fatal(e)
	}
	f, e := os.Open(filepath.Join(root, "complete-input-files.jsonl"))
	if e != nil {
		t.Fatal(e)
	}
	dec := json.NewDecoder(f)
	var receipts []columnControlReceipt
	seen := map[string]bool{}
	for {
		var r columnControlReceipt
		e = dec.Decode(&r)
		if e == io.EOF {
			break
		}
		if e != nil {
			t.Fatal(e)
		}
		if len(r.Source) != 3 || len(r.Candidate) != 3 || seen[r.Source[0].Path] {
			t.Fatal("invalid trio receipt")
		}
		seen[r.Source[0].Path] = true
		receipts = append(receipts, r)
	}
	f.Close()
	if len(receipts) != 4609 {
		t.Fatalf("expected all fixed files, got %d", len(receipts))
	}
	out, e := os.OpenFile(filepath.Join(root, "column-controls-files.jsonl"), os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if e != nil {
		t.Fatal(e)
	}
	defer out.Close()
	started := time.Now()
	var sourceBytes, candidateBytes, controlBytes, sourceAlloc, candidateAlloc, controlAlloc uint64
	done, equal, transformed := 0, 0, uint64(0)
	var mu sync.Mutex
	status := func(complete bool) error {
		b, e := json.MarshalIndent(map[string]any{"complete": complete, "files": done, "total": len(receipts), "source_bytes": sourceBytes, "candidate_bytes": candidateBytes, "control_bytes": controlBytes, "source_allocated": sourceAlloc, "candidate_allocated": candidateAlloc, "control_allocated": controlAlloc, "original_control_equivalent_files": equal, "column_pages": transformed, "seconds": time.Since(started).Seconds(), "production_mutations": false}, "", "  ")
		if e != nil {
			return e
		}
		path := filepath.Join(root, "column-controls-status.json")
		if e = os.WriteFile(path+".tmp", b, 0600); e != nil {
			return e
		}
		return os.Rename(path+".tmp", path)
	}
	if e = status(false); e != nil {
		t.Fatal(e)
	}
	g, _ := errgroup.WithContext(context.Background())
	g.SetLimit(4)
	for _, r := range receipts {
		r := r
		g.Go(func() error {
			row, e := buildColumnControl(base, dir, control, r, 100*1000*1000*1000)
			if e != nil {
				return fmt.Errorf("%s: %w", r.Source[0].Path, e)
			}
			mu.Lock()
			defer mu.Unlock()
			if e = json.NewEncoder(out).Encode(row); e != nil {
				return e
			}
			sourceBytes += row.Source.Size
			candidateBytes += row.Candidate.Size
			controlBytes += row.ControlFileBytes
			sourceAlloc += row.SourceAllocated
			candidateAlloc += row.CandidateAllocated
			controlAlloc += row.ControlAllocated
			if row.SourceIsIdenticalOrdinaryFramesAndBoundaries {
				equal++
			}
			transformed += row.ColumnPages
			done++
			if done%25 == 0 {
				if e = out.Sync(); e != nil {
					return e
				}
				return status(false)
			}
			return nil
		})
	}
	if e = g.Wait(); e != nil {
		t.Fatal(e)
	}
	if done != len(receipts) {
		t.Fatal("incomplete controls")
	}
	if e = out.Sync(); e != nil {
		t.Fatal(e)
	}
	if e = status(true); e != nil {
		t.Fatal(e)
	}
}

func TestRecordColumnActualControlFixture(t *testing.T) {
	for _, format := range []string{"2", "1"} {
		t.Run(format, func(t *testing.T) {
			dir := t.TempDir()
			refs := writeV6StateDomainHistorySegmentForTest(t, dir, 1, 6000, v6StreamChanges(1, 6000, 1, 80))
			for i, ref := range refs {
				if ref.Kind != SegmentHistory {
					continue
				}
				path := filepath.Join(dir, ref.Path)
				raw, e := os.ReadFile(path)
				if e != nil {
					t.Fatal(e)
				}
				if format == "2" {
					w, e := newCompressedBlockStreamWriterWithPrefix(dir, historyRecordColumnPageMax, historyHeaderPrefixBytes, 1, true)
					if e != nil {
						t.Fatal(e)
					}
					if _, e = w.Write(raw); e != nil {
						t.Fatal(e)
					}
					if e = w.Finish(path); e != nil {
						t.Fatal(e)
					}
				} else {
					w, e := newCompressedBlockWriter(dir, 1)
					if e != nil {
						t.Fatal(e)
					}
					for off := 0; off < len(raw); off += historyRecordColumnPageMax {
						if _, e = w.Append(raw[off:min(len(raw), off+historyRecordColumnPageMax)]); e != nil {
							t.Fatal(e)
						}
					}
					if e = w.Finish(path); e != nil {
						t.Fatal(e)
					}
				}
				refs[i].Size, refs[i].Checksum, e = stateDomainChangeBinaryFileMetadata(path)
				if e != nil {
					t.Fatal(e)
				}
			}
			target, stats, e := ReencodeHistoryRecordColumnsTrioContext(context.Background(), dir, refs)
			if e != nil {
				t.Fatal(e)
			}
			if !stats.Converted {
				t.Fatal("fixture did not select columns")
			}
			controls := t.TempDir()
			row, e := buildColumnControl(dir, dir, controls, columnControlReceipt{Source: refs, Candidate: target, Audit: stats}, 0)
			if e != nil {
				t.Fatal(e)
			}
			if row.SourceIsIdenticalOrdinaryFramesAndBoundaries != (format == "2") || row.ColumnPages == 0 || row.SourceCanonicalSHA256 != row.CandidateCanonicalSHA256 {
				t.Fatalf("bad control: %+v", row)
			}
		})
	}
}
