#!/usr/bin/env python3
"""Verify ordered UI-transferred chunks, then verify the entire sealed ZIP."""
import argparse
import hashlib
import json
import pathlib
import zipfile

P = pathlib.Path(__file__).resolve().parent
EXPECTED_BYTES = 442721
EXPECTED_SHA = '96ea01fc84e8ff8354b1137035f48d2937c611fcd2f9a87b9c6a3b5f34be4433'


def sha(b):
    return hashlib.sha256(b).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--partial', action='store_true')
    args = parser.parse_args()
    parts = []
    for root in (P / 'download-mature', P / 'download-mature-remainder'):
        for meta_file in root.glob('chunk-*.bin.json'):
            meta = json.loads(meta_file.read_bytes())
            data = meta_file.with_suffix('').read_bytes()
            assert meta['name'] == 'gtron-mature-formats-20261026-01.zip'
            assert meta['file_bytes'] == EXPECTED_BYTES and meta['bytes'] == len(data)
            assert meta['sha256'] == sha(data) and meta['nonce']
            parts.append((meta['offset'], data, meta))
    parts.sort(key=lambda r: r[0])
    assert len({m['nonce'] for _, _, m in parts}) == len(parts)
    assert len({(str(m['inode']), str(m['device'])) for _, _, m in parts}) == 1
    off = 0
    for start, data, _ in parts:
        assert start == off, 'Gap, duplicate or overlap at {}'.format(off)
        off += len(data)
    result = dict(complete=False, chunks=len(parts), bytes=off, expected_bytes=EXPECTED_BYTES,
                  production_mutations=False, exact_chunk_bodies_preserved=True,
                  scope='Checks chunk bytes/offsets/nonces and SHA; transport metadata is not a DB body audit.')
    if args.partial:
        assert off <= EXPECTED_BYTES
    else:
        assert off == EXPECTED_BYTES
        data = b''.join(row[1] for row in parts)
        assert sha(data) == EXPECTED_SHA
        out = P / 'server-mature-source-full.zip'
        if out.exists():
            assert out.read_bytes() == data
        else:
            out.write_bytes(data)
        with zipfile.ZipFile(out) as z:
            assert z.testzip() is None
            names = z.namelist()
            assert len(names) == len(set(names)) == 7
            manifest = json.loads(z.read('evidence-manifest.json'))
            assert set(names) == set(manifest) | {'evidence-manifest.json'}
            for name, expected in manifest.items():
                p = pathlib.PurePosixPath(name)
                assert not p.is_absolute() and '..' not in p.parts
                assert sha(z.read(name)) == expected
        result.update(complete=True, exact_archive_body_preserved=True, sha256=EXPECTED_SHA, zip_crc_verified=True,
                      archive_members=7, member_sha_verified=True)
        (P / 'binary-transfer-complete.json').write_text(json.dumps(result, sort_keys=True, indent=2)+'\n')
    print(json.dumps(result, sort_keys=True, indent=2))


if __name__ == '__main__':
    main()
