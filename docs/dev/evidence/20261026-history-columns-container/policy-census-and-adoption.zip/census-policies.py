import pathlib,json,collections,hashlib,datetime
P=pathlib.Path('/data/gtron/history-record-columns-container-20261026-01');BASE=P/'baseline-input/state-snapshots';raw=(BASE/'manifest.json').read_bytes();m=json.loads(raw)
refs=[r for r in m['segments']if r['kind']=='history'and(r.get('dataset')=='state-domain-change'or'state-domain-change'in r['path'])];assert len(refs)==4609,'fixed corpus history selection'
headers={};groups=collections.defaultdict(lambda:dict(files=0,bytes=0))
for r in refs:
 p=BASE/r['path'];assert p.stat().st_size==r['size']
 with p.open('rb')as f:h=f.read(48)
 assert len(h)==48
 version=str(int.from_bytes(h[8:12],'big'))if h[:8]==b'gtcblk01'else'raw-'+h[:8].hex()
 headers[r['path']]=version;groups[version]['files']+=1;groups[version]['bytes']+=r['size']
completed=collections.defaultdict(lambda:dict(files=0,source_bytes=0,candidate_bytes=0,after_bytes=0,converted_files=0,kept_source_files=0,logical_bytes=0,records=0));seen=set();rows=(P/'complete-input-files.jsonl').read_bytes().splitlines(keepends=True)
for line in rows:
 if not line.endswith(b'\n'):continue
 r=json.loads(line);source=r['source'][0];assert source['path']in headers and source['path']not in seen;seen.add(source['path']);a=r['audit'];g=completed[headers[source['path']]];g['files']+=1;g['source_bytes']+=a['BeforeBytes'];g['candidate_bytes']+=a['CandidateBytes'];g['after_bytes']+=a['AfterBytes'];g['logical_bytes']+=a['LogicalBytes'];g['records']+=a['Records'];g['converted_files']+=bool(a['Converted']);g['kept_source_files']+=not bool(a['Converted'])
result=dict(complete=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),production_mutations=False,scope='All immutable baseline .seg physical headers and currently complete append-only trio receipts; not final physical SHA closure or a fresh-genesis adoption test.',source_manifest_sha256=hashlib.sha256(raw).hexdigest(),all_source_files=len(refs),all_source_bytes=sum(r['size']for r in refs),source_versions=dict(groups),complete_receipts_at_observation=len(seen),completed_by_source_version=dict(completed),explicit_5_bypasses_cdc_policy=True,offline_converter_whole_file_fallback=True)
(P/'policy-census-01.json').write_text(json.dumps(result,sort_keys=True,indent=2));print('POLICY_CENSUS_READY',len(seen),dict(groups))
