package snapshots

import (
	"context"
	"encoding/binary"
	"encoding/json"
	"math/rand"
	"os"
	"path/filepath"
	"reflect"
	"syscall"
	"testing"

	"github.com/tronprotocol/go-tron/core/rawdb"
)

// A compression-policy stress case, not a measured mainnet frequency. Archival
// Prev bytes are opaque and must remain exact even for repeated large images.
func TestRecordColumnFreshPolicyStress(t *testing.T) {
	db := rawdb.NewMemoryDatabase()
	defer db.Close()
	payload := make([]byte, 512<<10)
	rand.New(rand.NewSource(20261026)).Read(payload)
	for block := uint64(1); block <= 16; block++ {
		c := compressionPolicyChange(payload)
		c.BlockNum = block
		c.TxNum = block
		c.Seq = 1
		if e := rawdb.WriteStateTxRange(db, block, c.BlockHash, block, block); e != nil {
			t.Fatal(e)
		}
		if e := rawdb.WriteStateDomainChangeBlockRows(db, []*rawdb.StateDomainChange{&c}); e != nil {
			t.Fatal(e)
		}
	}
	cfg, _ := DefaultDomainRegistry().Dataset(SegmentDatasetStateDomainChange)
	path := cfg.HistoryPath(1, 16)
	expected, e := DigestHotStateHistoryCompatibilityContext(context.Background(), db, t.TempDir(), 1, 16, 1, 16, 16<<20)
	if e != nil {
		t.Fatal(e)
	}
	type result struct {
		Format           string
		PhysicalVersion  uint32
		Files, Allocated uint64
		Logical          StateHistoryDiagnosticDigest
	}
	var rows []result
	var sourceVersion2, forcedVersion5, autoBytes uint64
	var autoDir string
	var autoRefs []SegmentRef
	for _, format := range []string{"2", "3", "auto", "5"} {
		dir := t.TempDir()
		refs, e := BuildDiagnosticStateHistoryTrioContext(context.Background(), db, dir, 1, 16, 1, 16, path, format)
		if e != nil {
			t.Fatal(e)
		}
		got, e := DigestColdStateHistoryContext(context.Background(), dir, refs)
		if e != nil || !reflect.DeepEqual(got, expected) {
			t.Fatalf("%s diagnostic mismatch: %+v %+v %v", format, got, expected, e)
		}
		r := result{Format: format, Logical: got}
		for _, ref := range refs {
			st, e := os.Stat(filepath.Join(dir, ref.Path))
			if e != nil {
				t.Fatal(e)
			}
			r.Files += uint64(st.Size())
			r.Allocated += uint64(st.Sys().(*syscall.Stat_t).Blocks) * 512
			if ref.Kind == SegmentHistory {
				f, e := os.Open(filepath.Join(dir, ref.Path))
				if e != nil {
					t.Fatal(e)
				}
				var h [16]byte
				_, e = f.Read(h[:])
				f.Close()
				if e != nil {
					t.Fatal(e)
				}
				r.PhysicalVersion = binary.BigEndian.Uint32(h[8:12])
			}
		}
		if format == "2" {
			sourceVersion2 = r.Files
		}
		if format == "5" {
			forcedVersion5 = r.Files
		}
		if format == "auto" {
			autoBytes = r.Files
			autoDir, autoRefs = dir, refs
			if r.PhysicalVersion != compressedBlockCDCVersion {
				t.Fatal("auto lost CDC")
			}
		}
		if format == "5" && r.PhysicalVersion != compressedBlockRecordColumnsVersion {
			t.Fatal("explicit 5 did not select record columns")
		}
		rows = append(rows, r)
	}
	if autoBytes >= forcedVersion5 || autoBytes >= sourceVersion2 {
		t.Fatal("fixture did not expose CDC policy difference")
	}
	kept, stats, e := ReencodeHistoryRecordColumnsTrioContext(context.Background(), autoDir, autoRefs)
	if e != nil || stats.Converted || stats.BeforeBytes != stats.AfterBytes || !reflect.DeepEqual(kept, autoRefs) {
		t.Fatalf("offline CDC fallback failed: %+v %v", stats, e)
	}
	got, e := DigestColdStateHistoryContext(context.Background(), autoDir, kept)
	if e != nil || !reflect.DeepEqual(got, expected) {
		t.Fatal("fallback source changed", e)
	}
	b, _ := json.Marshal(map[string]any{"scope": "Synthetic large opaque Prev stress; not a production distribution or HTTP test", "source_records": 16, "source_prev_bytes": 16 * len(payload), "all_row_and_range_digests_identical": true, "trios": rows, "from_genesis_explicit_5_keeps_cdc_heuristic": false, "offline_retained_cdc_source": true, "offline_stats": stats})
	t.Log(string(b))
}
