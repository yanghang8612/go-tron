#!/usr/bin/env python3
"""Replay the synthetic policy case in a Go overlay; no source/DB mutation."""
import argparse
import json
import pathlib
import subprocess
import tempfile


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source_root", type=pathlib.Path)
    args = parser.parse_args()
    root = args.source_root.resolve()
    helper = pathlib.Path(__file__).with_name("offline_record_column_adoption_test.go")
    assert helper.is_file()
    with tempfile.TemporaryDirectory(prefix="gtron-column-policy-") as scratch:
        overlay = pathlib.Path(scratch) / "overlay.json"
        target = root / "core/state/snapshots" / helper.name
        assert not target.exists(), "Overlay target must not hide a source file"
        overlay.write_text(json.dumps({"Replace": {str(target): str(helper.resolve())}}))
        subprocess.run([
            "go", "test", "-overlay", str(overlay), "./core/state/snapshots",
            "-run", "^TestRecordColumnFreshPolicyStress$", "-count=1", "-v",
            "-timeout", "180s",
        ], cwd=root, check=True)


if __name__ == "__main__":
    main()
