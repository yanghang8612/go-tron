import pathlib,subprocess,json,hashlib,zipfile,io
R=pathlib.Path.cwd(); P=R/'build/benchmarks/20261026-history-columns-container'; LAB='/data/gtron/history-record-columns-container-20261026-01'
def git(*a): return subprocess.check_output(['git',*a]).decode().split('\0')
tracked=[n for n in git('ls-files','-z') if n and (n.endswith('.go') or n in ('go.mod','go.sum','third_party/pebble/go.mod','third_party/pebble/go.sum'))]
new=[n for n in git('ls-files','--others','--exclude-standard','-z','--','*.go') if n]
files=sorted(set(tracked+new)); manifest={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in files}
changed=set(n for n in git('diff','--name-only','-z','0bc938ff','--','*.go','go.mod','go.sum') if n)|set(new)
assert all(n in manifest for n in changed)
(P/'source-inventory.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
h=(R/'build/benchmarks/20261025-account-delta/final/harness-source/core/state/snapshots/offline_account_delta_capture_test.go').read_text().replace('saveADCapture','saveColumnCapture').replace('TestOfflineAccountDeltaCapture','TestOfflineRecordColumnCapture').replace('GTRON_ACCOUNT_DELTA_ROOT','GTRON_COLUMN_CONTAINER_ROOT').replace('ReencodeHistoryAccountDeltaTrioContext','ReencodeHistoryRecordColumnsTrioContext')
h=h.replace('out,stats,e:=ReencodeHistoryRecordColumnsTrioContext','fileStarted:=time.Now();out,stats,e:=ReencodeHistoryRecordColumnsTrioContext').replace('"audit":stats,','"audit":stats,"seconds":time.Since(fileStarted).Seconds(),')
(P/'offline_record_column_capture_test.go').write_text(h)
installer=r'''import pathlib,os,json,hashlib,shutil,datetime,subprocess,traceback,time
P=pathlib.Path('/data/gtron/history-record-columns-container-20261026-01'); BASE=pathlib.Path('/data/gtron/history-account-delta-20261025-01/candidate-source'); S=P/'candidate-source'
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,v):
 t=P/(n+'.tmp');t.write_text(json.dumps(v,sort_keys=True,indent=2));os.replace(str(t),str(P/n))
status={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'production_mutations':False,'complete':False,'checks':[]}
def run(label,cmd,env,timeout):
 started=time.monotonic();status['stage']=label;save('native-status.json',status)
 with (P/(label+'.log')).open('wb') as f:r=subprocess.run(cmd,cwd=str(S),env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 status['checks'].append({'label':label,'argv':cmd,'returncode':r.returncode,'seconds':time.monotonic()-started});save('native-status.json',status)
 if r.returncode:raise RuntimeError(label+' failed '+str(r.returncode))
try:
 assert not S.exists(),'candidate source already exists'
 base=json.loads((P/'base-inventory.json').read_text());bad=[n for n,h in base.items() if not (BASE/n).is_file() or digest(BASE/n)!=h]
 save('base-verification.json',{'files':len(base),'mismatches':bad});assert not bad,'baseline source mismatch'
 assert shutil.disk_usage('/data').free>180*10**9,'disk reserve preflight'
 shutil.copytree(str(BASE),str(S),symlinks=True,copy_function=os.link)
 payload=P/'source';current=json.loads((P/'source-inventory.json').read_text())
 for x in payload.rglob('*'):
  if x.is_file():
   rel=x.relative_to(payload);dst=S/rel;dst.parent.mkdir(parents=True,exist_ok=True);tmp=dst.with_name(dst.name+'.columns-private');tmp.write_bytes(x.read_bytes());os.replace(str(tmp),str(dst))
 bad=[n for n,h in current.items() if not (S/n).is_file() or digest(S/n)!=h]
 save('source-verification.json',{'files':len(current),'tests':sum(n.endswith('_test.go') for n in current),'mismatches':bad});assert not bad,'full source mismatch'
 extra={str(p.relative_to(S)):digest(p) for p in S.rglob('offline_*.go')};save('inherited-harness-inventory.json',extra)
 dst=S/'core/state/snapshots/offline_record_column_capture_test.go';assert not dst.exists();dst.write_bytes((P/dst.name).read_bytes())
 env=dict(os.environ,PATH='/data/go/bin:'+os.environ.get('PATH',''),GOCACHE='/root/.cache/go-build',GOPATH='/root/go',GOTOOLCHAIN='local',CGO_ENABLED='1',GOMAXPROCS='2',GOMEMLIMIT='3GiB')
 env.pop('GTRON_ACCOUNT_DELTA_ROOT',None);env.pop('GTRON_FIXED_INPUT',None);env.pop('GTRON_COLUMN_CONTAINER_ROOT',None)
 status['go_version']=subprocess.check_output(['/data/go/bin/go','version'],env=env,universal_newlines=True).strip()
 run('native-record-tests',['/data/go/bin/go','test','./core/state/snapshots','-run','^(TestRecordColumn|TestHistoryReferenceTranscodeAllFormatsFullTrio|TestHistoryReferenceBuildIntegrationOracle|TestHistoryV6StreamMatchesPlainMerge)','-count=1','-timeout=300s'],env,400)
 run('native-snapshots-build',['/data/go/bin/go','test','-c','./core/state/snapshots','-o',str(P/'columns-snapshots.test')],env,600)
 run('native-http-build',['/data/go/bin/go','test','-c','./core','-o',str(P/'columns-http.test')],env,600)
 run('native-packages',['/data/go/bin/go','test','-p','2','./core/rawdb','./core/state','./core/state/snapshots','./core','./cmd/gtron','-count=1','-timeout=1200s'],env,1800)
 run('native-race',['/data/go/bin/go','test','-race','./core/state/snapshots','-run','^TestRecordColumn','-count=1','-timeout=300s'],env,600)
 run('native-vet',['/data/go/bin/go','vet','./core/rawdb','./core/state','./core/state/snapshots','./core','./cmd/gtron'],env,600)
 run('native-sapling-build',['/data/go/bin/go','build','-tags=sapling','-o',str(P/'gtron-columns'),'./cmd/gtron'],env,900)
 status['binaries']={n:digest(P/n) for n in ('columns-snapshots.test','columns-http.test','gtron-columns')};status['complete']=True;status['stage']='complete';save('native-status.json',status)
except Exception as e:
 status['error']=str(e);status['traceback']=traceback.format_exc();save('native-status.json',status);raise
'''
(P/'prepare-native.py').write_text(installer)
items={f'source/{n}':(R/n).read_bytes() for n in sorted(changed)}
for n in ['source-inventory.json','base-inventory.json','prepare-native.py','offline_record_column_capture_test.go']:items[n]=(P/n).read_bytes()
items['payload-manifest.json']=json.dumps({n:hashlib.sha256(b).hexdigest() for n,b in items.items()},sort_keys=True,indent=2).encode()
b=io.BytesIO()
with zipfile.ZipFile(b,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,v in sorted(items.items()):z.writestr(n,v)
data=b.getvalue();(P/'source-payload.zip').write_bytes(data)
print(json.dumps({'source_files':len(manifest),'tests':sum(n.endswith('_test.go') for n in manifest),'changed':len(changed),'payload_bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'chunks':(len(data)+29999)//30000}))
