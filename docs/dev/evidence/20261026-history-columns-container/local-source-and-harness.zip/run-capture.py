import pathlib,os,sys,json,hashlib,shutil,subprocess,time,datetime,traceback
P=pathlib.Path('/data/gtron/history-record-columns-container-20261026-01'); SOURCE=pathlib.Path('/data/gtron/history-account-delta-20261025-01/baseline-input'); S=P/'candidate-source';state={'complete':False,'production_mutations':False,'parallel_trio_workers':4}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save():
 state['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();t=P/'capture-status.json.tmp';t.write_text(json.dumps(state,sort_keys=True,indent=2));os.replace(str(t),str(P/'capture-status.json'))
def ident():
 d=dict(l.split('=',1) for l in subprocess.check_output(['systemctl','show','gtron','-p','MainPID','-p','ActiveState'],universal_newlines=True).splitlines());pid=int(d['MainPID']);d['binary_sha256']=sha(pathlib.Path('/proc/%d/exe'%pid)) if pid else None;return d
def replica(dst):
 dst.mkdir()
 for d,dirs,files in os.walk(str(SOURCE)):
  rel=pathlib.Path(d).relative_to(SOURCE);(dst/rel).mkdir(exist_ok=True)
  for n in files:
   if n in ('LOCK','FLOCK'):continue
   a=pathlib.Path(d)/n;b=dst/rel/n
   if a.suffix in ('.sst','.seg','.idx','.kv','.route','.gtv2') or str(rel).startswith('ancient'):os.link(str(a),str(b))
   else:shutil.copy2(str(a),str(b))
try:
 state['before_identity']=ident();state['phase']='wait-native';save();started=time.monotonic()
 while True:
  if (P/'native-status.json').exists():
   native=json.loads((P/'native-status.json').read_text())
   if native.get('error'):raise RuntimeError('native preparation failed: '+native['error'])
   if native.get('complete'):break
  if time.monotonic()-started>5400:raise TimeoutError('native gate deadline')
  time.sleep(5)
 assert shutil.disk_usage('/data').free>180*10**9,'disk reserve'
 assert not (P/'candidate-input').exists(),'fresh immutable candidate required'
 baseline=P/'baseline-input';assert not baseline.exists();baseline.symlink_to(SOURCE,target_is_directory=True)
 replica(P/'candidate-input');(P/'complete-input-files.jsonl').touch(exist_ok=False)
 manifest=SOURCE/'state-snapshots/manifest.json';state['source_manifest_sha256']=sha(manifest);assert sha(P/'candidate-input/state-snapshots/manifest.json')==state['source_manifest_sha256']
 state['phase']='build-parallel-capture';save()
 harness=S/'core/state/snapshots/offline_record_column_parallel_test.go';assert not harness.exists();harness.write_bytes((P/harness.name).read_bytes());state['capture_harness_sha256']=sha(harness)
 env=dict(os.environ,PATH='/data/go/bin:'+os.environ.get('PATH',''),GOCACHE='/root/.cache/go-build',GOPATH='/root/go',GOTOOLCHAIN='local',CGO_ENABLED='1',GOMAXPROCS='2',GOMEMLIMIT='3GiB',GTRON_COLUMN_CONTAINER_ROOT=str(P));env.pop('GTRON_ACCOUNT_DELTA_ROOT',None);env.pop('GTRON_FIXED_INPUT',None)
 with (P/'capture-build.log').open('wb')as f:subprocess.run(['/data/go/bin/go','test','-c','./core/state/snapshots','-o',str(P/'columns-capture.test')],cwd=str(S),env=env,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=600)
 state['capture_binary_sha256']=sha(P/'columns-capture.test');state['phase']='convert-and-strictly-check';save()
 with (P/'complete-input.log').open('wb')as f:subprocess.run([str(P/'columns-capture.test'),'-test.run=^TestOfflineRecordColumnCaptureParallel$','-test.v','-test.timeout=12h'],cwd=str(S),env=env,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=43300)
 assert json.loads((P/'complete-input-status.json').read_text())['complete'];assert json.loads((P/'complete-input-routing.json').read_text())['complete'];assert sha(manifest)==state['source_manifest_sha256']
 state['after_identity']=ident();state['identity_changed']=state['after_identity']!=state['before_identity'];state['phase']='converted-await-full-audit-http';state['complete']=True;save()
except BaseException as e:state['phase']='failed';state['error']=repr(e);state['traceback']=traceback.format_exc();save();raise
